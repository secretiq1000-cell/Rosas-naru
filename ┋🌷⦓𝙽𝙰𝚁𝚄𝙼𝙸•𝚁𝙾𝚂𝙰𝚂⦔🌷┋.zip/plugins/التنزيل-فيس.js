import axios from 'axios'
import * as cheerio from 'cheerio'
import qs from 'qs'

// نرسل رسالة التوضيح مرة واحدة فقط لكل محادثة
const shownGuide = new Set()

// توقيع ثابت
const SIGN = '𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀'

// دالة التوقيع
const vito = (text) => `💀 ${text}\n\n${SIGN}`

// رسالة توضيحية حسب الأمر
function buildGuide(commandUsed) {
  const sampleUrl = 'https://www.facebook.com/watch/?v=1234567890'
  const cmd = commandUsed

  return vito(
`اسمعني يا صديقي... تعطيني الرابط، أعطيك الفيديو. خدمة واضحة ومباشرة.

طريقة الاستخدام:
- ارسل الامر ثم الرابط مباشرة

مثال:
${cmd} ${sampleUrl}

ملاحظات:
- ان كان الفيديو بجودة عالية سارسله لك
- لا تكثر بالكلام، الرابط يكفي`
  )
}

let handler = async (m, { command, args, conn }) => {
  try {
    const commandUsed = command

    // لو مفيش رابط
    if (!args[0]) {
      await m.reply(
        vito(
          'احضر لي الرابط اولا... اكتب الامر ثم الصق رابط فيسبوك مباشرة'
        )
      )

      if (!shownGuide.has(m.chat)) {
        shownGuide.add(m.chat)
        await m.reply(buildGuide(commandUsed))
      }
      return
    }

    const url = args[0]

    // تحقق من رابط فيسبوك
    if (!/^https?:\/\/(www\.|m\.)?(facebook\.com|fb\.watch)/i.test(url)) {
      return m.reply(
        vito(
          'هذا الرابط ليس من فيسبوك. استخدم facebook.com او fb.watch'
        )
      )
    }

    // رد مؤقت
    await m.reply(vito('انتظر لحظة... جاري تجهيز الفيديو'))

    const payload = qs.stringify({ fb_url: url })

    const res = await axios.post(
      'https://saveas.co/smart_download.php',
      payload,
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'Mozilla/5.0'
        },
        timeout: 20000
      }
    )

    const $ = cheerio.load(res.data)
    const hd = $('#hdLink').attr('href')
    const sd = $('#sdLink').attr('href')
    const video = hd || sd

    if (!video) {
      await m.reply(
        vito(
          'لم اجد رابط تحميل. جرب رابطا اخر او فيديو مختلف'
        )
      )

      if (!shownGuide.has(m.chat)) {
        shownGuide.add(m.chat)
        await m.reply(buildGuide(commandUsed))
      }
      return
    }

    // ارسال الفيديو
    await conn.sendMessage(
      m.chat,
      {
        video: { url: video },
        caption: vito('هذا هو الفيديو. اذا احتجت غيره ارسل رابطا جديدا')
      },
      { quoted: m }
    )

  } catch (e) {
    await m.reply(
      vito(
        `حدث خطا: ${e.message || e}\nجرب رابطا اخر`
      )
    )
  }
}

// الاوامر
handler.command = ['فيس', 'فيسبوك', 'facebook', 'fb']
handler.tags = ['downloader']
handler.help = ['فيس <رابط>']

export default handler
