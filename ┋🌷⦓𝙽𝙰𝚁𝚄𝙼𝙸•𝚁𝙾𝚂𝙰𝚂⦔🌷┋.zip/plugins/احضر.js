import fetch from 'node-fetch'
import { format } from 'util'

const handler = async (m, { conn, text }) => {
  try {
    if (!text || !/^https?:\/\//i.test(text))
      throw '🧞 يجب أن يبدأ الرابط بـ http:// أو https://'

    const res = await fetch(text)

    if (!res.ok)
      throw `🧞 فشل الطلب! الحالة: ${res.status}`

    const length = Number(res.headers.get('content-length') || 0)
    const type = res.headers.get('content-type') || ''

    // حد أقصى 50MB
    if (length > 50 * 1024 * 1024)
      throw `🧞 الملف كبير جدًا (${(length / 1024 / 1024).toFixed(2)} MB)`

    // إذا لم يكن نص أو JSON → أرسل كملف
    if (!/text|json/i.test(type)) {
      return conn.sendFile(m.chat, text, 'file', '📦 تــــــــــم احـــــــضـــــار طـــــلــبــڪ ، دانـــــي فـي خدمتـڪ دايـما" ي حـب 🌹', m)
    }

    let buffer = Buffer.from(await res.arrayBuffer())
    let output

    try {
      output = format(JSON.parse(buffer.toString()))
    } catch {
      output = buffer.toString()
    }

    m.reply(output.slice(0, 65536))
  } catch (e) {
    m.reply(String(e))
  }
}

handler.help = ['fetch', 'get', 'احضر'].map(v => v + ' <الرابط>')
handler.tags = ['internet']
handler.command = /^(fetch|get|احضر)$/i
handler.premium = true

export default handler
