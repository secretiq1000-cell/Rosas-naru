import * as cheerio from "cheerio"
import { basename, extname } from "path"
import mime from "mime-types"

async function mediafire(url) {
    const $ = cheerio.load(await (await fetch(url.trim())).text())
    const title = $("meta[property='og:title']").attr("content")?.trim() || "Unknown"
    const size = /Download\s*\(([\d.]+\s*[KMGT]?B)\)/i.exec($.html())?.[1] || "Unknown"
    const dl = $("a.popsok[href^='https://download']").attr("href")?.trim() || $("a.popsok:not([href^='javascript'])").attr("href")?.trim() || (() => { throw new Error("Download URL not found.") })()
    return { name: title, filename: basename(dl), type: extname(dl), size, download: dl, link: url.trim() }
}

let handler = async (m, { conn, args, command }) => {
    try {
        if (!args[0]) {
            let usageMessage = `💀 *يا رفيقي، أنت نسيت الرابط!* 💀\n\n`
            usageMessage += `*طريقة الاستخدام الصحيحة:*\n`
            usageMessage += `.${command} <رابط الميديا فاير>\n\n`
            usageMessage += `*مثال عملي 💼:*\n`
            usageMessage += `.${command} https://www.mediafire.com/file/1fqjqg7e8e2v3ao/YOWA.v8.87_By.SamMods.apk/\n\n`
            usageMessage += `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
            return m.reply(usageMessage)
        }
        
        let data = await mediafire(args[0])
        let mimetype = mime.lookup(data.filename) || 'application/octet-stream'
        
        await m.reply(`💀 *تم العثور على الملف، جاري التحميل...* 💀\n\n📁 *الاسم:* ${data.name}\n📊 *الحجم:* ${data.size}\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`)
        
        await conn.sendMessage(m.chat, { 
            document: { url: data.download }, 
            mimetype, 
            fileName: data.filename 
        }, { quoted: m })
        
    } catch (e) {
        let errorMessage = `💀 *حدث خطأ يا رفيقي!* 💀\n\n`
        errorMessage += `*الخطأ:* ${e.message}\n\n`
        errorMessage += `تأكد من أن الرابط صحيح وأن الملف متاح للتحميل 💼\n\n`
        errorMessage += `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
        m.reply(errorMessage)
    }
}

handler.help = ['mediafire', 'ميديافاير', 'ميديا-فاير']
handler.command = ['mediafire', 'mf', 'ميديافاير', 'ميديا-فاير']
handler.tags = ['downloader']

export default handler
