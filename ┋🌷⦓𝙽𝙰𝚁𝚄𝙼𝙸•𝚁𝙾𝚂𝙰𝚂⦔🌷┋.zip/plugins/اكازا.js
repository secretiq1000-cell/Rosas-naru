// ❄️ كود أكازا : مرثية الروح المحطمة ❄️

let handler = async (m, { conn }) => {
  try {
    // اختيار الشخص المذكور أو توجيه الرسالة للعدم
    let target = 'إلى الروح التائهة في دياجير الظلام...'
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      target = `@${m.mentionedJid[0].split('@')[0]}`
    } else if (m.quoted) {
      target = `@${m.quoted.sender.split('@')[0]}`
    }

    // اقتباسات طويلة وعميقة (سردية)
    const tragicTales = [
      '❄️ "كنت أريد حماية أبي، فمات.. كنت أريد حماية معلمي وخطيبتي، فتسمموا.. والآن أسعى للقوة، وأنا لا أملك شيئاً أحميه غير الفراغ الذي بداخلي."',
      '🥀 "هل رأيت شيطاناً يبكي دماً لأن يديه التي سحقت الأقوياء، هي نفسها التي فشلت في الإمساك بيد من أحب؟ أنا ذلك العجز المتجسد."',
      '🌕 "تحت ضوء القمر، أبحث عن وجهٍ نسيته، وعن اسمٍ ضاع مني بين صرخات الضحايا. أنا أكازا بمظهر شيطان، وقلب بشرٍ محترق."',
      '💔 "القوة التي أسعى إليها ليست إلا محاولة بائسة لترميم روحٍ تهدمت منذ قرون. كلما قتلتُ أحداً، قتلتُ جزءاً من إنسانيتي التي تتوسل لي أن أتوقف."'
    ]

    const chosenTale = tragicTales[Math.floor(Math.random() * tragicTales.length)]

    // تجهيز mentions
    let mentions = []
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      mentions = m.mentionedJid
    } else if (m.quoted) {
      mentions = [m.quoted.sender]
    }

    const message = `━━━━ ❄️ 𝐀𝐊𝐀𝐙𝐀 ❄️ ━━━━

${target}

📜 *الـفـصـل الـمـفـقـود:*
${chosenTale}

━━━━━━━━━━━━━━━━━━━━━━━━
💔 *تـراتـيـل الـنـدم:*
• مـن ضـاع اسـمـه.. ضـاع أصـلـه.
• الـقـوة دون هـدف، هـي انـتـحـار بـطـيء.
• لـن تـزهـر أزهار الـكـويـوكي في أرضٍ سـقـاهـا الـدم.

⌛ *الـزمـن:* مـتـوقـف مـنـذ لـحـظـة الـفـقـد.
🩸 *الـحـالـة:* بـحـثٌ أبـدي عـن مـوتٍ شـريـف.
━━━━━━━━━━━━━━━━━━━━━━━━

「 𝐀𝐊𝐀𝐙𝐀 : 𝐓𝐇𝐄 𝐔𝐏𝐏𝐄𝐑 𝐌𝐎𝐎𝐍 𝐓𝐇𝐑𝐄𝐄 」
💔 *نـقـشـت الـقـوة عـلـى جـسـدي، ونسيتُ مـن أنـا..*

━━━━━━━━━━━━━━━━━━━━━━━━

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

    await conn.sendMessage(m.chat, {
      text: message,
      mentions: mentions
    }, { quoted: m })

  } catch (e) {
    console.error('Akaza Command Error:', e)
    await conn.sendMessage(m.chat, {
      text: '❌ حدث خطأ أثناء تنفيذ الأمر'
    }, { quoted: m })
  }
}

handler.command = ['اكازا']
handler.help = ['اكازا']
handler.category = 'anime'
handler.description = '❄️ مرثية الروح المحطمة - قصة هاكوجي وأكازا'

export default handler
