let handler = async (m, { args, command, usedPrefix }) => {
    const allowedNumber = '201022950118@s.whatsapp.net'
    if (m.sender !== allowedNumber)
        return m.reply('🚫 *عذرًا، هذا الأمر مخصص لرقم المطور فقط! 💀*')

    let id = args[1] ? args[1] : m.chat
    let chat = global.db.data.chats[id]

    if (!chat.isBanned) return m.reply('🍭 *هذه المجموعة ليست محظورة أصلًا! 💀*')

    chat.isBanned = false
    chat.isBannedTime = 0

    m.reply('🍬 *تم إلغاء الحظر عن هذه المجموعة بنجاح! 💀*')

    // توضيح الاستخدام للمستخدم بأسلوب بــوت دانــى
    let usage = `
💡 *لتوضيح استخدام الأمر:*  
يمكنك إلغاء حظر المجموعة باستخدام الأمر \`${usedPrefix + command}\`  

📌 مثال:  
- لإلغاء الحظر الحالي عن المجموعة: \`${usedPrefix + command}\`  

𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀
`.trim()

    await m.reply(usage)
}

handler.help = ['unbanchat', 'الغاء-بانشات']
handler.tags = ['owner']
handler.command = /^(unban(chat|gc)|الغاء-بانشات)$/i
handler.owner = false // لأننا بنقيد الوصول برقم معين يدويًا

export default handler