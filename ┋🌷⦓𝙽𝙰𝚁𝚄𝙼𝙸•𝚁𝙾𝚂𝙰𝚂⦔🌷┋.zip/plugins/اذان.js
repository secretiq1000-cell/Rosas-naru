import fetch from "node-fetch";

// =========================
// 🔹 المتغيرات الأساسية 🔹
// =========================
let autosholat = {};      // لمنع التكرار
let azanStatus = {};      // حالة الأذان لكل جروب
let azanSettings = {};    // إعدادات إضافية لكل جروب

// =======================
// 🔹 دوال مساعدة 🔹
// =======================
function formatTime(date) {
  return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;
}

// جلب بيانات الأذان من API
async function fetchAzanData(chatId) {
  try {
    const res = await fetch(`https://tyson-dev.vercel.app/api/azan?chat=${chatId}`);
    if (!res.ok) throw new Error(`خطأ في الاتصال: ${res.status}`);
    const data = await res.json();
    return data;
  } catch (e) {
    console.error("❌ خطأ في جلب بيانات الأذان:", e);
    return null;
  }
}

// الحصول على الوقت الحالي بتوقيت مصر
function getCurrentEgyptTime() {
  return new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Cairo" }));
}

// ✅ دالة غلق الجروب (منع الأعضاء من الكتابة)
async function lockGroup(conn, chatId) {
  try {
    await conn.groupSettingUpdate(chatId, 'announcement');
    console.log(`✅ تم غلق الجروب ${chatId} بنجاح`);
    return true;
  } catch (error) {
    console.error("❌ خطأ في غلق الجروب:", error);
    return false;
  }
}

// ✅ دالة فتح الجروب (السماح للأعضاء بالكتابة)
async function unlockGroup(conn, chatId) {
  try {
    await conn.groupSettingUpdate(chatId, 'not_announcement');
    console.log(`✅ تم فتح الجروب ${chatId} بنجاح`);
    return true;
  } catch (error) {
    console.error("❌ خطأ في فتح الجروب:", error);
    return false;
  }
}

// ===========================
// 🔹 المعالج الأساسي للأوامر 🔹
// ===========================
export async function before(m, { conn, groupMetadata }) {
  const chatId = m.chat;
  const text = m.text?.trim();

  // -------- قائمة الأوامر الرئيسية --------
  if (text === '.اذان') {
    const menu = `
🕌 *نظام الأذان التلقائي*

⚡ الأوامر المتاحة:

🔹 تشغيل النظام → .اذان-تشغيل
🔹 إيقاف النظام → .اذان-ايقاف
🔹 جدول الصلاة → .اذان-جدول
🔹 حالة النظام → .اذان-حالة

📖 للمساعدة: .اذان-مساعدة
    `.trim();
    return conn.sendMessage(chatId, { text: menu });
  }

  // -------- تفعيل الأذان --------
  if (text === '.اذان-تشغيل' || text === '.اذان-تفعيل') {
    if (!groupMetadata) return conn.sendMessage(chatId, { text: "❌ هذا الأمر يعمل في الجروبات فقط" });
    
    azanStatus[chatId] = true;
    azanSettings[chatId] = {
      enabled: true,
      lockGroup: true,
      lastCheck: null
    };
    
    return conn.sendMessage(chatId, { 
      text: "✅ *تم تفعيل نظام الأذان التلقائي*\n\n⏰ سيتم إرسال تنبيهات الأذان تلقائياً\n🔒 سيتم غلق الجروب أثناء الصلاة\n🔓 وسيتم فتحه بعد انتهاء الوقت المحدد" 
    });
  }

  // -------- إيقاف الأذان --------
  if (text === '.اذان-ايقاف') {
    // فتح الجروب قبل إيقاف النظام
    if (azanStatus[chatId]) {
      await unlockGroup(conn, chatId);
    }
    
    delete azanStatus[chatId];
    delete autosholat[chatId];
    delete azanSettings[chatId];
    
    return conn.sendMessage(chatId, { text: "⛔ *تم إيقاف نظام الأذان التلقائي*" });
  }

  // -------- جدول الصلاة --------
  if (text === '.اذان-جدول') {
    const apiData = await fetchAzanData(chatId);
    if (!apiData?.timings) return conn.sendMessage(chatId, { text: "❌ فشل في جلب جدول الصلاة\nيرجى المحاولة لاحقاً" });
    
    const t = apiData.timings;
    const table = `
📅 *جدول أوقات الصلاة اليوم*

🕋 الفجر: ${t.Fajr || '--:--'}
🌅 الشروق: ${t.Sunrise || '--:--'}
☀️ الظهر: ${t.Dhuhr || '--:--'}
🌤️ العصر: ${t.Asr || '--:--'}
🌇 المغرب: ${t.Maghrib || '--:--'}
🌙 العشاء: ${t.Isha || '--:--'}

📍 الموقع: ${apiData.city || 'غير محدد'}
    `.trim();
    return conn.sendMessage(chatId, { text: table });
  }

  // -------- حالة النظام --------
  if (text === '.اذان-حالة') {
    const status = azanStatus[chatId] ? '✅ مفعل' : '❌ غير مفعل';
    const settings = azanSettings[chatId] || {};
    
    const statusMessage = `
📊 *حالة نظام الأذان*

🔄 الحالة: ${status}
🔒 غلق الجروب أثناء الصلاة: ${settings.lockGroup ? '✅ مفعل' : '❌ غير مفعل'}
⏰ آخر تحديث: ${settings.lastCheck || 'لم يتم بعد'}
    `.trim();
    
    return conn.sendMessage(chatId, { text: statusMessage });
  }

  // -------- مساعدة --------
  if (text === '.اذان-مساعدة') {
    const help = `
🕌 *مساعدة نظام الأذان*

📖 *كيفية الاستخدام:*
1. قم بتفعيل النظام: .اذان-تشغيل
2. سيتم إرسال الأذان تلقائياً
3. الجروب سيغلق وقت الصلاة ويفتح بعدها
4. لإيقاف النظام: .اذان-ايقاف

⚙️ *المميزات:*
• إشعارات الأذان التلقائية
• غلق الجروب أثناء الصلاة
• فتح الجروب بعد انتهاء الوقت
• إرسال صوت الأذان

📞 للدعم: 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴 🐦
    `.trim();
    return conn.sendMessage(chatId, { text: help });
  }

  // ===========================
  // 🔹 نظام الأذان التلقائي 🔹
  // ===========================
  if (!azanStatus[chatId]) return;

  const date = getCurrentEgyptTime();
  const timeNow = formatTime(date);
  
  // منع التكرار في نفس الدقيقة
  if (autosholat[chatId]?.lastTime === timeNow) return;

  const apiData = await fetchAzanData(chatId);
  if (!apiData || apiData.status !== "أذان 🕌") return;

  // تحديث وقت آخر فحص
  if (azanSettings[chatId]) {
    azanSettings[chatId].lastCheck = timeNow;
  }

  autosholat[chatId] = { lastTime: timeNow };

  // استخدام الصوت
  const selectedAudio = apiData.audio || "https://files.catbox.moe/e543w9.m4a";

  try {
    // إرسال رسالة الأذان
    await conn.sendMessage(chatId, { 
      text: apiData.message || `🕌 حان الآن وقت أذان ${apiData.prayer || 'الصلاة'}\nالله أكبر الله أكبر` 
    });

    // إرسال صوت الأذان
    await conn.sendMessage(chatId, {
      audio: { url: selectedAudio },
      fileName: 'azan.m4a',
      mimetype: 'audio/mp4',
      ptt: true
    });

    // 🔒 غلق الجروب أثناء الصلاة
    if (apiData.lock_group && azanSettings[chatId]?.lockGroup !== false) {
      const locked = await lockGroup(conn, chatId);
      if (locked) {
        console.log(`🔒 تم غلق الجروب ${chatId} أثناء صلاة ${apiData.prayer}`);
      }
    }

    // 🔓 فتح الجروب بعد وقت محدد
    if (apiData.reopenMessage && apiData.unlock_group) {
      const lockDuration = (apiData.lock_duration || 15) * 60 * 1000; // 15 دقيقة
      
      setTimeout(async () => {
        try {
          const unlocked = await unlockGroup(conn, chatId);
          if (unlocked) {
            console.log(`🔓 تم فتح الجروب ${chatId} بعد صلاة ${apiData.prayer}`);
          }
          
          if (apiData.reopenMessage) {
            await conn.sendMessage(chatId, { text: apiData.reopenMessage });
          }
        } catch (e) {
          console.error("❌ خطأ في فتح الجروب:", e);
        }
      }, lockDuration);
    }

    console.log(`✅ [أذان] تم إرسال أذان ${apiData.prayer} إلى ${chatId}`);

  } catch (error) {
    console.error("❌ خطأ في إرسال الأذان:", error);
    await conn.sendMessage(chatId, { 
      text: "❌ حدث خطأ في إرسال تنبيه الأذان" 
    });
  }
}

// ===========================
// 🔹 التصدير 🔹
// ===========================
export const azanSystem = {
  status: azanStatus,
  settings: azanSettings,
  autosholat: autosholat
};
