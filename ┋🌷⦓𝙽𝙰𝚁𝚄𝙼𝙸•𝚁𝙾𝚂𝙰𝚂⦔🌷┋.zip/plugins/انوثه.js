// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

let handler = async (m, { conn }) => {
  let targetJid

  // جلب الشخص المذكور أو المرسل نفسه
  if (m.mentionedJid && m.mentionedJid.length > 0) {
    targetJid = m.mentionedJid[0]
  } else if (m.quoted) {
    targetJid = m.quoted.sender
  } else {
    targetJid = m.sender
  }

  const percentage = Math.floor(Math.random() * 101)
  const targetId = targetJid.split('@')[0]

  // رسائل حسب النسبة
  let comment = ''
  if (percentage >= 80) comment = '🌸 أنتِ الملكة! دلال لا يُقاوم!'
  else if (percentage >= 60) comment = '💖 أنوثة عالية، استمري!'
  else if (percentage >= 40) comment = '🌷 أنوثة متوسطة، في تطور!'
  else if (percentage >= 20) comment = '🌱 أنوثة بسيطة، تحتاج رعاية!'
  else comment = '🪨 تحتاجين تمرين أنوثة! 😂'

  const message = `💃 *نسبة الأنوثة* 💃

━━━━━━━━━━━━━━━━━━━━
👤 المستخدم: *@${targetId}*
💗 النسبة: *${percentage}%*

✨ ${comment}
━━━━━━━━━━━━━━━━━━━━

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

  await conn.sendMessage(m.chat, {
    text: message,
    mentions: [targetJid]
  }, { quoted: m })
}

handler.command = ['انوثه', 'انوثة', 'انوثة']
handler.help = ['انوثه']
handler.category = 'ترفيه'
handler.description = '💃 نسبة الأنوثة لك أو لصديقك'

export default handler
