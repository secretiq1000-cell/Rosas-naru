import axios from 'axios';

// --- وظيفة جلب الرد من سمسمي ---
async function getSimSimiResponse(query) {
    try {
        const url = 'https://kube-appserver.simsimi.com:30443/simtalk/get_talk_set';
        
        const headers = {
            'Host': 'kube-appserver.simsimi.com:30443',
            'User-Agent': 'okhttp/4.10.0',
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/json',
            'os': 'a',
            'av': '9.1.2',
            // تنبيه: x-signature قد يتغير ويحتاج لتحديث دوري إذا كان مرتبطاً بالوقت
            'x-signature': 'fb660fe0943ac99e8fe9dfbacaecf714810c6ac0ea7c7c2addd239b1aac772c9'
        };

        const data = {
            "uid": 509271565,
            "av": "9.1.2",
            "os": "a",
            "lc": "ar", // اللغة العربية
            "cc": "MA", // الدولة (المغرب في هذا المثال)
            "tz": "Africa/Casablanca",
            "cv": "",
            "message": query,
            "free_level": 4,
            "logUID": "509271565",
            "reg_now_days": 0
        };

        const response = await axios.post(url, data, { headers });

        // تحليل المفاتيح بناءً على استجابة السيرفر المتوقعة
        // عادة ما يكون الرد في حقل 'sentence' أو 'talk_set'
        if (response.data && response.data.talk_set) {
            return response.data.talk_set[0].content; 
        } else if (response.data && response.data.sentence) {
            return response.data.sentence;
        }
        
        return "🔹 لم يستطع سمسمي العثور على رد مناسب في ذاكرته..";
        
    } catch (error) {
        console.error('SimSimi API Error:', error.response ? error.response.data : error.message);
        throw new Error("فشل الاتصال بسيرفرات سمسمي.. ربما تم كشف التوقيع!");
    }
}

// --- Handler البوت ---

let handler = async (m, { conn, text }) => {
    try {
        if (!text) {
            return conn.reply(
                m.chat,
                `*⎔ ⋅ ───━ •﹝🔹﹞• ━─── ⋅ ⎔*\n` +
                `*مساعد سمسمي الأصلي:*\n\n` +
                `🤖 *الاستخدام:*\n.سمسمي <رسالتك>\n\n` +
                `📌 *ملاحظة:* هذا الكود يستخدم بروتوكول التطبيق الرسمي.\n` +
                `*⎔ ⋅ ───━ •﹝🔹﹞• ━─── ⋅ ⎔*`,
                m
            );
        }

        await conn.sendPresenceUpdate('composing', m.chat);

        const reply = await getSimSimiResponse(text);
        
        await conn.reply(m.chat, reply, m);

    } catch (error) {
        await conn.reply(m.chat, `🔹 خطأ: ${error.message}`, m);
    }
};

handler.help = ['سمسم'];
handler.tags = ['ai'];
handler.command = /^(سمسم|simsimi)$/i;

export default handler;