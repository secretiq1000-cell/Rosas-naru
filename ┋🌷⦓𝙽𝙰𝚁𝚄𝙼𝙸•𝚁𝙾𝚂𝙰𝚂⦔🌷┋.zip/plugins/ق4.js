let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let name = conn.getName(m.sender) || 'مستخدم';
  let taguser = '@' + m.sender.split("@")[0];

  let currentTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

  let groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
  let groupName = groupMetadata ? groupMetadata.subject : 'غير معروف';
  let groupMembers = groupMetadata ? groupMetadata.participants.length : 'غير معروف';

  let message = `
╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊${taguser}⌉
── • ◈ • ──
*⌝📦┊قــســم التحميل┊📦⌞* 
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹🍷›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
┤┌ ─๋︩︪─✦ *𝑫𝑨𝑵𝑵𝒀* ─˚᳝᳝𖥻
> │┊ ۬.͜ـ📦˖ ⟨بحث-جيتهاب☇

> │┊ ۬.͜ـ📦˖ ⟨جيتهاب☇ 

> │┊ ۬.͜ـ📦˖ ⟨ميجا☇

> │┊ ۬.͜ـ📦˖ ⟨احضر☇

> │┊ ۬.͜ـ📦˖ ⟨احضر2☇

> │┊ ۬.͜ـ📦˖ ⟨احضر3☇

> │┊ ۬.͜ـ📦˖ ⟨جوجل☇

> │┊ ۬.͜ـ📦˖ ⟨شغـل☇

> │┊ ۬.͜ـ📦˖ ⟨ميديا_فاير☇

> │┊ ۬.͜ـ📦˖ ⟨تويتر☇

> │┊ ۬.͜ـ📦˖ ⟨بحث-تيكتوك☇

> │┊ ۬.͜ـ📦˖ ⟨تـيك☇

> │┊ ۬.͜ـ📦˖ ⟨تـيك2☇ 

> │┊ ۬.͜ـ📦˖ ⟨تيك-صوت☇ 

> │┊ ۬.͜ـ📦˖ ⟨يوتيوب☇

> │┊ ۬.͜ـ📦˖ ⟨فـيـديـو☇

> │┊ ۬.͜ـ📦˖ ⟨فـيديو2☇

> │┊ ۬.͜ـ📦˖ ⟨فـيديو3☇ 

> │┊ ۬.͜ـ📦˖ ⟨اغنيـه☇

> │┊ ۬.͜ـ📦˖ ⟨اغنـية☇

> │┊ ۬.͜ـ📦˖ ⟨صــوت☇

> │┊ ۬.͜ـ📦˖ ⟨انستا☇

> │┊ ۬.͜ـ📦˖ ⟨تيكتوك☇

> │┊ ۬.͜ـ📦˖ ⟨فيس☇

> │┊ ۬.͜ـ📦˖ ⟨فيس2☇

> │┊ ۬.͜ـ📦˖ ⟨اغنيه-اديت☇

> │┊ ۬.͜ـ📦˖ ⟨فيديو-اديت☇ 

> │┊ ۬.͜ـ📦˖ ⟨تطـبيق☇ 

> │┊ ۬.͜ـ📦˖ ⟨مـود☇ 

> │┊ ۬.͜ـ📦˖ ⟨اapk☇

> │┊ ۬.͜ـ📦˖ ⟨تيرابوكس☇

> │┊ ۬.͜ـ📦˖ ⟨اهـداف☇ 

> │┊ ۬.͜ـ📦˖ ⟨رونـالدو☇ 

> │┊ ۬.͜ـ📦˖ ⟨انـمي☇ 

> │┊ ۬.͜ـ📦˖ ⟨ايـديـت☇

> │┊ ۬.͜ـ📦˖ ⟨ويـتـشـر☇ 

> │┊ ۬.͜ـ📦˖ ⟨شيلات-حزينه☇ 

> │┊ ۬.͜ـ📦˖ ⟨حالات-انمي☇

> │┊ ۬.͜ـ📦˖ ⟨حالات-المومري☇ 

> │┊ ۬.͜ـ📦˖ ⟨حالات-بهجت-صابر☇ 

┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈─๋︩︪─═⊐<🧧𝑫𝑨𝑵𝑵𝒀🧧›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ  `;

  const emojiReaction ='📦';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    await conn.sendMessage(m.chat, { 
      image: { url: 'https://i.postimg.cc/SNG4nnZ3/IMG-20251230-WA0080.jpg' },
      caption: message,
      mentions: [m.sender]
    });
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق4)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;
