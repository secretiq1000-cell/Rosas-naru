import { generateWAMessageFromContent } from '@whiskeysockets/baileys'

const handler = async (m, { conn, text, participants, isOwner, isAdmin, args, command }) => {
  if (!isAdmin && !isOwner)
    return m.reply('💀 *لازم تكون ادمن عشان تستخدم الأمر ي ابني*')

  const pesan = args.join` `
  let oi = `*» رسالة الإشعار :* ${pesan}`

  let commandTitle = ''
  switch (command) {
    case 'todos':
    case 'منشن':
    case 'tagall':
      commandTitle = 'إشعار جماعي⚡'
      break
    case 'invocar':
    case 'استدعاء':
      commandTitle = 'استدعاء الجميع 📢'
      break
    default:
      commandTitle = 'منشن عام 👻'
  }

  if (!pesan)
    oi = `*» ${commandTitle} :* لايوجد رسالة محددة`

  // ═══════ زخرفة فخمة ═══════

  let teks = `╭•─•𓆩 ✦ ${commandTitle} ✦ 𓆪•─•╮\n`
  teks += `│\n`
  teks += `│ 👑 مــرحــبـاً بالجميــع\n`
  teks += `│\n`
  teks += `│ 📊 الأعـضـاء : ${participants.length}\n`
  teks += `│\n`
  teks += `├•─•─•─•─•─•─•─•─•─•─•\n`

  for (const mem of participants) {
    const jid = conn.decodeJid(mem.id)
    teks += `│ ⌬ @${jid.split('@')[0]}\n`
  }

  teks += `│\n`
  teks += `│ ⚡ تم إستدعاء جميع الأعضاء\n`
  teks += `│\n`
  teks += `╰•𓆩 ✦ 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 ✦ 𓆪•─╯`

  let fakegif = {
    key: {
      participant: `0@s.whatsapp.net`,
      ...( "6289643739077-1613049930@g.us"
        ? { remoteJid: "6289643739077-1613049930@g.us" }
        : {})
    },
    message: {
      videoMessage: {
        title: '𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟮 📮 ✰',
        h: 'Hmm',
        seconds: '99999',
        gifPlayback: true,
        caption: '🧬𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟮❄️⃨፝⃕✰',
        jpegThumbnail: false
      }
    }
  }

  let users = participants.map(u => conn.decodeJid(u.id))

  let msg = conn.cMod(
    m.chat,
    generateWAMessageFromContent(
      m.chat,
      {
        extendedTextMessage: { text: teks }
      },
      {
        quoted: fakegif,
        userJid: conn.user.id
      }
    ),
    teks,
    conn.user.jid,
    { mentions: users }
  )

  await conn.relayMessage(
    m.chat,
    msg.message,
    { messageId: msg.key.id }
  )
}

handler.help = ['todos', 'منشن', 'invocar', 'استدعاء', 'tagall', 'مخفي']
handler.tags = ['group']
handler.command = ['todos', 'منشن', 'invocar', 'استدعاء', 'tagall', 'مخفي']
handler.admin = true
handler.group = true

export default handler