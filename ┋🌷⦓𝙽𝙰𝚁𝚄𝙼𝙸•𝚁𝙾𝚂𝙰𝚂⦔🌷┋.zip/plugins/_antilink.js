// روابط الجروبات + القنوات
const linkRegex = /(chat\.whatsapp\.com\/[0-9A-Za-z]{20,24})|(https:\/\/whatsapp\.com\/channel\/[0-9A-Za-z]{20,24})/i;

// رابط مسموح
const allowedLinks = [
  'https://whatsapp.com/channel/0029Vb6hPGJ3bbVCjW2W6D2p'
];

export async function before(m, { conn, isAdmin, isBotAdmin }) {
  try {
    if (!m.isGroup) return;
    if (!m.text) return;

    const chat = global.db.data.chats[m.chat];
    if (!chat.antiLink) return; // إذا كان antilink غير مفعل

    const text = m.text;

    const isGroupLink = /chat\.whatsapp\.com\//i.test(text);
    const isChannelLink = /whatsapp\.com\/channel\//i.test(text);

    // لو الرابط مسموح
    if (allowedLinks.some(link => text.includes(link))) return;

    // لو الأدمن – تجاهل
    if (isAdmin) return;

    // لو مفيش أنتلينك – خروج
    if (!isGroupLink && !isChannelLink) return;

    // تحقق من رابط الجروب الحالي (لا تعاقب المرسل)
    if (isGroupLink) {
      const currentGroupLink = `https://chat.whatsapp.com/${await conn.groupInviteCode(m.chat)}`;
      if (text.includes(currentGroupLink)) return;
    }

    // يجب أن يكون البوت أدمن
    if (!isBotAdmin) {
      return await conn.reply(m.chat, "*❍╎🧸┊ ارفـعـنـي ادمـن عـشـان انـفـذ مـنـع الـروابـط*", m);
    }

    // حذف الرسالة
    await conn.sendMessage(
      m.chat,
      {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: m.key.id,
          participant: m.sender
        }
      }
    );

    // طرد العضو
    await conn.reply(
      m.chat,
      `❍╎🧸┊ اتـحـذفـت عـشـانـك عـبـد ${isChannelLink ? "قناة" : "جروب"}.\nانـطـر ابـلـكـاش 🔽`,
      m
    );

    await conn.groupParticipantsUpdate(m.chat, [m.sender], "remove");

  } catch (e) {
    console.log("AntiLink Error:", e);
  }
}
