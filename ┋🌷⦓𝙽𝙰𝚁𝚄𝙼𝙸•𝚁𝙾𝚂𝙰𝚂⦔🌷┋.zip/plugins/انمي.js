// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios'

async function translateToArabic(text) {
    try {
        const res = await axios.get('https://translate.googleapis.com/translate_a/single', {
            params: {
                client: 'gtx',
                sl: 'en',
                tl: 'ar',
                dt: 't',
                q: text
            }
        })

        const translated = res.data[0].map(part => part[0]).join('')
        return translated
    } catch (e) {
        console.error('فشل الترجمة:', e.message)
        return text
    }
}

let handler = async (m, { conn, text }) => {
    const query = text.trim()

    if (!query) {
        return await conn.sendMessage(m.chat, {
            text: '❗ *الرجاء كتابة اسم الأنمي*\n\nمثال: .انمي Naruto\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐'
        }, { quoted: m })
    }

    try {
        const res = await axios.get(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(query)}&limit=1`)
        const data = res.data.data

        if (!data || data.length === 0) {
            return await conn.sendMessage(m.chat, {
                text: `❌ *لم يتم العثور على نتائج* للأنمي "${query}".\n\nجرب اسم آخر بالياباني أو الإنجليزي.`
            }, { quoted: m })
        }

        const anime = data[0]
        const translatedSynopsis = await translateToArabic(anime.synopsis || 'لا يوجد وصف متاح')

        const info = `📺 *الاسم:* ${anime.title}\n` +
                     `📝 *الوصف:* ${translatedSynopsis.substring(0, 500)}${translatedSynopsis.length > 500 ? '...' : ''}\n` +
                     `📅 *تاريخ العرض:* ${anime.aired?.string || 'غير معروف'}\n` +
                     `🎭 *النوع:* ${anime.type || 'غير معروف'}\n` +
                     `⭐ *التقييم:* ${anime.score || 'لا يوجد'}\n` +
                     `🎯 *التصنيف:* ${anime.rating || 'غير مصنف'}\n` +
                     `🔗 *الرابط:* ${anime.url}\n\n` +
                     `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

        await conn.sendMessage(m.chat, {
            image: { url: anime.images.jpg.image_url },
            caption: info
        }, { quoted: m })

    } catch (error) {
        console.error('خطأ أثناء جلب الأنمي:', error.message)
        
        let errorMsg = '❌ *حدث خطأ أثناء جلب بيانات الأنمي*\n\n'
        if (error.response?.status === 429) {
            errorMsg += '⏳ الطلب كثير جداً. انتظر قليلاً ثم حاول مرة أخرى.'
        } else if (error.response?.status === 404) {
            errorMsg += '🔍 الأنمي غير موجود. تأكد من الاسم.'
        } else {
            errorMsg += `📛 ${error.message}`
        }
        
        await conn.sendMessage(m.chat, {
            text: errorMsg
        }, { quoted: m })
    }
}

handler.command = ['انمي', 'anime', 'انيمي']
handler.help = ['انمي']
handler.category = 'معلومات'
handler.description = '📺 يعرض معلومات أنمي باللغة العربية'

export default handler
