import fs from 'fs'
import path from 'path'

let handler = async (m, { text, conn }) => {
  const devNumbers = ['201553801908', '201044689315'] // ✅ مصفوفة

  let senderNumber = m.sender.split('@')[0]
  if (!devNumbers.includes(senderNumber)) {
    return m.reply('❌ هذا الأمر للمطور فقط')
  }

  if (!text) return m.reply('*❍╎🧸┊ اكتب الأمر بالشكل الصحيح:\nبدل الكود_القديم|الكود_الجديد*')

  text = text.trim()
  let separatorIndex = text.indexOf('|')
  if (separatorIndex === -1) return m.reply('*❍╎🧸┊ استخدم "|" للفصل بين الكود القديم والكود الجديد*')

  let oldCode = text.slice(0, separatorIndex).trim()
  let newCode = text.slice(separatorIndex + 1).trim()

  if (!oldCode || !newCode) return m.reply('*❍╎🧸┊ يجب كتابة الكود القديم والكود الجديد بشكل صحيح*')

  let folderPath = './plugins'

  try {
    let extensions = ['.js', '.ts', '.json']
    let files = fs.readdirSync(folderPath).filter(file =>
      extensions.includes(path.extname(file))
    )

    let changedFiles = []

    for (let file of files) {
      let filePath = path.join(folderPath, file)
      let content = fs.readFileSync(filePath, 'utf8')

      if (content.includes(oldCode)) {
        let newContent = content.split(oldCode).join(newCode)
        fs.writeFileSync(filePath, newContent, 'utf8')
        changedFiles.push(file)
      }
    }

    if (changedFiles.length > 0) {
      m.reply(`❍╎🌷┊ تـم اسـتـبـدال "${oldCode}" بـ "${newCode}" في:\n📄 ${changedFiles.join('\n📄 ')}`)
    } else {
      m.reply(`🔍 لم يتم العثور على "${oldCode}" في أي ملف.`)
    }

  } catch (err) {
    console.error(err)
    m.reply('❌ حصل خطأ أثناء محاولة التبديل:\n' + err.message)
  }
}

handler.command = /^بدل$/i
export default handler