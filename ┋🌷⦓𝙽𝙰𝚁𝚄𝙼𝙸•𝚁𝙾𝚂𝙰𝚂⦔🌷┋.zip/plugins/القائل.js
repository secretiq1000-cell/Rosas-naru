// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent, proto } = pkg;

const quotes = [
  {
    level: 1,
    quote: "🗣️ *العدالة ستسود في النهاية، حتى إن تأخرت.*",
    options: ['ناروتو', 'لوفي', 'كاكاشي', 'إيروين'],
    answer: 'إيروين',
  },
  {
    level: 2,
    quote: "🗣️ *لا توجد طريقة مختصرة لتحقيق الحلم.*",
    options: ['تانجيرو', 'ميناتو', 'إيتاتشي', 'إدوارد'],
    answer: 'إيتاتشي',
  },
  {
    level: 3,
    quote: "🗣️ *أنا سأصبح ملك القراصنة!*",
    options: ['زورو', 'لوفي', 'شانكس', 'غول دي روجر'],
    answer: 'لوفي',
  },
  {
    level: 4,
    quote: "🗣️ *الخوف هو العدو الحقيقي.*",
    options: ['هيسوكا', 'كورابيكا', 'كاكاشي', 'جارا'],
    answer: 'كاكاشي',
  },
  {
    level: 5,
    quote: "🗣️ *لا تتراجع عن كلامك، هذه هي طريقتي في النينجا!*",
    options: ['ناروتو', 'ساسكي', 'ساكورا', 'مادارا'],
    answer: 'ناروتو',
  }
];

let handler = async function (m, { text, conn }) {
  if (!conn.quoteGames) conn.quoteGames = {};
  const sessionKey = `${m.chat}-${m.sender}`;
  const session = conn.quoteGames[sessionKey];

  // عرض الأزرار الرئيسية إذا لم يوجد نص
  if (!text) {
    const buttons = [
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "🎮 بدء اللعبة", id: ".القائل ابدا" }),
      },
      {
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({ display_text: "📘 المساعدة", id: ".القائل مساعدة" }),
      },
    ];

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: "🎤 هل تريد بدء لعبة *من القائل؟* 🎤",
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: "اختر أحد الخيارات التالية:",
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false,
                title: "🎮 لعبة من القائل؟ 🎮\n\n BY: 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴 ❄",
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons,
              }),
            }),
          },
        },
      },
      {}
    );

    return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  }

  // المساعدة
  if (text === "مساعدة") {
    return m.reply(`📘 *شرح لعبة من القائل؟* 🎤\n\n🎮 .القائل ابدا → بدء اللعبة\n✅ اختر الإجابة الصحيحة من الأزرار\n🏆 كل إجابة صحيحة = 5 نقاط\n📊 5 مستويات مختلفة\n\n✨ استمتع باللعبة!`);
  }

  // بدء اللعبة
  if (text === "ابدا") {
    if (session) {
      return m.reply("⚠️ لديك لعبة نشطة حالياً! أكملها أولاً.");
    }
    
    conn.quoteGames[sessionKey] = {
      currentIndex: 0,
      score: 0,
      startedAt: Date.now()
    };
    
    return await sendQuestion(m.chat, conn.quoteGames[sessionKey], m, conn);
  }

  // معالجة الإجابات
  const validAnswers = quotes.flatMap(q => q.options);
  
  if (validAnswers.includes(text)) {
    if (!session) return m.reply("⚠️ لا توجد لعبة نشطة! ابدأ لعبة جديدة بـ .القائل ابدا");
    
    const currentQuote = quotes[session.currentIndex];
    
    if (text === currentQuote.answer) {
      // إجابة صحيحة
      session.score += 5;
      session.currentIndex++;
      
      if (session.currentIndex >= quotes.length) {
        // انتهت اللعبة
        delete conn.quoteGames[sessionKey];
        return m.reply(`🎉 *تهانينا!* 🎉\n\nلقد أكملت اللعبة!\n🏆 نتيجتك النهائية: *${session.score}* نقطة\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`);
      }
      
      await m.reply(`✅ *إجابة صحيحة!*\n⭐ نقاطك الحالية: *${session.score}*\n\n⏳ جاري الانتقال إلى السؤال التالي...`);
      
      setTimeout(async () => {
        await sendQuestion(m.chat, session, m, conn);
      }, 2000);
      
    } else {
      // إجابة خاطئة
      delete conn.quoteGames[sessionKey];
      return m.reply(`❌ *إجابة خاطئة!*\n\nالإجابة الصحيحة كانت: *${currentQuote.answer}*\n🏆 نتيجتك النهائية: *${session.score}* نقطة\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`);
    }
    return;
  }
  
  if (text === "حذف") {
    if (!session) return m.reply("⚠️ لا توجد لعبة نشطة");
    delete conn.quoteGames[sessionKey];
    return m.reply("✅ تم حذف الجلسة بنجاح");
  }
  
  return m.reply(`⚠️ أمر غير معروف. استخدم .القائل مساعدة للأوامر.`);
};

async function sendQuestion(jid, session, m, conn) {
  const currentQuote = quotes[session.currentIndex];
  
  // بناء أزرار الخيارات
  const buttons = currentQuote.options.map((opt, idx) => ({
    name: "quick_reply",
    buttonParamsJson: JSON.stringify({ display_text: `${idx + 1}. ${opt}`, id: `.القائل ${opt}` }),
  }));
  
  // إضافة زر حذف الجلسة
  buttons.push({
    name: "quick_reply",
    buttonParamsJson: JSON.stringify({ display_text: "🗑️ إنهاء اللعبة", id: ".القائل حذف" }),
  });
  
  const questionText = `
╭━━━━━━━━━━━━━━━━━━━━╮
      🎮 *من القائل؟* 🎮
╰━━━━━━━━━━━━━━━━━━━━╯

${currentQuote.quote}

━━━━━━━━━━━━━━━━━━━━
📊 *المستوى:* ${session.currentIndex + 1}/${quotes.length}
⭐ *نقاطك:* ${session.score}
━━━━━━━━━━━━━━━━━━━━`

  try {
    const msg = generateWAMessageFromContent(
      jid,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({
                text: questionText,
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
                text: "✍️ اختر الإجابة الصحيحة:",
              }),
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: false,
                title: "🎤 لعبة من القائل؟ 🎤",
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons,
              }),
            }),
          },
        },
      },
      {}
    );

    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id });
  } catch (e) {
    console.error('خطأ إرسال السؤال:', e);
    // طريقة بديلة بدون أزرار
    let text = `${questionText}\n\n📌 الخيارات:\n`;
    currentQuote.options.forEach((opt, idx) => {
      text += `${idx + 1}. ${opt}\n`;
    });
    text += `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`;
    await conn.sendMessage(jid, { text }, { quoted: m });
  }
}

handler.command = /^القائل$/i;
export default handler;
