let handler = async (m, { conn, command, text }) => {
    let user = global.db.data.users[m.sender];
    if (!user) {
        user = global.db.data.users[m.sender] = {};
    }

    const startGame = async () => {
        const numbers = [5, 7, 9, 12, 15];
        const randomNumber = numbers[Math.floor(Math.random() * numbers.length)];
        const answer = randomNumber * 2;

        user.mathGame = {
            number: randomNumber,
            answer: answer,
            attempts: 0,
            maxAttempts: 3,
            started: true
        };

        const infoText = `
🧮 *لعبة احسب* 🧮

❓ احسب الناتج:
━━━━━━━━━━━━━━━━━
📌 *${randomNumber} × 2*
━━━━━━━━━━━━━━━━━

📝 لديك 3 محاولات
✨ أرسل إجابتك باستخدام: *حل [الرقم]*

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`;
        
        await conn.reply(m.chat, infoText, m);
    };

    const endGame = async (guess) => {
        let game = user.mathGame;
        if (!game || !game.started) {
            return conn.reply(m.chat, '❌ لا توجد لعبة جارية حالياً.\nابدأ لعبة جديدة باستخدام الأمر: *احسب*', m);
        }

        guess = parseInt(guess);
        if (isNaN(guess)) {
            return conn.reply(m.chat, '❌ يرجى إدخال رقم صحيح.\nمثال: *حل 10*', m);
        }

        game.attempts++;

        if (guess === game.answer) {
            user.exp = (user.exp || 0) + 50;
            user.money = (user.money || 0) + 500;
            await conn.reply(m.chat, `🎉 *تهانينا!* 🎉\n\n✅ لقد أجبت بشكل صحيح!\n📌 الرقم كان: ${game.number} × 2 = ${game.answer}\n\n🏆 ربحت:\n⭐ 50 نقطة خبرة (XP)\n💰 500 عملة\n\n🔄 اكتب *احسب* للعب مرة أخرى`, m);
            user.mathGame = {};
        } else if (game.attempts >= game.maxAttempts) {
            await conn.reply(m.chat, `❌ *لقد انتهت محاولاتك!*\n\n📌 الرقم الصحيح كان: ${game.number} × 2 = ${game.answer}\n\n🔄 اكتب *احسب* للعب مرة أخرى`, m);
            user.mathGame = {};
        } else {
            let remaining = game.maxAttempts - game.attempts;
            await conn.reply(m.chat, `❌ *إجابة خاطئة!*\n\n📝 إجابتك: ${guess}\n✅ الإجابة الصحيحة: ${game.answer}\n\n💢 تبقت لديك ${remaining} محاولات\n🔄 حاول مرة أخرى باستخدام: *حل [الرقم]*`, m);
        }
    };

    const showHelp = async () => {
        const helpMessage = `
🌟 *شرح لعبة احسب* 🌟

1. *بدء اللعبة*: 
   - استخدم الأمر *احسب* لبدء اللعبة.
   - ستظهر لك مسألة حسابية بسيطة.

2. *الحل*:
   - استخدم الأمر *حل [الرقم]* لإدخال إجابتك.
   - مثال: *حل 10*

3. *الجوائز*:
   - ✅ إجابة صحيحة: 50 XP + 500 عملة
   - ❌ إجابة خاطئة: تنقص محاولاتك

4. *المحاولات*:
   - لديك 3 محاولات فقط لكل لعبة

📝 *الأوامر*:
• *احسب* - بدء لعبة جديدة
• *حل [رقم]* - إرسال إجابتك
• *شرح_احسب* - عرض هذا الشرح

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`;
        
        await conn.reply(m.chat, helpMessage, m);
    };

    // التحقق من الأوامر المستخدمة
    if (command === 'احسب') {
        if (user.mathGame?.started) {
            return conn.reply(m.chat, '⚠️ لديك لعبة نشطة حالياً!\nأرسل إجابتك باستخدام: *حل [الرقم]*', m);
        }
        await startGame();
    } else if (command === 'حل') {
        await endGame(text.trim());
    } else if (command === 'شرح_احسب') {
        await showHelp();
    }
};

handler.help = ['احسب', 'حل [رقم]', 'شرح_احسب'];
handler.tags = ['game'];
handler.command = ['احسب', 'حل', 'شرح_احسب'];

export default handler;
