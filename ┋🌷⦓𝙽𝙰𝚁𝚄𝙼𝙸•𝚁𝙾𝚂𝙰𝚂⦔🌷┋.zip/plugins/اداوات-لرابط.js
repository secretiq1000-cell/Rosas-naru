import fs from 'fs';
import axios from 'axios';
import fetch from 'node-fetch';
import FormData from 'form-data';
import { fileTypeFromBuffer } from 'file-type';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m;
  const mime = (q.msg || q).mimetype || '';

  if (!mime) throw '*❲ 💡 ❳ يرجى تحديد الملف الذي تود تحويله لرابط .*\n> مثال: ' + usedPrefix + command + ' ريبلي الملف';

  const media = await q.download();
  const { ext, mime: fileMime } = await fileTypeFromBuffer(media);
  const fileType = fileMime.split('/')[0];

  if (!text) {
    throw '*❲ 💡 ❳ يرجى تحديد الخيار الذي تريد استعماله للرفع .*\n' +
    '*❱ الخيارات المتاحة:*\n' +
    '1 - Gofile\n' +
    '2 - File.io\n' +
    '3 - Imgbb (صور فقط - يحتاج API)\n' +
    '4 - Quax\n' +
    '5 - Ezgif (صور فقط)\n' +
    '6 - Uguu\n' +
    '7 - Catbox\n' +
    '8 - Catbox\n' +
    '9 - Telegraph (صور فقط)\n' +
    '\n📌 *مثال:* *.لرابط 3*';
  }

  let link;
  switch (text) {
    case '1': link = await uploadToGofile(media, ext); break;
    case '2': link = await uploadToFileio(media, ext); break;
    case '3':
      if (!/image/.test(mime)) throw '*❲ ❗ ❳ يرجى تحديد صور فقط .*';
      link = await uploadToImgbb(media);
      break;
    case '4': link = await uploadToQuax(media, ext); break;
    case '5':
      if (!/image/.test(mime)) throw '*❲ ❗ ❳ يرجى تحديد صور فقط .*';
      link = await uploadToEzgif(media);
      break;
    case '6': link = await uploadToUguu(media, ext); break;
    case '7': link = await uploadToCatbox(media, ext); break;  
    case '8': link = await uploadToCatbox(media, ext); break;
    case '9':
      if (!/image/.test(mime)) throw '*❲ ❗ ❳ Telegraph يقبل صور فقط .*';
      link = await uploadToTelegraph(media, ext);
      break;
    default: throw '*❲ 💡 ❳ حدد الخيار الصحيح من القائمة .*';
  }

  let cap = '🧞 *⎆─┈┈〔 معلومات الملف 〕─┈⌲*\n\n';
  cap += '📂 *الاسم:* ' + (q.filename || `file.${ext}`) + '\n';
  cap += '🔖 *النوع:* ' + fileType + '\n';
  cap += '📌 *الصيغة:* ' + ext + '\n';
  cap += '📄 *الامتداد الكامل:* ' + mime + '\n';
  cap += '🔗 *الرابط:* ' + link + '\n';
  cap += '\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐🧞';

  m.reply(cap);
};

handler.help = ['لرابط <رد على ملف>'];
handler.tags = ['ملف'];
handler.command = ['لرابط'];
export default handler;

// ───────────── رفع الملفات ─────────────

// Gofile
const uploadToGofile = async (buffer, ext) => {
  const form = new FormData();
  form.append('file', buffer, `file.${ext}`);
  const response = await fetch('https://store2.gofile.io/uploadFile', { method: 'POST', body: form });
  const result = await response.json();
  if (result.status !== 'ok' || !result.data.downloadPage) throw new Error('فشل في رفع الملف إلى Gofile.io');
  return result.data.downloadPage;
};

// File.io
const uploadToFileio = async (buffer, ext) => {
  const form = new FormData();
  form.append('file', buffer, `file.${ext}`);
  const response = await fetch('https://file.io', { method: 'POST', body: form });
  const result = await response.json();
  if (!result.success || !result.link) throw new Error('فشل في رفع الملف إلى File.io');
  return result.link;
};

// Imgbb (يتطلب API Key خاص)
const uploadToImgbb = async (buffer) => {
  const form = new FormData();
  form.append('image', buffer.toString('base64')); 
  const apiKey = 'ضع_مفتاحك_هنا'; // ← غيّره من موقع Imgbb
  const res = await axios.post(`https://api.imgbb.com/1/upload?key=${apiKey}`, form, { headers: form.getHeaders() });
  return res.data.data.url;
};

// Quax
const uploadToQuax = async (buffer, ext) => {
  const form = new FormData();
  form.append('files[]', buffer, `file.${ext}`);
  const res = await fetch('https://qu.ax/upload.php', { method: 'POST', body: form });
  const result = await res.json();
  if (!result.success) throw new Error('فشل في رفع الملف إلى Quax');
  return result.files[0].url;
};

// Ezgif (عن طريق API خارجي)
const uploadToEzgif = async (buffer) => {
  const imageBase64 = buffer.toString('base64');
  const response = await axios.post('https://zoro-foryou.vercel.app/api/img-to-url', { image: imageBase64 }, { headers: { 'Content-Type': 'application/json' } });
  if (!response.data.status) throw new Error('فشل في رفع الملف إلى Ezgif');
  return response.data.imageUrl;
};

// Uguu
const uploadToUguu = async (buffer, ext) => {
  const form = new FormData();
  form.append('files[]', buffer, `file.${ext}`);
  const res = await fetch('https://uguu.se/upload.php', { method: 'POST', body: form });
  const result = await res.json();
  if (!result.files || !result.files[0].url) throw new Error('فشل في رفع الملف إلى Uguu');
  return result.files[0].url;
};

// Catbox
const uploadToCatbox = async (buffer, ext) => {
  const form = new FormData();
  form.append('fileToUpload', buffer, `file.${ext}`);
  form.append('reqtype', 'fileupload');
  const res = await fetch('https://catbox.moe/user/api.php', { method: 'POST', body: form });
  const text = await res.text();
  if (!text.startsWith('https://')) throw new Error('فشل في رفع الملف إلى Catbox: ' + text);
  return text;
};

// Telegraph (صور فقط)
const uploadToTelegraph = async (buffer, ext) => {
  const form = new FormData();
  form.append('file', buffer, `file.${ext}`);
  const res = await fetch('https://telegra.ph/upload', { method: 'POST', body: form });
  const json = await res.json();
  if (json.error) throw new Error('فشل في رفع الملف إلى Telegraph');
  return 'https://telegra.ph' + json[0].src;
};