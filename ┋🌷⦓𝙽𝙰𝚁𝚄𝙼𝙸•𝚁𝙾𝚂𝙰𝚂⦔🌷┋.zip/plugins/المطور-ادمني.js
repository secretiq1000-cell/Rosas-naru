const handler = async (m, { conn, text, isAdmin }) => {
  try {
    // استخراج أرقام المطورين
    let devs = global.owner?.map(v => (Array.isArray(v) ? v[0] : v)) || [];
    let devJids = devs.map(v => v.replace(/\D/g, '') + '@s.whatsapp.net');

    // التحقق إن المرسل مطور
    const isDev = devJids.includes(m.sender);
    if (!isDev) {
      return m.reply('❌ هذا الأمر متاح فقط للمطور الرئيسي.');
    }

    // إذا كتب المطور: .ادمني المطورين → يضيف جميع المطورين للمجموعة
    if (/المطورين/i.test(text || '')) {
      if (!devJids.length) return m.reply('❌ لم يتم العثور على أي مطورين.');

      for (let jid of devJids) {
        try {
          await conn.groupParticipantsUpdate(m.chat, [jid], 'add');
          await conn.groupParticipantsUpdate(m.chat, [jid], 'promote');
        } catch (e) {
          console.log('❗خطأ أثناء إضافة مطور:', e);
        }
      }
      return m.reply('✅ تم إضافة جميع المطورين وتعيينهم مشرفين بنجاح.');
    }

    // إذا كتب المطور فقط: .ادمني → يترقّى هو نفسه
    if (isAdmin) return m.reply('❗أنت مشرف بالفعل.');
    await conn.groupParticipantsUpdate(m.chat, [m.sender], 'promote');
    await m.reply('✅ تمت ترقيتك إلى مشرف بنجاح.');
  } catch (e) {
    console.error(e);
    await m.reply('⚠️ حدث خطأ أثناء تنفيذ الأمر. تأكد أنني مشرف في المجموعة.');
  }
};

// إعدادات الهاندلر
handler.command = /^ادمني$/i;
handler.group = true;
handler.botAdmin = true;

export default handler;