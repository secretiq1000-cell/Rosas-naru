let handler = async (m, { conn, text, usedPrefix, command, args, isOwner }) => {

  // لو اللي بيستعمل الأمر مش أونر
  if (!isOwner) {
    return conn.reply(
      m.chat,
      `*⎔⋅ ╼╃ ⊰ •﹝🧬﹞• ⊱ ╄╾ ⋅⎔*\n\n*يا @${m.sender.split('@')[0]}*\n*لو حابب تضيف البوت لمجموعة، كلم الأونر عشان يظبطلك الموضوع.*\n\n*📌 تواصل مع المطور:* wa.me/${global.owner[0] || 'رقمالمطور'}`,
      m,
      { mentions: [m.sender] }
    )
  }

  // التحقق من الرابط
  const linkRegex = /chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i
  const delay = time => new Promise(res => setTimeout(res, time))

  let match = text.match(linkRegex)
  let code = match ? match[1] : null

  if (!args[0]) {
    throw `*✠ أرسل لينك الجروب أولاً.*\n\n*📌 مثال:*\n*${usedPrefix + command}* <الرابط>`
  }

  if (!code) {
    throw `*✠ اللينك غير صحيح يا كبير!*`
  }

  // رسالة الدخول
  await m.reply(`*⎔⋅ ╼╃ ⊰ •﹝🧬﹞• ⊱ ╄╾ ⋅⎔*\n*ويــــت… البوت داخل الجروب دلوقتي 🥂.*`)
  await delay(3000)

  try {
    // محاولة الانضمام للجروب
    let res = await conn.groupAcceptInvite(code)
    
    // لو وصلنا للسطر ده، معناه نجحنا ✅
    let meta = await conn.groupMetadata(res)
    let members = meta.participants.map(v => v.id)

    // تأكيد الدخول
    await m.reply(
      `*⎔⋅ ╼╃ ⊰ •﹝🧬﹞• ⊱ ╄╾ ⋅⎔*\n*تم دخول البوت للجروب بنجاح!*\n\n*✠ معلومات الجروب:*\n*• الاسم:* ${meta.subject}`
    )

    // رسالة الترحيب داخل الجروب
    await conn.reply(
      res,
      `*⎔⋅ ╼╃ ⊰ •﹝🧬﹞• ⊱ ╄╾ ⋅⎔*\n*هايات جميعاً!*\n\n*@${m.sender.split('@')[0]}* أضافني هنا 🧬`,
      null,
      { mentions: members }
    )

    await delay(7000)

    await conn.reply(
      res,
      `*📮 الدخول العشوائي للبوت بدون إذن المطور قد يؤدي للحظر!*`
    )

  } catch (e) {
    // التعامل مع خطأ already-exists
    if (String(e).includes('already-exists')) {
      throw `*⚠️ البوت موجود بالفعل في هذا الجروب!*`
    }
    else if (String(e).includes('Timed Out') || String(e).includes('timeout')) {
      throw `*⏰ انتهت المهلة!*\n\nالسبب الأرجح:\n• البوت محظور من الانضمام للمجموعات\n• أو الرابط لا يعمل (منتهي الصلاحية)\n• أو الإنترنت ضعيف جداً`
    } 
    else if (String(e).includes('invalid')) {
      throw `*❌ الرابط غير صالح!*\nتأكد أن الرابط لم ينتهِ صلاحيته.`
    }
    else if (String(e).includes('full')) {
      throw `*👥 الجروب ممتلئ!* لا يمكن إضافة المزيد من الأعضاء.`
    }
    else {
      throw `*📮 حدثت مشكلة أثناء دعوة البوت للجروب.*`
    }
  }
}

handler.help = ['join <chat.whatsapp.com>']
handler.tags = ['owner']
handler.command = ['ادخل', 'انضم']
// handler.owner = true

export default handler
