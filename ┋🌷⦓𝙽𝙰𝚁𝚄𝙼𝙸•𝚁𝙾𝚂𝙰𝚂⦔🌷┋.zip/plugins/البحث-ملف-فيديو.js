import fetch from 'node-fetch'
import yts from 'yt-search'

let handler = async (m, { conn, text, usedPrefix, command }) => {

    if (!text) return conn.reply(m.chat, `🎥 *يرجى إرسال رابط أو اسم فيديو*\n📌 مثال:\n${usedPrefix + command} https://youtu.be/...\n${usedPrefix + command} اغنية يمني`, m)

    await m.react('📹')

    try {
        let videoUrl = text.trim()
        
        // التحقق: إذا كان النص رابط YouTube، استخدمه مباشرة
        const youtubeRegex = /(youtu\.be\/|youtube\.com\/watch\?v=|\/v\/|\/e\/|watch\?v=|&v=|\?v=)([a-zA-Z0-9_-]{11})/
        let isUrl = youtubeRegex.test(videoUrl)
        
        let finalUrl
        
        if (isUrl) {
            finalUrl = videoUrl
        } else {
            // إذا كان نصًا، ابحث عنه
            let search = await yts(text)
            if (!search.videos[0]) return m.reply('❌ لم يتم العثور على الفيديو.')
            finalUrl = search.videos[0].url
        }

        const b = (s) => Buffer.from(s, 'base64').toString('utf-8')
        const base = b("aHR0cHM6Ly9hcGkuZXZvZ2Iub3Jn")
        const key = b("c2FzdWtl")

        let res = await fetch(`${base}/dl/ytmp4?url=${encodeURIComponent(finalUrl)}&key=${key}`)
        let json = await res.json()

        if (!json.status || !json.data || !json.data.dl) {
            await m.react('🚫')
            return m.reply('⚠️ تعذر استخراج الفيديو.')
        }

        const vid = json.data

        let report = `🎬 *الاسم:* ${vid.title}\n💎 *الدقة:* ${vid.quality}\n📽️ *الصيغة:* .${vid.format}`

        // إرسال الفيديو كـ مستند (document)
        await conn.sendMessage(m.chat, { 
            document: { url: vid.dl }, 
            mimetype: 'video/mp4',
            fileName: `${vid.title}.mp4`,
            caption: report
        }, { quoted: m })

        await m.react('✅')

    } catch (e) {
        await m.react('✖️')
        console.log(e)
        m.reply('⚠️ حدث خطأ، حاول مرة أخرى.')
    }
}

handler.help = ['ملف-فيديو']
handler.tags = ['downloader', 'البحث']
handler.command = ['ملف-فيديو']

export default handler