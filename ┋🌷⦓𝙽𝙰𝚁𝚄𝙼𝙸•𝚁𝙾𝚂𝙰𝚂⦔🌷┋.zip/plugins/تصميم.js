// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios'

let handler = async (m, { conn, text }) => {
  try {
    const query = text.trim()
    
    // التحقق من وجود الوصف
    if (!query) {
      return conn.sendMessage(m.chat, {
        text: `🎨 *تصميم الصور بالذكاء الاصطناعي* 🎨

━━━━━━━━━━━━━━━━━
📝 *الاستخدام:* 
.تصميم <وصف الصورة>

📋 *مثال:*

.تصميم غروب شمس على البحر

━━━━━━━━━━━━━━━━━
⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
      }, { quoted: m })
    }
    
    await conn.sendMessage(m.chat, { 
      text: `🎨 *جاري تصميم الصورة...*\n📝 الوصف: ${query}\n⏳ يرجى الانتظار`
    }, { quoted: m })
    
    // طلب API لتوليد الصورة
    const apiUrl = `https://helm-api.vercel.app/api/gpt-img-2.0/image?prompt=${encodeURIComponent(query)}`
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' })
    
    // إرسال الصورة
    await conn.sendMessage(m.chat, {
      image: Buffer.from(response.data),
      caption: `🎨 *تم تصميم الصورة بنجاح* 🎨

━━━━━━━━━━━━━━━━━
📝 *الوصف:* ${query}
━━━━━━━━━━━━━━━━━

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m })
    
  } catch (err) {
    console.error('❌ خطأ في توليد الصورة:', err.message)
    
    let errorMsg = `❌ *حدث خطأ أثناء توليد الصورة*\n\n`
    
    if (err.response?.status === 400) {
      errorMsg += `⚠️ الوصف غير صحيح أو فارغ.\n📝 حاول كتابة وصف أكثر وضوحاً.`
    } else if (err.response?.status === 500) {
      errorMsg += `⚠️ خطأ في الخادم.\n🔄 حاول مرة أخرى لاحقاً.`
    } else if (err.code === 'ECONNREFUSED' || err.code === 'ENOTFOUND') {
      errorMsg += `⚠️ مشكلة في الاتصال بالإنترنت أو الخادم.`
    } else {
      errorMsg += `📛 ${err.message}`
    }
    
    errorMsg += `\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    
    await conn.sendMessage(m.chat, { text: errorMsg }, { quoted: m })
  }
}

handler.command = ['تصميم']
handler.help = ['تصميم']
handler.category = 'tools'
handler.description = '🎨 تصميم الصور بالذكاء الاصطناعي عن طريق وصف'

export default handler