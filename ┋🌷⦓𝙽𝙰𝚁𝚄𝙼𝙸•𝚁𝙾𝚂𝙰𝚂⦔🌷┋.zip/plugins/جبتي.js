import fetch from "node-fetch";
import fs from 'fs';

let handler = async (m, { conn, args, usedPrefix, text, command }) => {
  if (!text)
    return m.reply(
      "- 「🚀」 *أدخل نصًا بعد الامر لاستخدام الرد بالذكاء الاصطناعي* *مثال* :\n ⟣ *جبتي* افضل انمي حتی الان ⟣ \n*جبتي* اكتب رمز JS"
    );

  await m.reply("⏳ جاري التفكير...");

  try {
    let result = await jebtiAI(m.sender, text);
    await m.reply(result);
  } catch (e) {
    console.error(e);
    await m.reply("⚠️ وقعت مشكلة: " + e.message);
  }
};

handler.help = ["جبتي"];
handler.tags = ["ai"];
handler.command = /^(جبتي)$/i;
export default handler;

// ========== نظام الذاكرة ==========
const conversations = new Map();
const MEMORY_FILE = './jebti_memory.json';

// تحميل الذاكرة
function loadMemory() {
    try {
        if (fs.existsSync(MEMORY_FILE)) {
            const data = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'));
            for (const [k, v] of Object.entries(data)) conversations.set(k, v);
            console.log(`✅ تم تحميل ذاكرة جبتي: ${conversations.size} مستخدم`);
        }
    } catch (e) {
        console.error('خطأ في تحميل الذاكرة:', e);
    }
}

// حفظ الذاكرة
function saveMemory() {
    try {
        fs.writeFileSync(MEMORY_FILE, JSON.stringify(Object.fromEntries(conversations), null, 2));
    } catch (e) {
        console.error('خطأ في حفظ الذاكرة:', e);
    }
}

// دالة الـ AI الرئيسية (مع معالجة SSE)
async function jebtiAI(userId, prompt) {
    // جلب محادثة المستخدم
    let history = conversations.get(userId) || [];
    
    // إضافة رسالة المستخدم
    history.push({ role: 'user', content: prompt });
    
    // الاحتفاظ بآخر 10 رسائل فقط
    if (history.length > 10) {
        history = history.slice(-10);
    }
    
    // تحويل تاريخ المحادثة إلى صيغة API
    const messages = [];
    for (let i = 0; i < history.length; i++) {
        const msg = history[i];
        messages.push({
            role: msg.role,
            content: [{ type: 'text', text: msg.content }]
        });
    }
    
    const headers = {
        'User-Agent': 'okhttp/4.9.2',
        'Accept': 'text/event-stream',
        'Content-Type': 'application/json',
        'cache-control': 'no-cache',
        'x-requested-with': 'XMLHttpRequest',
        'authorization': 'Bearer az-chatai-key',
        'x-app-version': '1.0.16',
        'x-user-id': `WA_${String(userId).substring(0, 20)}`,
        'x-platform-type': 'android',
        'x-language': 'ar',
    };
    
    const jsonData = {
        model: 'gpt-5.4-mini',
        stream: true,
        messages: messages,
        isSubscribed: false,
        web_search: false,
        reason: false,
        study_mode: false,
    };
    
    try {
        console.log(`📤 جاري الاتصال بالـ API للمستخدم: ${userId}`);
        
        const response = await fetch('https://api.appzoneai.com/v1/chat/completions', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(jsonData)
        });
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        // معالجة الـ SSE stream
        const text = await response.text();
        console.log('📥 تم استلام الـ stream');
        
        // استخراج الرد من صيغة data: {...}
        let fullResponse = '';
        const lines = text.split('\n');
        
        for (const line of lines) {
            if (line.startsWith('data: ') && line !== 'data: [DONE]') {
                try {
                    const jsonStr = line.slice(6); // إزالة 'data: '
                    const parsed = JSON.parse(jsonStr);
                    const content = parsed?.choices?.[0]?.delta?.content;
                    if (content) {
                        fullResponse += content;
                    }
                } catch (e) {
                    // تجاهل الأخطاء
                }
            }
        }
        
        if (!fullResponse) {
            throw new Error('لم يتم العثور على رد في الاستجابة');
        }
        
        // حفظ رد المساعد في الذاكرة
        history.push({ role: 'assistant', content: fullResponse });
        conversations.set(userId, history);
        saveMemory();
        
        return fullResponse;
    } catch (error) {
        console.error('API Error:', error.message);
        throw error;
    }
}

// تحميل الذاكرة عند بدء البوت
loadMemory();
