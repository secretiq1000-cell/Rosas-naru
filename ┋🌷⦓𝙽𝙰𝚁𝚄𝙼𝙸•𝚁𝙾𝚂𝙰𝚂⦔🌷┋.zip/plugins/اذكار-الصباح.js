let handler = async (m, { conn }) => {
  try {
    const remoteJid = m.chat

    const azkarSabah = `
🕌 *أذكار الصباح* 🌅

اللّهـمّ أَنْتَ رَبِّـي لا إلهَ إلاّ أَنْتَ، خَلَقْتَنـي وأنا عَبْـدُك،
وأنا علـى عَهْـدِك ووَعْـدِك ما اسْتَـطَعْت،
أَعـوذُ بِكَ مِن شَـرِّ ما صَنَـعْت،
أَبـوءُ لَـكَ بِنِعْـمَـتِـكَ عَلَـيَّ،
وأَبـوءُ بِذَنْـبي فَاغْفِـرْ لي،
فَإِنَّـهُ لا يَغْفِـرُ الذُّنـوبَ إِلاّ أَنْتَ 🤲

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

    await conn.sendMessage(remoteJid, {
      text: azkarSabah
    }, { quoted: m })

  } catch (err) {
    console.error('❌ خطأ:', err)
    await conn.sendMessage(m.chat, {
      text: `❌ خطأ: ${err.message}`
    }, { quoted: m })
  }
}

handler.command = ['اذكار-الصباح']
handler.help = ['اذكار']
handler.category = 'ديني'

export default handler
