let timeout = 15000; // 15 ثانية
let poin = 1; // نقطة واحدة
let targetPoints = 10; // النقاط المطلوبة للفوز

global.writingGame = global.writingGame || {};
global.gamePoints = global.gamePoints || {};

let handler = async (m, { conn, usedPrefix, command }) => {
    let id = m.chat;

    if (id in global.writingGame) {
        conn.reply(m.chat, `╔═━━••📝••━━═╗
✦ هناك جولة كتابة قائمة بالفعل ✦
✦ أكتب الكلمة الظاهرة بشكل صحيح ✦
╚═━━••📝••━━═╝`, global.writingGame[id][0]);
        return;
    }

    // 100 كلمة عربية متنوعة للعبة
    const words = [
        // دول وعواصم عربية (20 كلمة)
        "بيروت", "القاهرة", "الرياض", "دبي", "عمّان",
        "الدار البيضاء", "تونس", "الجزائر", "مسقط", "الدوحة",
        "الكويت", "المنامة", "صنعاء", "طرابلس", "الخرطوم",
        "دمشق", "بغداد", "القدس", "اسطنبول", "الرباط",
        
        // كلمات متعلقة بالكتابة واللغة (20 كلمة)
        "الكتابة", "القلم", "الورقة", "الحروف", "الكلمات",
        "الجملة", "النص", "القصة", "الشعر", "النثر",
        "الإملاء", "التهجئة", "القراءة", "الخط", "الرسم",
        "التوقيع", "المستند", "الكتاب", "الصفحة", "الفصل",
        
        // أسماء أشياء شائعة (20 كلمة)
        "التلفون", "الحاسوب", "السيارة", "المنزل", "المدرسة",
        "المستشفى", "المطعم", "الفندق", "المطار", "الميناء",
        "السوق", "المحل", "المصنع", "المزرعة", "الحديقة",
        "المسبح", "الملعب", "المسرح", "المتحف", "المكتبة",
        
        // كلمات إيجابية (20 كلمة)
        "السعادة", "النجاح", "الفرح", "الابتسامة", "الحب",
        "السلام", "الأمل", "الطموح", "العزيمة", "الإصرار",
        "الصبر", "الجهد", "العمل", "الإبداع", "التميز",
        "التفوق", "الذكاء", "المهارة", "السرعة", "الدقة",
        
        // كلمات متنوعة (20 كلمة)
        "الشمس", "القمر", "النجوم", "السماء", "الأرض",
        "البحر", "النهر", "الجبل", "الصحراء", "الغابة",
        "الطائر", "السمكة", "الأسد", "الفيل", "الحصان",
        "الوردة", "الشجرة", "الثمرة", "الماء", "الهواء",
        
        // كلمات صعبة للتحدي (إضافية)
        "البرمجيات", "التقنيات", "الإنترنت", "التواصل", "الاجتماع",
        "الاحتفال", "المنافسة", "البطولة", "المسابقة", "التحدي",
        "المعرفة", "العلم", "التعليم", "الدراسة", "البحث",
        "الاكتشاف", "الاختراع", "الابتكار", "التطوير", "التقدم",
        "الاستقلال", "الحرية", "العدالة", "المساواة", "الديمقراطية"
    ];
    
    let word = words[Math.floor(Math.random() * words.length)];
    
    let caption = `╔═━━••📝••━━═╗
✦ بدأت مسابقة الكتابة! ✦
✦ اكتب الكلمة التالية بشكل صحيح: ✦
╟────────────────╢
✦ 【 ${word} 】 ✦
╟────────────────╢
✦ الوقت: ${(timeout/1000)} ثانية ⏱️ ✦
✦ الجائزة: ${poin} نقطة ✦
✦ الفوز عند: ${targetPoints} نقاط 🏆 ✦
╟────────────────╢
✦ أول من يكتب الكلمة بشكل صحيح يفوز ✦
╚═━━••📝••━━═╝`.trim();

    global.writingGame[id] = [
        await conn.reply(m.chat, caption, m),
        word,
        poin,
        targetPoints,
        Date.now(),
        setTimeout(async () => {
            if (global.writingGame[id]) {
                await conn.reply(m.chat, `╔═━━••📝••━━═╗
✦ انتهى الوقت! ⌛ ✦
✦ الكلمة كانت: ${word} ✦
✦ لم يكتب أحد الكلمة بشكل صحيح ✦
╚═━━••📝••━━═╝`, global.writingGame[id][0]);
                delete global.writingGame[id];
            }
        }, timeout)
    ];
};

// معالج الإجابات
handler.before = async function(m, { conn }) {
    let id = m.chat;
    
    if (!global.writingGame || !global.writingGame[id]) return;
    
    let gameData = global.writingGame[id];
    let correctWord = gameData[1];
    
    if (!m.text) return;
    
    let userAnswer = m.text.trim();
    
    // مقارنة مرنة (تجاهل التشكيل والمسافات الزائدة)
    let normalizedAnswer = userAnswer.replace(/[ًٌٍَُِّْـ]/g, '').replace(/\s+/g, ' ').trim();
    let normalizedCorrect = correctWord.replace(/[ًٌٍَُِّْـ]/g, '').replace(/\s+/g, ' ').trim();
    
    if (normalizedAnswer === normalizedCorrect) {
        let points = gameData[2];
        let targetPoints = gameData[3];
        let startTime = gameData[4];
        
        // حساب النقاط
        let userId = m.sender;
        global.gamePoints[userId] = (global.gamePoints[userId] || 0) + points;
        
        let userPoints = global.gamePoints[userId];
        
        await conn.reply(m.chat, `╔═━━••📝••━━═╗
✦ مبروك! 🎉 ✦
✦ @${m.sender.split('@')[0]} كتب الكلمة بشكل صحيح ✦
╟────────────────╢
✦ الكلمة: ${correctWord} ✦
✦ النقاط: +${points} (المجموع: ${userPoints}) ✦
╟────────────────╢
✦ الوقت المستغرق: ${((Date.now() - startTime) / 1000).toFixed(1)} ثانية ⏱️ ✦
╚═━━••📝••━━═╝`, m, { mentions: [m.sender] });
        
        if (userPoints >= targetPoints) {
            await conn.reply(m.chat, `🎊🎊🎊🎊🎊🎊🎊🎊
✦ فوز كبير! ✦
✦ @${m.sender.split('@')[0]} وصل إلى ${targetPoints} نقاط! ✦
✦ الفائز في مسابقة الكتابة! 🏆 ✦
🎊🎊🎊🎊🎊🎊🎊🎊`, m, { mentions: [m.sender] });
            delete global.gamePoints[userId];
        }
        
        clearTimeout(gameData[5]);
        delete global.writingGame[id];
        
        // بدء جولة جديدة بعد 3 ثواني
        setTimeout(() => {
            handler(m, { conn, usedPrefix: '.', command: 'كتابة' });
        }, 3000);
        
        return true;
    }
    
    return false;
};

handler.help = ['كتابة']
handler.tags = ['game']
handler.command = /^(كتابة|كتاببة|كتابه|كتاببه|كتابه)$/i
handler.group = true
handler.game = true

export default handler
