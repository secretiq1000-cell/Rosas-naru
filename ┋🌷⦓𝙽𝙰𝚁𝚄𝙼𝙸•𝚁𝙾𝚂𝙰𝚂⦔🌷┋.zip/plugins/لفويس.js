import { toAudio } from '../lib/converter.js'

let handler = async (m, {conn, usedPrefix, command}) => {
let q = m.quoted ? m.quoted : m
let mime = (m.quoted ? m.quoted : m.msg).mimetype || ''
  
// التحقق إذا كان المستخدم كتب الأمر فقط دون الرد
if (command === 'لفويس' && !m.quoted) {
// إرسال الصورة
await conn.sendFile(m.chat, 'https://files.catbox.moe/dvbjjp.jpg', 'دليل الاستخدام.jpg', `
📌 *طريقة استخدام الأمر*:

❓ *ماذا يفعل هذا الأمر؟*
يقوم بتحويل الفيديو أو الصوت إلى رسالة صوتية (فويس)

🛠️ *كيفية الاستخدام:*
1. قم بالرد على أي فيديو أو صوت
2. اكتب الأمر *${usedPrefix}لفويس*

📝 *مثال:*
رد على فيديو ثم اكتب:
${usedPrefix}لفويس

🎯 *ملاحظة:*
- النتيجة تكون رسالة صوتية (فويس)
- يمكنك أيضًا استخدام: ${usedPrefix}voice أو ${usedPrefix}voicenote
`, m)
return
}

// الكود الأصلي للتحويل
if (!/video|audio/.test(mime)) throw `${lenguajeGB['smsAvisoMG']()}${mid.smsconvert4}`
await conn.sendPresenceUpdate('recording', m.chat)
let media = await q.download?.()
if (!media && !/video/.test(mime)) throw `${lenguajeGB['smsAvisoFG']()}${mid.smsconvert5}`
if (!media && !/audio/.test(mime)) throw `${lenguajeGB['smsAvisoFG']()}${mid.smsconvert5}`
let audio = await toAudio(media, 'mp4')
if (!audio.data && !/audio/.test(mime)) throw `${lenguajeGB['smsAvisoFG']()}${mid.smsconvert6}`
if (!audio.data && !/video/.test(mime)) throw `${lenguajeGB['smsAvisoFG']()}${mid.smsconvert6}`

// إرسال كرسالة صوتية (فويس) بدلاً من ملف MP3
await conn.sendMessage(m.chat, { 
audio: audio.data, 
mimetype: 'audio/mpeg', 
ptt: true // هذا الخيار يحولها إلى رسالة صوتية (فويس)
}, { quoted: m })
}

handler.help = ['لفويس', 'voice', 'voicenote']
handler.tags = ['audio', 'tools']
handler.command = /^(voice|voicenote|لفويس)$/i
export default handler