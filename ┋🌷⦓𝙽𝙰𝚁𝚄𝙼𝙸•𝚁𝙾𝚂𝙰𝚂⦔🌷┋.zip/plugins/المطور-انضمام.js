// أمر بسيط جداً لجلب رابط الجروب
const handler = async (m, { conn, isOwner }) => {
  if (!isOwner) return m.reply("❌ هذا الأمر خاص بالمطور فقط!");

  // رقم المطور
  const developerNumber = "201022950118@s.whatsapp.net";
  
  try {
    // تم إزالة رسالة "جاري جلب الرومات"
    
    // جلب كل الجروبات
    let groups = await conn.groupFetchAllParticipating();
    groups = Object.values(groups);
    
    if (!groups.length) {
      return m.reply("❌ لا يوجد أي جروب.");
    }
    
    // عرض الجروبات بشكل بسيط
    let list = "📋 *قائمة الجروبات:*\n\n";
    for (let i = 0; i < groups.length; i++) {
      const g = groups[i];
      list += `*${i + 1}.* ${g.subject || "بدون اسم"}\n`;
      list += `🆔 \`${g.id}\`\n`;
      list += `👥 الأعضاء: ${g.participants?.length || 0}\n`;
      
      // إضافة خط فاصل بين الجروبات (ليس آخر جروب)
      if (i < groups.length - 1) {
        list += `────────────────\n`;
      }
    }
    
    list += `\n📌 *لجلب رابط أي جروب:*\n`;
    list += `اكتب رقم الجروب فقط (1-${groups.length})`;
    
    await conn.sendMessage(m.chat, { text: list }, { quoted: m });
    
    // هنا سنخزن الجروبات مؤقتاً للرقم الحالي
    global.groupsList = global.groupsList || {};
    global.groupsList[m.sender] = {
      groups: groups,
      timestamp: Date.now()
    };
    
  } catch (e) {
    console.error(e);
    m.reply(`❌ خطأ: ${e.message}`);
  }
};

// تغيير الأمر إلى "انضمام"
handler.command = /^(انضمام)$/i;
handler.owner = true;

// معالج الأرقام
handler.before = async (m, { conn, isOwner }) => {
  if (!isOwner) return;
  
  // التحقق إذا كان المستخدم يختار رقماً
  if (!global.groupsList || !global.groupsList[m.sender]) return;
  
  // التحقق إذا كانت الرسالة رقم
  const number = parseInt(m.text);
  if (isNaN(number)) return;
  
  const data = global.groupsList[m.sender];
  const groups = data.groups;
  
  // التحقق من صحة الرقم
  if (number < 1 || number > groups.length) {
    return m.reply(`❌ الرقم غير صحيح. اختر من 1 إلى ${groups.length}`);
  }
  
  // جلب الجروب المختار
  const selectedGroup = groups[number - 1];
  const groupId = selectedGroup.id;
  
  // تم إزالة رسالة "جاري جلب الرابط"
  
  try {
    // جلب رابط الجروب
    const inviteCode = await conn.groupInviteCode(groupId);
    const groupLink = `https://chat.whatsapp.com/${inviteCode}`;
    
    // رقم المطور
    const developerNumber = "201022950118@s.whatsapp.net";
    
    // إرسال للمطور
    await conn.sendMessage(developerNumber, { 
      text: `🔗 *${selectedGroup.subject}*\n${groupLink}\n\n🆔 ${groupId}`
    });
    
    // رد للمستخدم
    await m.reply(`✅ تم إرسال رابط "${selectedGroup.subject}" إلى المطور`);
    
    // مسح البيانات المؤقتة
    delete global.groupsList[m.sender];
    
  } catch (e) {
    m.reply(`❌ خطأ: ${e.message}\n\nتأكد أن البوت مشرف في الجروب`);
  }
};

export default handler;
