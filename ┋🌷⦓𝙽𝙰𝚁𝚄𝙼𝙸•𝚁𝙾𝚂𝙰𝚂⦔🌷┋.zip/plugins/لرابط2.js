//اسرق الحقوق براحتك يفنان
import axios from "axios"
import FormData from "form-data"
import fs from "fs"
import path from "path"

const handler = async (m,{conn}) => {

  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ""

  if (!mime) return conn.sendMessage(m.chat,{text:"❌ رد على صورة او فيديو"},{quoted:m})
  if (!mime.includes("image") && !mime.includes("video"))
    return conn.sendMessage(m.chat,{text:"❌ لازم يكون صورة او فيديو"},{quoted:m})

  let data
  try {
    data = await q.download()
  } catch {
    return conn.sendMessage(m.chat,{text:"❌ ما قدرت احمل الملف"},{quoted:m})
  }

  let ext = mime.split("/")[1] || "dat"
  let name = "up_"+Date.now()+"."+ext
  let file = path.join(process.cwd(),name)

  fs.writeFileSync(file,data)

  try {
    let form = new FormData()
    form.append("file",fs.createReadStream(file))

    let r = await axios.post("https://zeref-up.vercel.app/api/upload",form,{
      headers: form.getHeaders()
    })

    if (fs.existsSync(file)) fs.unlinkSync(file)

    if (!r.data || !r.data.success)
      return conn.sendMessage(m.chat,{text:"❌ فشل رفع الملف"},{quoted:m})

    conn.sendMessage(m.chat,{text:"✅ تم رفع الملف\n"+r.data.file.url},{quoted:m})

  } catch {
    if (fs.existsSync(file)) fs.unlinkSync(file)
    conn.sendMessage(m.chat,{text:"❌ صار خطأ وقت الرفع"},{quoted:m})
  }
}

handler.help=["لرابط2"]
handler.tags=["tools"]
handler.command=["لرابط2"]

export default handler
