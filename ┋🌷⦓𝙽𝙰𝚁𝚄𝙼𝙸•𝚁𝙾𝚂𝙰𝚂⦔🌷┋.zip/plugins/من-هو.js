// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const ranksFile = path.join(__dirname, '../data/ranks.json')

function loadRanks() {
  try {
    if (!fs.existsSync(ranksFile)) fs.writeFileSync(ranksFile, '{}')
    return JSON.parse(fs.readFileSync(ranksFile))
  } catch {
    return {}
  }
}

function saveRanks(ranks) {
  fs.writeFileSync(ranksFile, JSON.stringify(ranks, null, 2))
}

const animeQuestions = [
  { question: "من هو قائد قراصنة قبعة القش؟", answer: "لوفي" },
  { question: "ما اسم القطة في أنمي Sailor Moon؟", answer: "لونا" },
  { question: "من هو والد غوكو؟", answer: "باردوك" },
  { question: "ما اسم الشينيغامي في ديث نوت؟", answer: "ريوك" },
  { question: "كم عدد كرات التنين في دراغون بول؟", answer: "7" },
  { question: "من هو خصم ناروتو الأساسي؟", answer: "ساسكي" },
  { question: "من الذي كتب أسماء الأشخاص في ديث نوت؟", answer: "لايت" },
  { question: "ما اسم أخ إيتاتشي؟", answer: "ساسكي" },
  { question: "من هو هاوك آيز في ون بيس؟", answer: "ميهوك" },
  { question: "ما اسم الكيان الذي يساعد إينويشا؟", answer: "كيكيو" },
  { question: "ما اسم صديق غون المقرب؟", answer: "كيلوا" },
  { question: "ما اسم التقنية النهائية لناروتو؟", answer: "راسينغان" },
  { question: "ما اسم الأنمي الذي يحتوي على شخصية إدوارد إلريك؟", answer: "فول ميتال ألكيمست" },
  { question: "من هو ملك القراصنة؟", answer: "غول دي روجر" },
  { question: "ما اسم سيف زورو الثالث؟", answer: "وادو إيتشي مونجي" },
  { question: "من هو خصم لوفي في أرخبيل شابوندي؟", answer: "كيزارو" },
  { question: "ما اسم فتاة التي تمتلك قوة تيتان المؤنث؟", answer: "آني" },
  { question: "من هو الذي قتل إيتاتشي؟", answer: "ساسكي" },
  { question: "من هو أعظم محقق في ديث نوت؟", answer: "L" },
  { question: "من هو صاحب قبعة القش قبل لوفي؟", answer: "شانكس" },
  { question: "ما اسم المنظمة التي ينتمي إليها إيتاتشي؟", answer: "الأكاتسكي" },
  { question: "من هو المعلم الخاص بـ غون؟", answer: "كايتو" },
  { question: "من هو ملك العمالقة؟", answer: "زيك" },
  { question: "من هو النينجا الأسطوري الذي درب ناروتو؟", answer: "جيرايا" },
  { question: "ما اسم أول بوكيمون في البوكيدكس؟", answer: "بولباسور" },
  { question: "من هو صاحب قدرة غريموار النجم الأسود؟", answer: "أستا" },
  { question: "من هو قاتل والد إيرين؟", answer: "زيك" },
  { question: "من هو قائد فرقة الاستطلاع في هجوم العمالقة؟", answer: "ليفاي" },
  { question: "ما اسم أخ ناروتو؟", answer: "ما عندوش" },
  { question: "من هو الشخص اللي أكل فاكهة المطاط؟", answer: "لوفي" },
  { question: "ما اسم شخصية ناروتو بالكامل؟", answer: "ناروتو أوزوماكي" },
  { question: "من هو محقق كونان الحقيقي؟", answer: "سينشي كودو" },
  { question: "من هي فتاة القمر في أنمي Sailor Moon؟", answer: "أوساغي" },
  { question: "من هو الخصم الرئيسي لغون؟", answer: "هيسوكا" },
  { question: "من هو قائد فرقة بلاك بولز؟", answer: "يامي" },
  { question: "من هو والد إيرين؟", answer: "غريشا ييغر" },
  { question: "ما اسم صديقة ميليوداس؟", answer: "إليزابيث" },
  { question: "من هو الكابتن في بليتش؟", answer: "إيتشيغو" },
  { question: "ما اسم القط في فيري تيل؟", answer: "هابي" },
  { question: "ما اسم منظمة القتلة في هنتر x هنتر؟", answer: "العناكب" },
  { question: "من هو أعظم ساحر في بلاك كلوفر؟", answer: "الملك السحري" },
  { question: "ما اسم الحيوان اللي مع ناروتو؟", answer: "الكيوبي" },
  { question: "ما اسم العدو اللي عنده قدرة النسخ في ناروتو؟", answer: "كاكاشي" },
  { question: "من هو مؤلف مذكرة الموت؟", answer: "تسوجومي أوبا" },
  { question: "ما اسم المكان الذي يتدرب فيه أبطال Boku no Hero؟", answer: "يو اي" },
  { question: "من هو الذي يملك قدرة \"وان فور أول\"؟", answer: "ديكو" },
  { question: "من هو قاتل نيزوكو؟", answer: "تنغن ساما" },
  { question: "ما اسم القمر الصناعي في أنمي Dr. Stone؟", answer: "Senku" },
  { question: "من هو الذكي في أنمي كونان؟", answer: "سينشي" },
  { question: "ما اسم الأميرة في أنمي توتورو؟", answer: "ماي" },
  { question: "من هو مؤسس أنمي ناروتو؟", answer: "ماساشي كيشيموتو" }
]

// تخزين الألعاب النشطة
if (!global.animeGames) global.animeGames = new Map()

// عبارات النجاح والفشل
const successMessages = [
  "🎉 *إجابة رائعة!* 🎉",
  "⭐ *ذكي جداً!* ⭐",
  "🏆 *أحسنت!* 🏆",
  "💪 *قوي يا بطل!* 💪",
  "🔥 *جاوبت صح!* 🔥",
  "✨ *إجابة صحيحة 100%* ✨",
  "🎯 *دقة متناهية!* 🎯",
  "🧠 *عقلك جامد!* 🧠"
]

const failMessages = [
  "😅 *للأسف غلط*",
  "🤔 *حاول مرة أخرى*",
  "💡 *فكر شوية*",
  "📚 *راجع معلوماتك*",
  "🎌 *غلط... جاوب تاني*",
  "❌ *إجابة خاطئة*"
]

let handler = async (m, { conn }) => {
  const chatId = m.chat
  
  if (global.animeGames.has(chatId)) {
    return conn.sendMessage(chatId, {
      text: '⚠️ *في لعبة نشطة حالياً!* 🎮\nأجب على السؤال الحالي أولاً.'
    }, { quoted: m })
  }
  
  const random = animeQuestions[Math.floor(Math.random() * animeQuestions.length)]
  const correctAnswer = random.answer.trim().toLowerCase()
  
  global.animeGames.set(chatId, {
    answer: correctAnswer,
    question: random.question,
    expectedAnswer: random.answer,
    active: true
  })
  
  const randomEmoji = ['🎌', '🎎', '🗾', '🌸', '🍜', '⚔️', '👺', '🐉'][Math.floor(Math.random() * 8)]
  
  await conn.sendMessage(chatId, {
    text: `${randomEmoji} *لعبة من هو؟* ${randomEmoji}\n\n❓ *${random.question}*\n\n⏳ *أرسل إجابتك خلال 30 ثانية*\n💡 تذكر: الأجوبة تكون بأسماء الشخصيات\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
  }, { quoted: m })
  
  setTimeout(async () => {
    const game = global.animeGames.get(chatId)
    if (game && game.active) {
      global.animeGames.delete(chatId)
      await conn.sendMessage(chatId, {
        text: `⌛ *انتهى الوقت!* ⏰\n\nالإجابة الصحيحة هي: *${game.expectedAnswer}*\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
      })
    }
  }, 30000)
}

handler.before = async (m, { conn }) => {
  const chatId = m.chat
  const game = global.animeGames.get(chatId)
  
  if (game && game.active && m.text && !m.text.startsWith('.') && !m.text.startsWith('#')) {
    const userAnswer = m.text.trim().toLowerCase()
    
    if (userAnswer === game.answer) {
      global.animeGames.delete(chatId)
      
      const ranks = loadRanks()
      ranks[m.sender] = (ranks[m.sender] || 0) + 1
      saveRanks(ranks)
      
      const successMsg = successMessages[Math.floor(Math.random() * successMessages.length)]
      const points = ranks[m.sender]
      
      let rankBadge = ''
      if (points >= 50) rankBadge = '👑 *أسطورة الأنمي* 👑'
      else if (points >= 30) rankBadge = '⚡ *خبير أنمي* ⚡'
      else if (points >= 15) rankBadge = '🎖️ *عاشق أنمي* 🎖️'
      else if (points >= 5) rankBadge = '🌱 *محب أنمي* 🌱'
      else rankBadge = '🆕 *مبتدئ أنمي* 🆕'
      
      await conn.sendMessage(chatId, {
        text: `${successMsg}\n\n✅ *${game.question}*\n📝 الإجابة: *${game.expectedAnswer}*\n\n🏆 الفائز: @${m.sender.split('@')[0]}\n⭐ نقاطك: *${points}*\n${rankBadge}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
        mentions: [m.sender]
      }, { quoted: m })
      
      return true
    } else {
      const failMsg = failMessages[Math.floor(Math.random() * failMessages.length)]
      await conn.sendMessage(chatId, {
        text: `${failMsg}\n\n📝 إجابتك: *${m.text}*\n💡 الإجابة الصحيحة: *${game.expectedAnswer}*\n\n🔄 اكتب *من-هو* للعب مرة أخرى`
      }, { quoted: m })
      
      return true
    }
  }
  return false
}

handler.command = ['من-هو', 'من هو', 'سؤال', 'انمي', 'anime']
handler.help = ['من-هو']
handler.category = 'ترفيه'
handler.description = '🎌 لعبة من هو؟ أسئلة أنمي مع نقاط وألقاب'

export default handler
