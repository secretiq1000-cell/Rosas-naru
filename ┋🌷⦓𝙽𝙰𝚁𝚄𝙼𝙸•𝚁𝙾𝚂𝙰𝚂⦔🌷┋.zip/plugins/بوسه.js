// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

let handler = async (m, { conn, text }) => {
  try {
    // تحديد الشخص المستهدف
    let targetJid = null
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      targetJid = m.mentionedJid[0]
    } else if (m.quoted) {
      targetJid = m.quoted.sender
    } else if (text) {
      let cleanNumber = text.replace(/[^0-9]/g, '')
      if (cleanNumber.length >= 10) {
        if (cleanNumber.startsWith('0')) {
          cleanNumber = '20' + cleanNumber.slice(1)
        }
        targetJid = `${cleanNumber}@s.whatsapp.net`
      }
    }

    if (!targetJid) {
      return await conn.sendMessage(m.chat, {
        text: '❗ *يرجى الرد على رسالة الشخص أو منشنه أو كتابة رقمه*\n\nمثال: .بوسه @الشخص'
      }, { quoted: m })
    }

    if (targetJid === m.sender) {
      return await conn.sendMessage(m.chat, {
        text: '😏 *ما تقدر تبوس نفسك!* جرب تبوس حد تاني'
      }, { quoted: m })
    }

    const targetName = targetJid.split('@')[0]

    const messages = [
      `💋 *بوسة* 💋\n\n💕 لـ @${targetName}\n😘 *قبلة من القلب*`,
      `💗 *أرسل لك بوسة* 💗\n\n✨ @${targetName} انت نور عيني ✨`,
      `💖 *تقبيل ساخن* 💖\n\n🔥 @${targetName} يا أحلى إنسان 🔥`,
      `💝 *بوسة رومانسية* 💝\n\n🌹 @${targetName} عقبال ما نشوفك 🌹`,
      `💘 *قبلة* 💘\n\n😚 @${targetName} تقبل تحياتي 😚`
    ]
    
    const randomMsg = messages[Math.floor(Math.random() * messages.length)]
    const finalMsg = `${randomMsg}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

    await conn.sendMessage(m.chat, {
      text: finalMsg,
      mentions: [targetJid]
    }, { quoted: m })

  } catch (error) {
    console.error('خطأ:', error)
    await conn.sendMessage(m.chat, {
      text: '❌ *حدث خطأ أثناء تنفيذ الأمر*\n\nالرجاء المحاولة مرة أخرى.'
    }, { quoted: m })
  }
}

handler.command = ['بوسه', 'بوس', 'قبلة']
handler.help = ['بوسه']
handler.category = 'ترفيه'

export default handler
