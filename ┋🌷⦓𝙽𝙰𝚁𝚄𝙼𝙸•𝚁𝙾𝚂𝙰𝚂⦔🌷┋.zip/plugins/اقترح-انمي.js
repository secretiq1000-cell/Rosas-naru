let handler = async (m, { conn }) => {
    const animeSuggestions = [
        "🔹 Attack on Titan (شونين/أكشن)",
        "🔹 Death Note (نفسي/غموض)",
        "🔹 Demon Slayer (أكشن/فانتازيا)",
        "🔹 One Piece (مغامرات/كوميديا)",
        "🔹 Jujutsu Kaisen (شياطين/مدرسة)",
        "🔹 Hunter x Hunter (مغامرة/أكشن)",
        "🔹 Tokyo Ghoul (رعب/نفسي)",
        "🔹 Naruto (ننجا/شونين)",
        "🔹 Your Name (رومانسي/دراما)",
        "🔹 A Silent Voice (دراما/مدرسي)",
        "🔹 Steins;Gate (خيال علمي/غموض)",
        "🔹 Erased (غموض/سفر عبر الزمن)",
        "🔹 Code Geass (أكشن/ذكاء)",
        "🔹 Parasyte (رعب/أكشن)",
        "🔹 The Promised Neverland (تشويق/هروب)",
        "🔹 Chainsaw Man (أكشن/رعب)",
        "🔹 Black Clover (سحر/شونين)",
        "🔹 Vinland Saga (تاريخي/فايكنج)",
        "🔹 Blue Lock (رياضي/كرة قدم)",
        "🔹 Haikyuu!! (رياضي/كرة طائرة)",
        "🔹 Kuroko no Basket (رياضي/كرة سلة)",
        "🔹 Re:Zero (إيسيكاي/نفسي)",
        "🔹 No Game No Life (ألعاب/إيسيكاي)",
        "🔹 Mob Psycho 100 (قوى خارقة)",
        "🔹 One Punch Man (أكشن/كوميديا)",
        "🔹 Spy x Family (كوميدي/تجسس)",
        "🔹 Horimiya (رومانسي/مدرسي)",
        "🔹 Toradora! (رومانسي/كوميدي)",
        "🔹 Clannad (دراما/رومانسي)",
        "🔹 Anohana (دراما/مؤثر)",
        "🔹 Made in Abyss (مغامرة/غموض)",
        "🔹 Dr. Stone (علم/بقاء)",
        "🔹 Ousama Ranking (خيال/طفولي جميل)",
        "🔹 Boku no Hero Academia (أبطال/مدرسة)",
        "🔹 Mashle (كوميدي/سحر)",
        "🔹 Classroom of the Elite (مدرسي/نفسي)",
        "🔹 Hellsing Ultimate (رعب/مصاصين دماء)",
        "🔹 Noragami (فانتازيا/كوميدي)",
        "🔹 Fairy Tail (مغامرة/سحر)",
        "🔹 Bleach (أرواح/أكشن)",
        "🔹 Psycho-Pass (نفسي/شرطة)",
        "🔹 The Rising of the Shield Hero (إيسيكاي/فانتازيا)",
        "🔹 Solo Leveling (أكشن/اصدار جديد)",
        "🔹 Frieren: Beyond Journey's End (دراما/فانتازيا)",
        "🔹 Zom 100 (كوميدي/زومبي)",
        "🔹 Hyouka (مدرسي/غموض)",
        "🔹 Welcome to the NHK (نفسي/مظلم)",
        "🔹 Great Pretender (احتيال/كوميديا)",
        "🔹 Devilman Crybaby (نفسي/رعب)",
        "🔹 Akudama Drive (أكشن/سايبربانك)",
        "🔹 Banana Fish (جريمة/دراما)",
        "🔹 Monster (جريمة/غموض/نفسي)"
    ]

    const randomAnime = animeSuggestions[Math.floor(Math.random() * animeSuggestions.length)]

    const message = `
🎬 *أنصحك تشوف:* 🎬

${randomAnime}

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

    await conn.sendMessage(m.chat, {
        text: message
    }, { quoted: m })
}

handler.command = ['اقترح-انمي']
handler.help = ['اقترح-انمي']
handler.category = 'ترفيه'
handler.description = 'يقترح البوت لك انمي لمشاهدته'

export default handler
