import fetch from "node-fetch";
import fs from "fs";
import path from "path";

let handler = async (m, { conn, text, usedPrefix }) => {
  if (!text) return m.reply(`🎙️ أرسل النص بعد الأمر.\nمثال: *${usedPrefix}انطق مرحبًا بك في البوت*`);

  try {
    const audioUrl = `https://translate.google.com/translate_tts?ie=UTF-8&tl=ar&client=tw-ob&q=${encodeURIComponent(text)}`;
    const response = await fetch(audioUrl);

    if (!response.ok) throw new Error("فشل الاتصال بخدمة جوجل.");

    // حفظ الصوت مؤقتًا كملف mp3
    const buffer = await response.arrayBuffer();
    const filePath = path.join(process.cwd(), `tts-${Date.now()}.mp3`);
    fs.writeFileSync(filePath, Buffer.from(buffer));

    // إرسال الصوت كمقطع صوتي حقيقي
    await conn.sendMessage(m.chat, {
      audio: { url: filePath },
      mimetype: "audio/mpeg",
      fileName: "voice.mp3",
    }, { quoted: m });

    // حذف الملف بعد الإرسال
    setTimeout(() => fs.unlinkSync(filePath), 5000);

  } catch (e) {
    console.error("⚠️ حدث خطأ:", e);
    await m.reply("❌ حدث خطأ أثناء معالجة طلبك، حاول لاحقًا.");
  }
};

handler.help = ["انطق"];
handler.tags = ["tools"];
handler.command = /^انطق$/i;

export default handler;