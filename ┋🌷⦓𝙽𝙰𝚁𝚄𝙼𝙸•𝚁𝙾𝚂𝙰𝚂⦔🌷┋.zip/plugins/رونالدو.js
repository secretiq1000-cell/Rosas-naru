// ╔════════════════════════════╗
// 👑 𝑴𝑶𝑶𝑫𝑬 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

const dir = [
  'https://telegra.ph/file/47980b59ec8bb7536b8c3.mp4',
  'https://telegra.ph/file/f5b44250d09185cdc5ceb.mp4',
  'https://telegra.ph/file/cc3c936f1c8a3011f4f61.mp4',
  'https://telegra.ph/file/720e5d6fd5b1db1d84fd1.mp4',
  'https://telegra.ph/file/73f99720578e60a185065.mp4',
  'https://telegra.ph/file/801bc2b575205d84fdd8c.mp4',
  'https://telegra.ph/file/984bb87dd03a92eee1a17.mp4',
  'https://telegra.ph/file/7097fb382329e9ad40b36.mp4',
  'https://telegra.ph/file/906199e5f8749000d0423.mp4',
  'https://telegra.ph/file/77348305d0298f1863b16.mp4',
  'https://telegra.ph/file/d91c04ed0c7ec4d93cf45.mp4',
  'https://telegra.ph/file/dac6f6ba7cf2e4f85f9f0.mp4',
]

let handler = async (m, { conn }) => {
  try {
    // تحديد الشخص المستهدف (منشن أو مقتبس)
    let target = m.sender // default نفسه
    
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      target = m.mentionedJid[0]
    } else if (m.quoted) {
      target = m.quoted.sender
    }
    
    const targetName = target.split('@')[0]

    // رسالة البداية
    await conn.sendMessage(m.chat, {
      text: `🎬 *فيديو قادم* 🎬\n\n✨ لـ @${targetName} استمتع ⚽`,
      mentions: [target]
    }, { quoted: m })

    // اختيار فيديو عشوائي
    const randomVideo = dir[Math.floor(Math.random() * dir.length)]

    // إرسال الفيديو
    const videoMsg = await conn.sendMessage(m.chat, {
      video: { url: randomVideo },
      caption: `⚽ *استمتع بالفيديو يا @${targetName}* ⚽\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
      mentions: [target]
    }, { quoted: m })

    // إضافة ردة فعل ⚽
    await conn.sendMessage(m.chat, { 
      react: { text: '⚽', key: videoMsg.key } 
    })

  } catch (err) {
    console.error('خطأ في أمر الدون:', err)
    await conn.sendMessage(m.chat, { 
      text: '⚠️ حصل خطأ غير متوقع.\n' + err.message 
    }, { quoted: m })
  }
}

handler.command = ['رونالدو']
handler.help = ['رونالدو']
handler.category = 'edit'
handler.description = '🎬 يبعت فيديو عشوائي + ردة فعل ⚽ لأي حد'

export default handler
