import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

const GROUP_DEVELOPERS = ['201022950118@s.whatsapp.net', 'developer2@s.whatsapp.net'];
const imgUrl = 'https://i.postimg.cc/KzmM5HPV/05ebe87e1c3dfe71e047f63414707c15.jpg';
const wm = '𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐';

const handler = async (m, { text, conn, usedPrefix, command }) => {
  // 1. حالة عدم وجود نص (عرض قائمة المجموعات)
  if (!text) {
    const chats = conn.chats;
    const groupJids = Object.keys(chats).filter(jid => jid.endsWith('@g.us') && chats[jid]?.isChats);
    const totalGroups = groupJids.length;

    if (totalGroups === 0) {
      return conn.sendMessage(m.chat, { text: '⚠️ البوت ليس عضوًا في أي مجموعة.' }, { quoted: m });
    }

    const rowsPromises = groupJids.map(async (jid) => {
      try {
        const groupMetadata = await conn.groupMetadata(jid);
        const groupName = groupMetadata.subject || 'No Name';
        const participants = groupMetadata.participants || [];
        const botParticipant = participants.find(p => p.id === conn.user.id);
        const isBotAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin';
        const totalParticipants = participants.length;

        return {
          header: `📌 ${groupName}`,
          title: `👤 ${totalParticipants} عضو | 🤖 ${isBotAdmin ? 'أدمن' : 'عضو'}`,
          description: `🆔 ${jid}`,  // ✅ تم التعديل: الآن سيرسل المعرف كاملاً مع @g.us
          id: `${usedPrefix + command} ${jid}`
        };
      } catch (error) {
        console.error(`فشل في جلب بيانات المجموعة ${jid}:`, error);
        return null;
      }
    });

    const rows = (await Promise.all(rowsPromises)).filter(row => row !== null);

    if (rows.length === 0) {
      return conn.sendMessage(m.chat, { text: '⚠️ لا توجد مجموعات متاحة أو حدث خطأ في جلب البيانات.' }, { quoted: m });
    }

    try {
      const { imageMessage } = await prepareWAMessageMedia(
        { image: { url: imgUrl } }, 
        { upload: conn.waUploadToServer }
      );
      
      const caption = `📋 *قائمة المجموعات*\n\n📊 *العدد:* ${totalGroups} مجموعة\n👥 *البوت مشارك في:* ${totalGroups} من المجموعات\n\n🔽 اضغط على الزر لعرض القائمة:\n\n📌 *ملاحظة:* المعرف كامل مع @g.us يمكنك نسخه واستخدامه`;
      
      const interactiveMessage = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: caption },
              footer: { text: wm },
              header: {
                hasMediaAttachment: true,
                imageMessage: imageMessage
              },
              nativeFlowMessage: {
                buttons: [
                  {
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                      title: '📁 قائمة المجموعات',
                      sections: [
                        {
                          title: '「 المجموعات المتاحة 」',
                          highlight_label: '📌',
                          rows: rows
                        }
                      ]
                    })
                  }
                ]
              }
            }
          }
        }
      }, { userJid: conn.user.jid, quoted: m });
      
      await conn.relayMessage(m.chat, interactiveMessage.message, { messageId: interactiveMessage.key.id });
    } catch (error) {
      console.error('خطأ في إنشاء الرسالة التفاعلية:', error);
      // رسالة نصية بديلة مع المعرف الكامل
      let groupList = `📋 *قائمة المجموعات*\n📊 *العدد:* ${totalGroups}\n\n`;
      rows.forEach((row, index) => {
        groupList += `${index + 1}. ${row.header}\n   ${row.title}\n   🆔 ${row.description}\n\n`;
      });
      groupList += `\n📌 *طريقة الاستخدام:*\n`;
      groupList += `• ${usedPrefix + command} سحب-المعرف@g.us\n`;
      groupList += `• ${usedPrefix + command} تصفيه-المعرف@g.us\n`;
      groupList += `• ${usedPrefix + command} مغادرة-المعرف@g.us\n\n`;
      groupList += `مثال: ${usedPrefix + command} سحب-12345678901234567890@g.us`;
      await conn.sendMessage(m.chat, { text: groupList }, { quoted: m });
    }
  }
  // 2. حالة وجود نص (تنفيذ أمر على مجموعة محددة)
  else {
    const [action, idgru] = text.split('-');
    
    // ✅ تحقق أفضل من صيغة المعرف
    if (!idgru || !idgru.endsWith('@g.us')) {
      return conn.sendMessage(m.chat, { 
        text: `⚠️ *الصيغة غير صحيحة*\n\n📌 *الاستخدام الصحيح:*\n- ${usedPrefix + command} سحب-المعرف@g.us\n- ${usedPrefix + command} تصفيه-المعرف@g.us\n- ${usedPrefix + command} مغادرة-المعرف@g.us\n\n📝 *مثال:*\n${usedPrefix + command} سحب-12345678901234567890@g.us\n\n💡 *للبحث عن المعرف:* استخدم ${usedPrefix + command} لعرض قائمة المجموعات مع المعرفات الكاملة` 
      }, { quoted: m });
    }

    if (!GROUP_DEVELOPERS.includes(m.sender)) {
      return conn.sendMessage(m.chat, { text: '❌ هذا الأمر للمطورين فقط.' }, { quoted: m });
    }

    let groupMetadata;
    try {
      groupMetadata = await conn.groupMetadata(idgru);
    } catch (e) {
      return conn.sendMessage(m.chat, { text: `⚠️ خطأ في جلب بيانات المجموعة: ${e.message}` }, { quoted: m });
    }

    const participants = groupMetadata.participants || [];
    const owner = groupMetadata.owner;
    const botId = conn.user.id;
    const senderId = m.sender;

    if (action === 'سحب') {
      const participantsToDemote = participants
        .filter(p => p.admin && p.id !== owner && p.id !== botId && !GROUP_DEVELOPERS.includes(p.id))
        .map(p => p.id);

      const developersToPromote = participants
        .filter(p => GROUP_DEVELOPERS.includes(p.id) && !p.admin)
        .map(p => p.id);

      try {
        if (participantsToDemote.length > 0) {
          await conn.groupParticipantsUpdate(idgru, participantsToDemote, 'demote');
        }
        if (developersToPromote.length > 0) {
          await conn.groupParticipantsUpdate(idgru, developersToPromote, 'promote');
        }

        const successMessage = `✅ *تم سحب الأدمنية بنجاح!*\n📌 *المجموعة:* ${groupMetadata.subject}\n🆔 *المعرف:* ${idgru}\n👤 *بواسطة:* @${senderId.split('@')[0]}`;
        await conn.sendMessage(idgru, { text: successMessage, mentions: [senderId] });
        await conn.sendMessage(m.chat, { text: successMessage, mentions: [senderId] });
      } catch (error) {
        console.error(error);
        await conn.sendMessage(m.chat, { text: `❌ فشل في سحب الأدمنية: ${error.message}` }, { quoted: m });
      }
    }
    else if (action === 'تصفيه') {
      const participantsToKick = participants
        .filter(p => p.id !== owner && p.id !== botId && !GROUP_DEVELOPERS.includes(p.id))
        .map(p => p.id);

      const developersToPromote = participants
        .filter(p => GROUP_DEVELOPERS.includes(p.id) && !p.admin)
        .map(p => p.id);

      if (participantsToKick.length === 0 && developersToPromote.length === 0) {
        return conn.sendMessage(m.chat, { text: '⚠️ لا يوجد أعضاء للطرد أو مطورين للترقية.' }, { quoted: m });
      }

      try {
        if (participantsToKick.length > 0) {
          await conn.groupParticipantsUpdate(idgru, participantsToKick, 'remove');
        }
        if (developersToPromote.length > 0) {
          await conn.groupParticipantsUpdate(idgru, developersToPromote, 'promote');
        }

        const successMessage = `🧹 *تمت تصفية المجموعة بنجاح!*\n📌 *المجموعة:* ${groupMetadata.subject}\n🆔 *المعرف:* ${idgru}\n👤 *بواسطة:* @${senderId.split('@')[0]}\n📊 *تم طرد:* ${participantsToKick.length} عضو\n⭐ *تم ترقية:* ${developersToPromote.length} مطور`;
        await conn.sendMessage(idgru, { text: successMessage, mentions: [senderId] });
        await conn.sendMessage(m.chat, { text: successMessage, mentions: [senderId] });
      } catch (error) {
        console.error(error);
        await conn.sendMessage(m.chat, { text: `❌ فشل في تصفية المجموعة: ${error.message}` }, { quoted: m });
      }
    }
    else if (action === 'مغادرة') {
      try {
        const leaveMessage = `👋 *تم مغادرة المجموعة بأمر من المطور!*\n📌 *المجموعة:* ${groupMetadata.subject}\n🆔 *المعرف:* ${idgru}\n👤 *المطور:* @${senderId.split('@')[0]}\n\nشكرًا لاستضافتكم لي 🙏`;
        await conn.sendMessage(idgru, { text: leaveMessage, mentions: [senderId] });
        await conn.groupLeave(idgru);
        await conn.sendMessage(m.chat, { text: `✅ *تمت المغادرة من المجموعة ${groupMetadata.subject} بنجاح.*` }, { quoted: m });
      } catch (error) {
        console.error(error);
        await conn.sendMessage(m.chat, { text: `❌ فشل في مغادرة المجموعة: ${error.message}` }, { quoted: m });
      }
    } else {
      await conn.sendMessage(m.chat, { 
        text: `⚠️ *الأمر غير معروف*\n\n📌 *الأوامر المتاحة:*\n- سحب\n- تصفيه\n- مغادرة\n\n📝 *مثال:*\n${usedPrefix + command} سحب-${Object.keys(conn.chats).find(j => j.endsWith('@g.us')) || 'معرف_المجموعة@g.us'}` 
      }, { quoted: m });
    }
  }
};

handler.help = ['groups', 'grouplist'];
handler.tags = ['info'];
handler.command = ['المجموعات', 'الجروبات'];
handler.owner = true;

export default handler;
