import { areJidsSameUser } from '@whiskeysockets/baileys'

let handler = async (m, { conn, args, command }) => {

  let users = Object.entries(global.db.data.users).map(([jid, data]) => ({
    jid,
    ...data
  }))

  let who = m.quoted
    ? m.quoted.sender
    : m.mentionedJid?.[0]
    ? m.mentionedJid[0]
    : m.sender

  let user = global.db.data.users[who]
  if (!user) throw '⚠️ المستخدم غير موجود في قاعدة البيانات'

  // ترتيب المستخدمين حسب الخبرة
  let sorted = [...users]
    .map(u => ({
      ...u,
      exp: u.exp || 0,
      level: u.level || 0,
      credit: u.credit || 0,
      bank: u.bank || 0
    }))
    .sort((a, b) => b.exp - a.exp)

  let rank = sorted.findIndex(u => areJidsSameUser(u.jid, who)) + 1
  let total = sorted.length

  // رابط الصورة
  let imageUrl = 'https://i.postimg.cc/9XRzwYTJ/IMG-20251230-WA0030.jpg'

  // ──────── 🔹 أمر (رتبتي / الرتبة) 🔹 ────────
  if (/^(رتبتي|الرتبة)$/i.test(command)) {
    let totalgold = (user.credit || 0) + (user.bank || 0)

    let text = `
╭──⊰ [👑 رتبتك الحالية 👑] ⊱──╮

*👤 الاسم:* ${user.name || 'مجهول'}
*🎯 المستوى:* ${user.level || 0}
*💎 الخبرة:* ${user.exp || 0}
*🏆 الرتبة:* ${user.role || 'مبتدئ'}

*👛 الرصيد:* ${user.credit || 0}
*🏦 البنك:* ${user.bank || 0}
*💰 المجموع:* ${totalgold}

📊 ترتيبك: *#${rank}* من *${total}* مستخدم

╰──⊰ 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 ⊱──╯
`.trim()

    return conn.sendMessage(m.chat, { image: { url: imageUrl }, caption: text }, { quoted: m })
  }

  // ──────── 🔹 أمر (المتصدرين / الترتيب) 🔹 ────────
  let limit = args[0] ? Math.min(50, Math.max(parseInt(args[0]), 5)) : 10

  let text = `
╭──⊰ [👑 قائمة المتصدرين 👑] ⊱──╮

${sorted.slice(0, limit).map((u, i) => {
  let totalgold = (u.credit || 0) + (u.bank || 0)
  return `
*#${i + 1}* 𓆩🌟𓆪
*👤 الاسم:* ${u.name || 'مجهول'}
*💎 الخبرة:* ${u.exp}
*🎯 المستوى:* ${u.level}
*🏆 الرتبة:* ${u.role || 'مبتدئ'}
*💰 المجموع:* ${totalgold}
───────────────`
}).join('\n')}

📊 ترتيبك: *#${rank}* من *${total}*

╰──⊰ 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 ⊱──╯
`.trim()

  conn.sendMessage(m.chat, { image: { url: imageUrl }, caption: text }, { quoted: m })
}

handler.help = ['رتبتي', 'المتصدرين']
handler.tags = ['xp']
handler.command = /^(رتبتي|الرتبة|المتصدرين|الترتيب)$/i

export default handler
