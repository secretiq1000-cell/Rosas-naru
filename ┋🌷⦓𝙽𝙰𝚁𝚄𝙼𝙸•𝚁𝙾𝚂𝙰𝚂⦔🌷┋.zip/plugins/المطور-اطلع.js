// Handler: الخروج من المجموعات (مُعدل — شخصية بــوت دانــى)
let handler = async (m, { conn, args, command, text }) => {
  // الأرقام المصرح لها بتنفيذ الأمر
  const allowedNumbers = [
    '201022950118@s.whatsapp.net', // الرقم الأول
    '123456789@s.whatsapp.net'  // الرقم الثاني
  ]

  // فحص السماح
  if (!allowedNumbers.includes(m.sender)) {
    return m.reply(`💀 سيدي... هذا القرار ليس بيدك.\nفقط رجال العائلة الموثوقون يملكون هذا الامتياز.\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`)
  }

  // تحديد المجموعة الهدف (المكتوبة أو الحالية)
  let group = text ? text : m.chat

  // صياغة رسالة الوداع حسب الأمر المستعمل
  let farewellMsg = ''
  switch (command) {
    case 'leavegc':
    case 'out':
      farewellMsg = `💀 لقد حان وقت الرحيل يا أصدقائي...\nأستودعكم الله.\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
      break
    case 'غادر':
    case 'اطلع':
      farewellMsg = `💀 كما يقولون... كل لقاء له نهاية.\nالآن، عليَّ أن أترككم.\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
      break
    case 'المجموعات':
      farewellMsg = `💀 يا سيدي، هذا الأمر مخصص لترك المجموعات فقط.\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
      break
    default:
      farewellMsg = `💀 وداعًا... سأغادر بهدوء.\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
  }

  // إرسال رسالة الوداع
  await conn.reply(group, farewellMsg, null)

  // مغادرة المجموعة (إلا إذا كان الأمر "المجموعات" فهو للعرض فقط)
  if (!/المجموعات/i.test(command)) {
    await conn.groupLeave(group)
  }
}

// المساعدة والأوامر
handler.help = ['leavegc', 'out', 'غادر', 'اطلع', 'المجموعات']
handler.tags = ['owner']
handler.command = /^(leavegc|out|غادر|اطلع)$/i
handler.owner = true

export default handler