import { jidDecode } from '@whiskeysockets/baileys'
import path from 'path'
import fs from 'fs'
import ws from 'ws'

const linkRegex = /https:\/\/chat\.whatsapp\.com\/([0-9A-Za-z]{20,24})/i
const handler = async (m, { conn, command, usedPrefix, text }) => {
try {
const isSubBots = [conn.user.jid, ...global.owner.map(([number]) => `${number}@s.whatsapp.net`)].includes(m.sender)
if (!isSubBots) return m.reply(`❀ الأمر *${command}* لا يمكن تنفيذه إلا من خلال الـ Socket.`)
switch (command) {

╭•─•─•─•─•╮
│ 🧩 أوامر التحكم في وضع البوت
╰•─•─•─•─•╯
case 'ذاتي': case 'عام': case 'مكافح_الخاص': case 'خاص': case 'مجموعات': case 'سولو': {
const config = global.db.data.settings[conn.user.jid]
const value = text ? text.trim().toLowerCase() : ''
const type = /ذاتي|عام/.test(command) ? 'self' : /مكافح_الخاص|خاص/.test(command) ? 'antiPrivate' : /مجموعات|سولو/.test(command) ? 'gponly' : null
if (!type) return m.reply(`ꕥ لم يتم التعرف على الوضع.`)
const isEnable = config[type] || false
const enable = value === 'تفعيل' || value === 'تشغيل'
const disable = value === 'تعطيل' || value === 'إيقاف'

if (enable || disable) {
if (isEnable === enable)
return m.reply(`ꕥ الوضع *${type}* كان بالفعل ${enable ? 'مفعل' : 'معطل'}.`)
config[type] = enable
return conn.reply(m.chat, `❀ لقد *${enable ? 'قمت بتفعيل' : 'قمت بإيقاف'}* وضع *${type}* في الـ Socket.`, m)
}

conn.reply(m.chat, `「✦」يمكنك تفعيل أو تعطيل وضع *${type}* باستخدام:\n\n● تفعيل » ${usedPrefix}${command} تفعيل\n● تعطيل » ${usedPrefix}${command} تعطيل\n\n✧ الحالة الحالية » *${isEnable ? '✓ مفعل' : '✗ معطل'}*`, m)
break
}

╭•─•─•─•─•╮
│ 🌸 الانضمام إلى المجموعات
╰•─•─•─•─•╯
case 'انضم': {
if (!text) return m.reply(`❀ يجب أن ترسل رابط دعوة للانضمام إلى مجموعة.`)
const [_, code] = text.match(linkRegex) || []
if (!code) return m.reply(`ꕥ رابط الدعوة غير صالح.`)
await m.react('🕒')
await conn.groupAcceptInvite(code)
await m.react('✔️')
m.reply(`❀ ${botname} انضم بنجاح إلى المجموعة.`)
break
}

╭•─•─•─•─•╮
│ 💨 أمر الخروج من المجموعة
╰•─•─•─•─•╯
case 'اخرج': case 'غادر': {
await m.react('🕒')
const id = text || m.chat
const chat = global.db.data.chats[m.chat]
chat.welcome = false
await conn.reply(id, `❀ وداعاً للجميع، ${botname} يودعكم! (≧ω≦)ゞ`)
await conn.groupLeave(id)
chat.welcome = true
await m.react('✔️')
break
}

╭•─•─•─•─•╮
│ 🔒 تسجيل الخروج
╰•─•─•─•─•╯
case 'تسجيل': case 'خروج': {
const rawId = conn.user?.id || ''
const cleanId = jidDecode(rawId)?.user || rawId.split('@')[0]
const index = global.conns?.findIndex(c => c.user.jid === m.sender)
if (global.conn.user.jid === conn.user.jid)
return conn.reply(m.chat, '❀ هذا الأمر معطل في الجلسات الرئيسية.', m)
if (index === -1 || !global.conns[index])
return conn.reply(m.chat, '⚠︎ الجلسة مغلقة بالفعل أو لم يتم العثور على اتصال نشط.', m)
conn.reply(m.chat, '✩ تم إغلاق جلستك بنجاح.', m)
setTimeout(async () => {
await global.conns[index].logout()
global.conns.splice(index, 1)
const sessionPath = path.join(global.jadi, cleanId)
if (fs.existsSync(sessionPath)) {
fs.rmSync(sessionPath, { recursive: true, force: true })
console.log(`⚠︎ تم حذف جلسة ${cleanId} من ${sessionPath}`)
}}, 3000)
break
}

╭•─•─•─•─•╮
│ 🔁 إعادة تحميل الجلسة
╰•─•─•─•─•╯
case 'إعادة': case 'تحديث': {
const rawId = conn.user?.id || ''
const cleanId = jidDecode(rawId)?.user || rawId.split('@')[0]
const sessionPath = path.join(global.jadi, cleanId)
if (!fs.existsSync(sessionPath)) return conn.reply(m.chat, '❀ هذا الأمر يمكن تنفيذه فقط من جلسة فرعية (Sub-Bot).', m)
await m.react('🕒')
if (typeof global.reloadHandler !== 'function')
throw new Error('لم يتم العثور على الدالة global.reloadHandler')
await global.reloadHandler(true)
await m.react('✔️')
conn.reply(m.chat, '✿ تم إعادة تحميل الجلسة بنجاح.', m)
break
}}} catch (error) {
await m.react('✖️')
conn.reply(m.chat, `⚠︎ حدثت مشكلة.\n> استخدم *${usedPrefix}ابلغ* للإبلاغ عنها.\n\n${error.message || error}`, m)
}}

handler.command = ['ذاتي', 'عام', 'مكافح_الخاص', 'خاص', 'مجموعات', 'سولو', 'انضم', 'اخرج', 'غادر', 'تسجيل', 'خروج', 'إعادة', 'تحديث']
handler.help = ['ذاتي', 'عام', 'مكافح_الخاص', 'خاص', 'مجموعات', 'سولو', 'انضم', 'اخرج', 'غادر', 'تسجيل', 'خروج', 'إعادة', 'تحديث']
handler.tags = ['socket']

export default handler