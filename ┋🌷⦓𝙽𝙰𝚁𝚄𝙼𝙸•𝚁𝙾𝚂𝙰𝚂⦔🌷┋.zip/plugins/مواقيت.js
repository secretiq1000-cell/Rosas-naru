import axios from 'axios';

// دالة لتحويل الوقت إلى النظام الـ12 ساعة
function format12HourTime(time24) {
  const [hours, minutes] = time24.split(':');
  let period = 'ص';
  let hours12 = parseInt(hours, 10);

  if (hours12 >= 12) {
    period = 'م';
    if (hours12 > 12) hours12 -= 12;
  }
  if (hours12 === 0) hours12 = 12;

  return `${hours12}:${minutes} ${period}`;
}

// خريطة المدن والدول (للاستعلام الصحيح)
const cityCountryMap = {
  // مصر
  'القاهرة': { city: 'Cairo', country: 'EG' },
  'الإسكندرية': { city: 'Alexandria', country: 'EG' },
  'الجيزة': { city: 'Giza', country: 'EG' },
  'قنا': { city: 'Qena', country: 'EG' },
  'أسوان': { city: 'Aswan', country: 'EG' },
  'الأقصر': { city: 'Luxor', country: 'EG' },
  'أسوان': { city: 'Aswan', country: 'EG' },
  'سوهاج': { city: 'Sohag', country: 'EG' },
  'أسيوط': { city: 'Asyut', country: 'EG' },
  'المنيا': { city: 'Minya', country: 'EG' },
  'بني سويف': { city: 'Beni Suef', country: 'EG' },
  'الفيوم': { city: 'Faiyum', country: 'EG' },
  'المنصورة': { city: 'Mansoura', country: 'EG' },
  'طنطا': { city: 'Tanta', country: 'EG' },
  'الزقازيق': { city: 'Zagazig', country: 'EG' },
  'الإسماعيلية': { city: 'Ismailia', country: 'EG' },
  'السويس': { city: 'Suez', country: 'EG' },
  'بورسعيد': { city: 'Port Said', country: 'EG' },
  'دمياط': { city: 'Damietta', country: 'EG' },
  'كفر الشيخ': { city: 'Kafr El Sheikh', country: 'EG' },
  'الغردقة': { city: 'Hurghada', country: 'EG' },
  'شرم الشيخ': { city: 'Sharm El Sheikh', country: 'EG' },
  'مرسى مطروح': { city: 'Marsa Matruh', country: 'EG' },
  
  // السعودية
  'الرياض': { city: 'Riyadh', country: 'SA' },
  'جدة': { city: 'Jeddah', country: 'SA' },
  'مكة': { city: 'Makkah', country: 'SA' },
  'المدينة': { city: 'Medina', country: 'SA' },
  'الدمام': { city: 'Dammam', country: 'SA' },
  'الخبر': { city: 'Khobar', country: 'SA' },
  'الظهران': { city: 'Dhahran', country: 'SA' },
  'تبوك': { city: 'Tabuk', country: 'SA' },
  'أبها': { city: 'Abha', country: 'SA' },
  'بريدة': { city: 'Buraidah', country: 'SA' },
  'حائل': { city: 'Hail', country: 'SA' },
  'نجران': { city: 'Najran', country: 'SA' },
  'جازان': { city: 'Jazan', country: 'SA' },
  
  // المغرب
  'الدار البيضاء': { city: 'Casablanca', country: 'MA' },
  'الرباط': { city: 'Rabat', country: 'MA' },
  'فاس': { city: 'Fes', country: 'MA' },
  'مراكش': { city: 'Marrakech', country: 'MA' },
  'طنجة': { city: 'Tangier', country: 'MA' },
  'أكادير': { city: 'Agadir', country: 'MA' },
  
  // الإمارات
  'دبي': { city: 'Dubai', country: 'AE' },
  'أبو ظبي': { city: 'Abu Dhabi', country: 'AE' },
  'الشارقة': { city: 'Sharjah', country: 'AE' },
  'عجمان': { city: 'Ajman', country: 'AE' },
  'رأس الخيمة': { city: 'Ras Al Khaimah', country: 'AE' },
  'الفجيرة': { city: 'Fujairah', country: 'AE' },
  'أم القيوين': { city: 'Umm Al Quwain', country: 'AE' },
  
  // الكويت
  'الكويت': { city: 'Kuwait City', country: 'KW' },
  'الفروانية': { city: 'Farwaniya', country: 'KW' },
  'حولي': { city: 'Hawally', country: 'KW' },
  
  // قطر
  'الدوحة': { city: 'Doha', country: 'QA' },
  'الوكرة': { city: 'Al Wakrah', country: 'QA' },
  'الخور': { city: 'Al Khor', country: 'QA' },
  
  // البحرين
  'المنامة': { city: 'Manama', country: 'BH' },
  'المحرق': { city: 'Muharraq', country: 'BH' },
  'الرفاع': { city: 'Riffa', country: 'BH' },
  
  // عمان
  'مسقط': { city: 'Muscat', country: 'OM' },
  'صلالة': { city: 'Salalah', country: 'OM' },
  'نزوى': { city: 'Nizwa', country: 'OM' },
  
  // الأردن
  'عمان': { city: 'Amman', country: 'JO' },
  'الزرقاء': { city: 'Zarqa', country: 'JO' },
  'إربد': { city: 'Irbid', country: 'JO' },
  'العقبة': { city: 'Aqaba', country: 'JO' },
  
  // لبنان
  'بيروت': { city: 'Beirut', country: 'LB' },
  'طرابلس': { city: 'Tripoli', country: 'LB' },
  'صيدا': { city: 'Sidon', country: 'LB' },
  
  // فلسطين
  'القدس': { city: 'Jerusalem', country: 'PS' },
  'غزة': { city: 'Gaza', country: 'PS' },
  'رام الله': { city: 'Ramallah', country: 'PS' },
  'نابلس': { city: 'Nablus', country: 'PS' },
  'الخليل': { city: 'Hebron', country: 'PS' },
  
  // سوريا
  'دمشق': { city: 'Damascus', country: 'SY' },
  'حلب': { city: 'Aleppo', country: 'SY' },
  'حمص': { city: 'Homs', country: 'SY' },
  'اللاذقية': { city: 'Latakia', country: 'SY' },
  
  // العراق
  'بغداد': { city: 'Baghdad', country: 'IQ' },
  'البصرة': { city: 'Basra', country: 'IQ' },
  'الموصل': { city: 'Mosul', country: 'IQ' },
  'أربيل': { city: 'Erbil', country: 'IQ' },
  
  // ليبيا
  'طرابلس': { city: 'Tripoli', country: 'LY' },
  'بنغازي': { city: 'Benghazi', country: 'LY' },
  'مصراتة': { city: 'Misrata', country: 'LY' },
  
  // تونس
  'تونس': { city: 'Tunis', country: 'TN' },
  'صفاقس': { city: 'Sfax', country: 'TN' },
  'سوسة': { city: 'Sousse', country: 'TN' },
  
  // الجزائر
  'الجزائر': { city: 'Algiers', country: 'DZ' },
  'وهران': { city: 'Oran', country: 'DZ' },
  'قسنطينة': { city: 'Constantine', country: 'DZ' },
  'عنابة': { city: 'Annaba', country: 'DZ' },
  
  // السودان
  'الخرطوم': { city: 'Khartoum', country: 'SD' },
  'أم درمان': { city: 'Omdurman', country: 'SD' },
  'بورتسودان': { city: 'Port Sudan', country: 'SD' },
  
  // اليمن
  'صنعاء': { city: 'Sanaa', country: 'YE' },
  'عدن': { city: 'Aden', country: 'YE' },
  'تعز': { city: 'Taiz', country: 'YE' }
};

const handler = async (m, { text, usedPrefix, command, conn }) => {
  const wm = '♡┆𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐┆♡';
  const userName = m.pushName || m.name || 'صديق';

  // صورة عشوائية للهيدر
  const images = [
    'https://ar.prayerinislam.com/wp-content/uploads/المشروع-في-المسجد.jpg',
    'https://islamonline.net/wp-content/uploads/2023/02/الإمام-والمؤذن-صلاة-الجماعة.jpg',
    'https://daleelalmasjed.com/upload/3021162680-258.png',
    'https://www.al-jazirah.com/2022/20220307/ln_69_1.jpg',
    'https://www.cairo24.com/UploadCache/libfiles/66/3/600x338o/426.jpg'
  ];
  const randomImage = images[Math.floor(Math.random() * images.length)];

  // إذا لم يكن هناك نص (لم يتم اختيار مدينة بعد)
  if (!text) {
    // تجميع المدن حسب الدول للعرض
    const citiesByCountry = {};
    for (const [city, data] of Object.entries(cityCountryMap)) {
      if (!citiesByCountry[data.country]) {
        citiesByCountry[data.country] = [];
      }
      citiesByCountry[data.country].push(city);
    }
    
    // أسماء الدول بالعربية
    const countryNames = {
      'EG': '🇪🇬 مصر',
      'SA': '🇸🇦 السعودية',
      'MA': '🇲🇦 المغرب',
      'AE': '🇦🇪 الإمارات',
      'KW': '🇰🇼 الكويت',
      'QA': '🇶🇦 قطر',
      'BH': '🇧🇭 البحرين',
      'OM': '🇴🇲 عمان',
      'JO': '🇯🇴 الأردن',
      'LB': '🇱🇧 لبنان',
      'PS': '🇵🇸 فلسطين',
      'SY': '🇸🇾 سوريا',
      'IQ': '🇮🇶 العراق',
      'LY': '🇱🇾 ليبيا',
      'TN': '🇹🇳 تونس',
      'DZ': '🇩🇿 الجزائر',
      'SD': '🇸🇩 السودان',
      'YE': '🇾🇪 اليمن'
    };
    
    // إنشاء أزرار لأهم 12 مدينة
    const mainCities = [
      'القاهرة', 'الرياض', 'دبي', 'الدار البيضاء',
      'القدس', 'عمان', 'بيروت', 'دمشق',
      'بغداد', 'طرابلس', 'تونس', 'الجزائر'
    ];
    
    const buttons = [];
    for (let city of mainCities) {
      if (cityCountryMap[city]) {
        buttons.push({
          buttonId: `${usedPrefix + command} ${city}`,
          buttonText: { displayText: city },
          type: 1
        });
      }
    }
    
    // إضافة زر لعرض قائمة كاملة
    buttons.push({
      buttonId: `${usedPrefix + command} قائمة`,
      buttonText: { displayText: '📋 عرض جميع المدن' },
      type: 1
    });
    
    // إرسال رسالة مع أزرار تفاعلية
    await conn.sendMessage(m.chat, {
      text: `🕌 *مــرحــبـا يــا ${userName}* 🕌\n\n` +
            `✨ *أهلاً بك في خدمة مواقيت الصلاة* ✨\n\n` +
            `📌 *المدن المتاحة:* ${Object.keys(cityCountryMap).length} مدينة\n` +
            `🌍 *الدول المتاحة:* ${Object.keys(citiesByCountry).length} دولة\n\n` +
            `اختر مدينتك من الأزرار أدناه:\n` +
            `─┄─┄─┄─┄─┄─┄─┄─┄─┄─\n` +
            `🕌 *المدن الرئيسية* 🕌`,
      footer: wm,
      buttons: buttons,
      headerType: 1,
      viewOnce: true,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 999,
        isForwarded: true
      }
    }, { quoted: m });
    
    return;
  }
  
  // عرض قائمة جميع المدن
  if (text === 'قائمة') {
    const allCities = Object.keys(cityCountryMap).sort();
    const citiesPerPage = 30;
    let message = `📋 *قائمة جميع المدن المتاحة* 📋\n\n`;
    message += `─┄─┄─┄─┄─┄─┄─┄─┄─┄─\n`;
    message += `📌 *إجمالي المدن:* ${allCities.length}\n`;
    message += `─┄─┄─┄─┄─┄─┄─┄─┄─┄─\n\n`;
    
    // عرض أول 30 مدينة
    const displayCities = allCities.slice(0, citiesPerPage);
    message += displayCities.map((city, i) => `${i + 1}. ${city}`).join('\n');
    
    if (allCities.length > citiesPerPage) {
      message += `\n\n✨ *و ${allCities.length - citiesPerPage} مدينة أخرى...* ✨\n`;
      message += `💡 *يمكنك كتابة اسم المدينة مباشرة للبحث*`;
    }
    
    // إضافة أزرار سريعة للمدن الرئيسية
    const quickButtons = [
      {
        buttonId: `${usedPrefix + command} القاهرة`,
        buttonText: { displayText: 'القاهرة' },
        type: 1
      },
      {
        buttonId: `${usedPrefix + command} الرياض`,
        buttonText: { displayText: 'الرياض' },
        type: 1
      },
      {
        buttonId: `${usedPrefix + command} دبي`,
        buttonText: { displayText: 'دبي' },
        type: 1
      }
    ];
    
    await conn.sendMessage(m.chat, {
      text: message,
      footer: wm,
      buttons: quickButtons,
      headerType: 1
    }, { quoted: m });
    return;
  }

  // البحث عن المدينة في الخريطة
  const cityEntry = cityCountryMap[text];
  if (!cityEntry) {
    // البحث عن مدن مشابهة
    const similarCities = Object.keys(cityCountryMap).filter(city => 
      city.includes(text) || text.includes(city)
    ).slice(0, 5);
    
    let errorMsg = `❌ *مدينة "${text}" غير موجودة* ❌\n\n`;
    errorMsg += `📌 *المدن المتاحة:* ${Object.keys(cityCountryMap).length} مدينة\n\n`;
    
    if (similarCities.length > 0) {
      errorMsg += `🔍 *هل تقصد:*\n`;
      errorMsg += similarCities.map(city => `• ${city}`).join('\n');
      errorMsg += `\n\n`;
    }
    
    errorMsg += `💡 *يمكنك:\n`;
    errorMsg += `• اختيار مدينة من القائمة\n`;
    errorMsg += `• كتابة "قائمة" لعرض جميع المدن*`;
    
    // عرض أزرار للمدن المقترحة
    const buttons = [];
    for (let city of similarCities.slice(0, 5)) {
      buttons.push({
        buttonId: `${usedPrefix + command} ${city}`,
        buttonText: { displayText: city },
        type: 1
      });
    }
    
    await conn.sendMessage(m.chat, {
      text: errorMsg,
      footer: wm,
      buttons: buttons,
      headerType: 1
    }, { quoted: m });
    return;
  }

  const { city, country } = cityEntry;

  try {
    // استدعاء API الصحيح
    const response = await axios.get(`http://api.aladhan.com/v1/timingsByCity`, {
      params: {
        city: city,
        country: country,
        method: 2,
        adjustment: 0
      },
      timeout: 10000
    });

    const timings = response.data.data.timings;
    const date = response.data.data.date.readable;
    const hijriDate = response.data.data.date.hijri.date;
    
    const fajr = format12HourTime(timings.Fajr);
    const sunrise = format12HourTime(timings.Sunrise);
    const dhuhr = format12HourTime(timings.Dhuhr);
    const asr = format12HourTime(timings.Asr);
    const maghrib = format12HourTime(timings.Maghrib);
    const isha = format12HourTime(timings.Isha);

    const prayerMessage = `🕌 *مواقيت الصلاة* 🕌\n\n` +
      `📍 *المدينة:* ${text}\n` +
      `🌍 *الدولة:* ${cityEntry.country}\n` +
      `📅 *التاريخ الميلادي:* ${date}\n` +
      `📅 *التاريخ الهجري:* ${hijriDate}\n` +
      `─┄─┄─┄─┄─┄─┄─┄─┄─┄─\n` +
      `☀️ *الفجر*    : ${fajr}\n` +
      `🌅 *الشروق*   : ${sunrise}\n` +
      `☀️ *الظهر*    : ${dhuhr}\n` +
      `🌇 *العصر*    : ${asr}\n` +
      `🌙 *المغرب*   : ${maghrib}\n` +
      `🌙 *العشاء*   : ${isha}\n` +
      `─┄─┄─┄─┄─┄─┄─┄─┄─┄─\n` +
      `${wm}\n\n` +
      `🕌 *اللهم تقبل منا الصلاة* 🕌`;

    // أزرار لمدن سريعة
    const quickCities = ['القاهرة', 'الرياض', 'دبي', 'قنا', 'أسوان', 'الأقصر'];
    const buttons = [];
    
    for (let cityName of quickCities) {
      if (cityName !== text && cityCountryMap[cityName]) {
        buttons.push({
          buttonId: `${usedPrefix + command} ${cityName}`,
          buttonText: { displayText: `📌 ${cityName}` },
          type: 1
        });
      }
    }
    
    buttons.push({
      buttonId: `${usedPrefix + command}`,
      buttonText: { displayText: '📋 العودة للقائمة' },
      type: 1
    });

    await conn.sendMessage(m.chat, {
      image: { url: randomImage },
      caption: prayerMessage,
      buttons: buttons,
      footer: wm,
      headerType: 1,
      contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 999,
        isForwarded: true
      }
    }, { quoted: m });

  } catch (error) {
    console.error('خطأ في جلب مواقيت الصلاة:', error);
    
    let errorMsg = `⚠️ *عذراً، حدث خطأ* ⚠️\n\n`;
    errorMsg += `لم أتمكن من الحصول على مواقيت الصلاة لمدينة *"${text}"*.\n\n`;
    errorMsg += `📌 *الأسباب المحتملة:*\n`;
    errorMsg += `• تأكد من اسم المدينة\n`;
    errorMsg += `• تحقق من اتصال الإنترنت\n`;
    errorMsg += `• حاول مرة أخرى لاحقاً\n\n`;
    errorMsg += `✨ *يمكنك اختيار مدينة أخرى من الأزرار أدناه* ✨`;
    
    const quickCities = ['القاهرة', 'الرياض', 'دبي', 'قنا', 'أسوان'];
    const buttons = [];
    
    for (let city of quickCities) {
      if (cityCountryMap[city]) {
        buttons.push({
          buttonId: `${usedPrefix + command} ${city}`,
          buttonText: { displayText: city },
          type: 1
        });
      }
    }
    
    await conn.sendMessage(m.chat, {
      text: errorMsg,
      footer: wm,
      buttons: buttons,
      headerType: 1
    }, { quoted: m });
  }
};

handler.command = ['الصلاة', 'مواقيت', 'الصلاه', 'prayer'];
handler.tags = ['tools'];
handler.help = ['مواقيت', 'مواقيت <اسم المدينة>', 'لعرض مواقيت الصلاة'];

export default handler;
