let handler = async (m, { conn, args, usedPrefix, command }) => {

    let who = m.mentionedJid && m.mentionedJid[0]
        ? m.mentionedJid[0]
        : m.quoted ? m.quoted.sender
        : args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        : false

    if (!who) return m.reply(
        `🍩 ضع تاغ للمستخدم أو أدخل رقمه أولاً!\n\nمثال:\n${usedPrefix + command} @${m.sender.split('@')[0]} 4`,
        false,
        { mentions: [m.sender] }
    )

    if (!global.db.data.users[who]) global.db.data.users[who] = {}
    let user = global.db.data.users[who]

    // ⛔ حظر مؤقت
    if (args[1]) {
        if (isNaN(args[1])) return m.reply('🍮 المدخل يجب أن يكون رقمًا فقط')

        let مدة = 86400000 * Number(args[1])
        let الآن = Date.now()

        user.bannedTime = الآن < (user.bannedTime || 0)
            ? user.bannedTime + مدة
            : الآن + مدة

        user.banned = true

        // ✅ إشعار في نفس الشات فقط
        m.reply(
            `🧁 تم حظر @${who.split('@')[0]} لمدة ${args[1]} يوم`,
            false,
            { mentions: [who] }
        )

    } else {
        // ⛔ حظر دائم
        user.banned = true
        user.bannedTime = 999

        m.reply(
            `🍫 تم حظر @${who.split('@')[0]} حظرًا دائمًا من استخدام البوت 🐤`,
            false,
            { mentions: [who] }
        )
    }
}

handler.help = ['banned', 'بان']
handler.tags = ['owner']
handler.command = /^(ban(user)?|banned(user)?|بان)$/i
handler.owner = true
handler.register = true

export default handler
