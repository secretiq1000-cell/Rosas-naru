let handler = async (m, { conn, args, command }) => {
    // 💀 توقيع لـي بوت
    const vitoSymbol = '𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀';
    
    // 💀 تحديد رسالة الخروج بناء على الأمر المستخدم
    let leaveMessage = '';
    
    if (command === 'out' || command === 'برا') {
        leaveMessage = `*💀 مش هتوحشوني... لـي بيقولكوا مع السلامه! اللي باعنا خسر دلعنا ⁦^⁠_⁠^⁩* \n\n${vitoSymbol}`;
    } else if (command === 'leavegc' || command === 'اخرج') {
        leaveMessage = `*💀 لـي بيسلم عليكوا ويقول: يلا باي يا حلوين! اللي مش عاجبه يروح يكلم نفسه 💀* \n\n${vitoSymbol}`;
    } else {
        leaveMessage = `*💀 مع السلامه يا جماعه... لـي مش هينسيكم! 💀* \n\n${vitoSymbol}`;
    }
    
    // 💀 إرسال رسالة الخروج
    await m.reply(leaveMessage);
    
    // 💀 مغادرة المجموعة
    await conn.groupLeave(m.chat);
}

// 💀 الأوامر المدعومة (عربي/إنجليزي)
handler.command = /^(out|برا|leavegc|اخرج)$/i;

// 💀 إعدادات الأمر
handler.group = true;
handler.rowner = true;

// 💀 توضيح الاستخدام للمستخدم
handler.help = [
    '💀 *الأوامر المتاحة:*',
    '• `out` أو `برا` - مغادرة المجموعة برسالة لـي الكلاسيكية',
    '• `leavegc` أو `اخرج` - مغادرة المجموعة برسالة مختلفة',
    '',
    '💀 *طريقة الاستخدام:*',
    'اكتب أحد هذه الأوامر في المجموعة المراد مغادرتها',
    'فقط مالك البوت يستطيع استخدام هذا الأمر!',
    '',
    '𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀'
];

export default handler;