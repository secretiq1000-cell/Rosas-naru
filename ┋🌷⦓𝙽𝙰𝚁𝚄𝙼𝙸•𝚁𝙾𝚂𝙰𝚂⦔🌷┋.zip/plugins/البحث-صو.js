import fetch from "node-fetch"
import yts from 'yt-search'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        let contoh = `${usedPrefix + command} سورة الكهف - ماهر المعيقلي`
        return m.reply(`
*⚠️ الاستخدام الصحيح:*
اكتب رابط يوتيوب أو اسم المقطع الذي تريد تحميله بصيغة MP3.

*مثال:* 
${contoh}
        `.trim())
    }

    await m.react('🎧')

    try {
        let videoUrl = text
        let duration = ''
        let title = ''
        let author = ''
        let image = ''

        // إذا لم يكن رابط يوتيوب، قم بالبحث
        if (!text.match(/youtu/gi)) {
            const search = await yts(text)
            if (!search.all.length) {
                await m.react('❌')
                return m.reply('❌ لم أجد أي نتائج لهذا البحث')
            }
            videoUrl = search.videos[0].url
            duration = search.videos[0].timestamp
            title = search.videos[0].title
            author = search.videos[0].author.name
            image = search.videos[0].thumbnail
        }

        // استخدام API delirius (نفس الذي في كود Barboza)
        const apiUrl = `https://api.delirius.store/download/ytmp3?url=${encodeURIComponent(videoUrl)}`
        
        const res = await fetch(apiUrl)
        const json = await res.json()

        if (!json.status || !json.data) {
            await m.react('❌')
            return m.reply('⚠️ خطأ في API، حاول مرة أخرى')
        }

        // استخراج البيانات من الـ API
        const data = json.data
        const finalTitle = title || data.title
        const finalAuthor = author || data.author
        const finalImage = image || data.image
        const downloadUrl = data.download
        const finalDuration = duration || data.duration

        let info = `📥 *جاري تحميل الصوت*

🎬 *العنوان:* ${finalTitle}
👤 *القناة:* ${finalAuthor}
⏱️ *المدة:* ${finalDuration || 'غير معروف'}
🎵 *الجودة:* MP3

⏳ جاري المعالجة...`

        // إرسال معلومات الفيديو مع الصورة
        if (finalImage) {
            await conn.sendMessage(m.chat, { 
                image: { url: finalImage }, 
                caption: info 
            }, { quoted: m })
        } else {
            await m.reply(info)
        }

        // إرسال الملف الصوتي
        await conn.sendMessage(m.chat, { 
            audio: { url: downloadUrl }, 
            mimetype: 'audio/mpeg',
            fileName: `${finalTitle.replace(/[^\w\s]/g, '')}.mp3`
        }, { quoted: m })

        await m.react('✅')

    } catch (e) {
        console.error(e)
        await m.react('❌')
        m.reply('❌ حدث خطأ: ' + (e.message || 'فشل التحميل'))
    }
}

handler.help = ['صو <رابط/بحث>']
handler.tags = ['downloader']
handler.command = ['صو']
handler.register = true

export default handler