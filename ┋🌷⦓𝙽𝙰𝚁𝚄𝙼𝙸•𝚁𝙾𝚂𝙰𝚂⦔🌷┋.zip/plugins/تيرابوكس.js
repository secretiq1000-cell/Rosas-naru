let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        return m.reply(
            `📦 *𝐓𝐞𝐫𝐚𝐛𝐨𝐱 𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝𝐞𝐫*\n\n` +
            `⚠️ *صيغة خاطئة!*\n\n` +
            `📌 *طريقة الاستخدام:*\n` +
            `*${usedPrefix + command} <رابط تيرابوكس>*\n\n` +
            `💡 *مثال:*\n` +
            `${usedPrefix + command} https://www.terabox.com/sharing/link?surl=xxxxx\n\n` +
            `🔹 *الأوامر المتاحة:*\n` +
            `• ${usedPrefix}terabox <رابط>\n` +
            `• ${usedPrefix}teraboxdl <رابط>\n` +
            `• ${usedPrefix}تيرابوكس <رابط>\n\n` +
            `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻`
        )
    }

    await m.react('⏳')
    await m.reply('🔄 جاري تحميل الملف من تيرابوكس... يرجى الانتظار قليلاً.')

    try {
        let apikey = 'cuki-x'
        let apiUrl = `https://api.cuki.biz.id/api/downloader/terabox?apikey=${apikey}&url=${encodeURIComponent(text.trim())}`
        
        let res = await fetch(apiUrl)
        let json = await res.json()

        if (!json.success || !json.results || !json.results.files || json.results.files.length === 0) {
            throw new Error('فشل في جلب البيانات أو لم يتم العثور على الملف.')
        }

        let data = json.results
        let fileInfo = data.files[0]

        let caption = `📦 *𝐓𝐞𝐫𝐚𝐛𝐨𝐱 𝐃𝐨𝐰𝐧𝐥𝐨𝐚𝐝𝐞𝐫*\n\n` +
            `📄 *اسم الملف:* ${fileInfo.name}\n` +
            `🗂️ *الحجم:* ${fileInfo.size}\n` +
            `🔗 *الرابط المختصر:* ${data.shortLink}\n\n` +
            `✅ *الحالة:* جاهز للتحميل\n\n` +
            `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻`

        await conn.sendMessage(m.chat, {
            document: { url: fileInfo.downloadLink },
            mimetype: 'application/octet-stream',
            fileName: fileInfo.name,
            caption: caption
        }, { quoted: m })

        await m.react('✅')
    } catch (e) {
        console.error(e)
        await m.react('❌')
        m.reply(`❌ *حدث خطأ:* فشل في تحميل الملف من تيرابوكس.\n\n` +
                `💡 *الأسباب المحتملة:*\n` +
                `• الرابط غير صالح\n` +
                `• الملف محذوف أو خاص\n` +
                `• خدمة التحميل معطلة حالياً\n\n` +
                `🔄 حاول مرة أخرى لاحقاً.\n\n` +
                `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻`)
    }
}

handler.help = ['terabox <رابط>', 'teraboxdl <رابط>', 'تيرابوكس <رابط>']
handler.tags = ['تحميل']
handler.command = /^(terabox|teraboxdl|تيرابوكس)$/i
handler.limit = true

export default handler
