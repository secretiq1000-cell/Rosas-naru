// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from "axios"
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// قائمة روابط تيك توك للأناشيد
const nasheedList = [
  'https://vt.tiktok.com/ZSBQsMT7c/',
  'https://vt.tiktok.com/ZSBQsJ56d/',
  'https://vt.tiktok.com/ZSBQsJhnM/',
  'https://vt.tiktok.com/ZSBQs8dmD/',
  'https://vt.tiktok.com/ZSBQshwaS/',
  'https://vt.tiktok.com/ZSBQskBVN/',
  'https://vt.tiktok.com/ZSBQs2u71/',
  'https://vt.tiktok.com/ZSBQsBWQ1/',
  'https://vt.tiktok.com/ZSBQsS7fg/',
  'https://vt.tiktok.com/ZSBQse2QD/',
  'https://vt.tiktok.com/ZSBQsN2Ca/',
  'https://vt.tiktok.com/ZSBQsLQ91/',
  'https://vt.tiktok.com/ZSBQpo1aB/',
  'https://vt.tiktok.com/ZSBQsSLW3/',
  'https://vt.tiktok.com/ZSBQs6cAN/',
]

const tempDir = './temp'
const indexFile = path.join(tempDir, 'last_nasheed.json')

if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

// دالة لجلب رابط الصوت من تيك توك
async function getTikTokAudio(url) {
  try {
    const { data } = await axios.get(`https://www.tikwm.com/api/`, {
      params: { url },
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      timeout: 15000
    })

    const result = data?.data
    if (!result) return null

    // جلب رابط الصوت (الموسيقى الأصلية)
    return result.music || result.hdplay || result.play
  } catch (e) {
    console.error('خطأ في جلب الصوت:', e.message)
    return null
  }
}

let handler = async (m, { conn }) => {
  const from = m.chat
  const imagePath = path.join(__dirname, '../resources/yahz.jpg')

  // قراءة آخر رقم أنشودة تم تشغيله
  let currentIndex = 0
  if (fs.existsSync(indexFile)) {
    try {
      const fileData = fs.readFileSync(indexFile, 'utf8')
      currentIndex = JSON.parse(fileData).last || 0
    } catch (e) {
      currentIndex = 0
    }
  }

  const selectedUrl = nasheedList[currentIndex]
  const nextIndex = (currentIndex + 1) % nasheedList.length
  fs.writeFileSync(indexFile, JSON.stringify({ last: nextIndex }))

  await m.react('⏳')

  const caption = `*┏━━ 🎧 أنشودة خاشعة ━━┓*

✨ أغلق عينيك...
🎶 ودع الكلمات تهمس لقلبك.

*┗━━━━━━━━━━━━━━┛*

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

  // إرسال الصورة
  if (fs.existsSync(imagePath)) {
    await conn.sendMessage(from, {
      image: fs.readFileSync(imagePath),
      caption: caption
    }, { quoted: m })
  } else {
    await conn.sendMessage(from, { text: caption }, { quoted: m })
  }

  // جلب الصوت من تيك توك
  try {
    const audioUrl = await getTikTokAudio(selectedUrl)
    
    if (!audioUrl) {
      throw new Error('لا يمكن الحصول على رابط الصوت')
    }

    // إرسال الصوت
    await conn.sendMessage(from, {
      audio: { url: audioUrl },
      mimetype: 'audio/mpeg',
      ptt: false
    }, { quoted: m })

    await m.react('✅')

  } catch (err) {
    console.error('خطأ:', err.message)
    await m.react('❌')
    await conn.sendMessage(from, {
      text: '❌ عذراً، حدث خطأ في تشغيل الأنشودة. حاول مرة أخرى لاحقاً.'
    }, { quoted: m })
  }
}

handler.command = ['انشوده', 'نشيد', 'nasheed']
handler.help = ['انشوده']
handler.category = 'ترفيه'
handler.description = '🎵 استمع إلى أنشودة خاشعة'

export default handler
