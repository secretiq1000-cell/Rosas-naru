let handler = async (m, { args, command, usedPrefix }) => {

    // السماح للمطور فقط
    const developer = '201022950118@s.whatsapp.net'
    if (m.sender !== developer) return m.reply('⚠️ هذا الأمر مخصص للمطور فقط.')

    let id = args[1] ? args[1] : m.chat
    let chat = global.db.data.chats[id]

    if (args[0]) {
        if (isNaN(args[0])) return m.reply('🍭 *المدخل يجب أن يكون رقمًا فقط! 💀*')
        let jumlahHari = 86400000 * args[0]
        let now = new Date() * 1
        if (now < chat.isBannedTime) chat.isBannedTime += jumlahHari
        else chat.isBannedTime = now + jumlahHari
        chat.isBanned = true
        m.reply(`🍬 *تم حظر هذه المجموعة لمدة ${args[0]} يوم! 💀*`)
    } else {
        chat.isBannedTime = 999
        chat.isBanned = true
        m.reply('🍓 *تم حظر هذه المجموعة بشكل دائم! 💀*')
    }

    let usage = `
💡 *لتوضيح استخدام الأمر:*  
يمكنك حظر المجموعة مؤقتًا أو دائمًا باستخدام الأمر \`${usedPrefix + command}\`  

📌 مثال:  
- لحظر المجموعة لمدة 3 أيام: \`${usedPrefix + command} 3\`  
- للحظر الدائم: \`${usedPrefix + command}\`  

𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀
`.trim()

    await m.reply(usage)
}

handler.help = ['banchat', 'بانشات']
handler.tags = ['owner']
handler.command = /^(ban(chat|gc)|بانشات)$/i
handler.owner = true

export default handler
