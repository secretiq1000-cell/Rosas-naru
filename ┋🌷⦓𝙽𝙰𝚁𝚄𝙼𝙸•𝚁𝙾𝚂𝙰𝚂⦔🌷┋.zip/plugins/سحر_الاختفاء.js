// كود الطرد السحري 🎩✨
// © rijalganzz 𝑀𝛩𝛩𝐷𝐸
let handler = async (m, { conn, usedPrefix, command, text }) => {
    let target = m.mentionedJid[0] 
        ? m.mentionedJid[0]
        : m.quoted
        ? m.quoted.sender
        : text
        ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        : false

    if (!target)
        return m.reply(
            `✋ *من فضلك رد على رسالة الشخص أو اعمله منشن!* \n\n📌 مثال:\n${usedPrefix + command} @${m.sender.split("@")[0]}`,
            false,
            { mentions: [m.sender] }
        )

    if (target == m.sender)
        return m.reply("❌ لا يمكنك طرد نفسك!")

    await m.reply("✨🎩 مرحبًا بكم في عرض السحر لهذه الليلة! 🎩✨")
    await delay(2000)
    await m.reply("🔮 اليوم سنقوم بفعل شيء مذهل... 🔮")
    await delay(2000)
    await m.reply("🧙‍♂️ استعدوا جيدًا... ركزوا أنظاركم هنا... 🧙‍♂️")
    await delay(2000)
    await m.reply("✨ سيم سلابيم... سنجعل أحدهم يختفي... ✨")
    await delay(2000)
    await m.reply("🎩 ابراكادابرا... شاهدوا بأعينكم... شيء عجيب سيحدث... 🎩")
    await delay(2000)
    await m.reply("🪄 هوكوس بوكوس... حان وقت الاختفاء... 🪄")
    await delay(2000)
    await m.reply("✨ استعدوا... في لمح البصر سيختفي... ✨")
    await delay(2000)
    await m.reply("🌟 *والآن...!* 🌟")
    await delay(1000)
    await m.reply("💥 *بوف!* لقد اختفى هذا العضو من المجموعة... 💥")
    await delay(2000)

    await conn.groupParticipantsUpdate(m.chat, [target], 'remove')
    await m.reply(`✅ تم طرد @${target.split("@")[0]} من المجموعة بنجاح 🧙‍♂️✨`, false, { mentions: [target] })
}

handler.help = ['سحر']
handler.tags = ['group']
handler.command = /^(سحر|سحر_الطرد|سحر_الاختفاء)$/i
handler.admin = true
handler.group = true
handler.botAdmin = true
export default handler

let delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))