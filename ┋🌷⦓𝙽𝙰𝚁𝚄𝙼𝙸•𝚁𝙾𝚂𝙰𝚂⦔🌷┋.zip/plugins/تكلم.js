// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios'

// الأصوات المتاحة مع معرفاتها
const voices = [
  { name: 'Elon', id: '271' },
  { name: 'Beast', id: '272' },
  { name: 'Cristiano', id: '273' },
  { name: 'Selena', id: '274' },
  { name: 'Donald', id: '275' }
]

let handler = async (m, { conn, text }) => {
  try {
    let args = text.trim().split(/\s+/)
    let query = text.trim()
    
    // أمر عرض الأصوات
    if (query === 'الاصوات' || query === 'voices') {
      let voiceList = `🎤 *الأصوات المتاحة* 🎤\n\n`
      voices.forEach((v, i) => {
        voiceList += `${i + 1}️⃣ *${v.name}*\n`
      })
      voiceList += `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
      return conn.sendMessage(m.chat, { text: voiceList }, { quoted: m })
    }
    
    // التحقق من وجود النص
    if (!text) {
      return conn.sendMessage(m.chat, {
        text: `🎤 *تحويل النص إلى صوت* 🎤

━━━━━━━━━━━━━━━━━
📝 *الاستخدام:* 
.تكلم <النص>

🎤 *مع الصوت:* 
.تكلم <رقم الصوت> <النص>

🎧 *الأصوات المتاحة:*
1️⃣ Elon
2️⃣ Beast
3️⃣ Cristiano
4️⃣ Selena
5️⃣ Donald

📋 *مثال:*
.تكلم 3 مرحبا

━━━━━━━━━━━━━━━━━
⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
      }, { quoted: m })
    }
    
    // تحديد الصوت والنص
    let voiceId = '271' // الصوت الافتراضي Elon
    let userText = text
    
    // التحقق إذا كان أول كلمة رقم صوت
    let firstWord = args[0]
    let voiceNum = parseInt(firstWord)
    
    if (!isNaN(voiceNum) && voiceNum >= 1 && voiceNum <= voices.length) {
      // إذا كان الرقم صحيحاً
      voiceId = voices[voiceNum - 1].id
      userText = args.slice(1).join(' ')
      
      if (!userText) {
        return conn.sendMessage(m.chat, {
          text: `❌ *يرجى كتابة النص بعد رقم الصوت*\n\nمثال: .تكلم 3 مرحبا`
        }, { quoted: m })
      }
    } else {
      // التحقق إذا كان أول كلمة اسم صوت
      let foundVoice = voices.find(v => v.name.toLowerCase() === firstWord.toLowerCase())
      if (foundVoice) {
        voiceId = foundVoice.id
        userText = args.slice(1).join(' ')
        if (!userText) {
          return conn.sendMessage(m.chat, {
            text: `❌ *يرجى كتابة النص بعد اسم الصوت*\n\nمثال: .تكلم Cristiano مرحبا`
          }, { quoted: m })
        }
      }
    }
    
    await conn.sendMessage(m.chat, { 
      text: `🎤 *جاري تحويل النص إلى صوت...*\n🎧 الصوت: ${voices.find(v => v.id === voiceId)?.name || 'Elon'}\n📝 النص: ${userText.substring(0, 50)}${userText.length > 50 ? '...' : ''}`
    }, { quoted: m })
    
    // طلب API
    const apiUrl = `https://helm-api.vercel.app/api/tts_ai/generate?text=${encodeURIComponent(userText)}&voice_id=${voiceId}`
    const response = await axios.get(apiUrl, { responseType: 'json' })
    
    if (response.data?.audio_url) {
      // إرسال الصوت
      await conn.sendMessage(m.chat, {
        audio: { url: response.data.audio_url },
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: m })
      
    } else {
      throw new Error('لم يتم الحصول على رابط الصوت')
    }
    
  } catch (err) {
    console.error('❌ خطأ:', err.message)
    await conn.sendMessage(m.chat, {
      text: `❌ *حدث خطأ أثناء تحويل النص إلى صوت*\n\n📛 ${err.message}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m })
  }
}

handler.command = ['تكلم']
handler.help = ['تكلم']
handler.category = 'tools'
handler.description = '🎤 تحويل النص إلى صوت بالذكاء الاصطناعي'

export default handler