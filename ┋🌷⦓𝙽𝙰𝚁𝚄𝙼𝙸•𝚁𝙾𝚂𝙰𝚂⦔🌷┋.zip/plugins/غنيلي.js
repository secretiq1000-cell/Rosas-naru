import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent, prepareWAMessageMedia, proto } = pkg;
import axios from "axios";

const IMAGE_URL = "https://files.catbox.moe/j6ljq6.jpg";

const genres = ["pop","rock","sad","rap","trap","lofi","arabic","chill","romantic","dance"];
const voices = ["male", "female", "robotic"];

let handler = async (m, { conn, text, usedPrefix, command }) => {

  if (command === "غنيلي") {
    if (!text) return m.reply(`💬 اكتب وصف الأغنية...\nمثال:\n${usedPrefix}سونو أغنية حزينة عن الفراق`);

    const media = await prepareWAMessageMedia(
      { image: { url: IMAGE_URL } },
      { upload: conn.waUploadToServer }
    );

    const rows = genres.map(g => ({
      title: g,
      id: `${usedPrefix}غنيلي-صوت ${encodeURIComponent(text)}|${g}`
    }));

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: { hasMediaAttachment: true, imageMessage: media.imageMessage },
              body: { text: `🎵 *الوصف:*\n"${text}"\n\nاختر نوع الموسيقى:` },
              footer: { text: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻" },
              nativeFlowMessage: {
                buttons: [{
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "أنواع الموسيقى",
                    sections: [{ title: "Genre List", rows }]
                  })
                }]
              }
            }
          }
        }
      },
      { userJid: conn.user.jid, quoted: m }
    );

    return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  }

  if (command === "غنيلي-صوت") {
    const [encodedDesc, genre] = text.split("|");
    const desc = decodeURIComponent(encodedDesc);

    const media = await prepareWAMessageMedia(
      { image: { url: IMAGE_URL } },
      { upload: conn.waUploadToServer }
    );

    const rows = voices.map(v => ({
      title: v,
      id: `${usedPrefix}غنيلي-توليد ${encodeURIComponent(desc)}|${genre}|${v}`
    }));

    const msg = generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: { hasMediaAttachment: true, imageMessage: media.imageMessage },
              body: { text: `🎵 *الوصف:*\n${desc}\n📌 النوع: ${genre}\n\nاختر نوع الصوت:` },
              footer: { text: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻" },
              nativeFlowMessage: {
                buttons: [{
                  name: "single_select",
                  buttonParamsJson: JSON.stringify({
                    title: "Voice Type",
                    sections: [{ title: "Voices", rows }]
                  })
                }]
              }
            }
          }
        }
      },
      { userJid: conn.user.jid, quoted: m }
    );

    return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  }

  if (command === "غنيلي-توليد") {
    const [encodedDesc, genre, voice] = text.split("|");
    const desc = decodeURIComponent(encodedDesc);

    const prompt = `${desc}. genre: ${genre}. voice: ${voice}. full AI song with lyrics and cover.`;

    await m.reply("⏳ جاري توليد الأغنية... الرجاء الانتظار.");

    try {
      const url = `https://arlecchino-bot.vercel.app/api/v1/ai/suno?prompt=${encodeURIComponent(prompt)}`;
      const { data } = await axios.get(url);

      if (!data.status || !data.data) return m.reply("❌ لم يتم إنشاء الأغنية.");

      const song = data.data;

      if (song.cover)
        await conn.sendMessage(
          m.chat,
          { image: { url: song.cover }, caption: "🎨 *غلاف الأغنية*" },
          { quoted: m }
        );

      await conn.sendMessage(
        m.chat,
        {
          audio: { url: song.audio },
          mimetype: "audio/mpeg",
          fileName: "suno-ai.mp3",
          caption: "🎵 *تم إنشاء الأغنية بنجاح!*"
        },
        { quoted: m }
      );

      if (song.lyrics && song.lyrics.trim() !== "")
        await conn.sendMessage(m.chat, { text: `📝 *الكلمات:*\n\n${song.lyrics}` }, { quoted: m });

    } catch (err) {
      console.error(err);
      m.reply("❌ حدث خطأ أثناء توليد الأغنية.");
    }
  }
};

handler.help = ['سونو <وصف الأغنية>', 'غنيلي-صوت', 'غنيلي-توليد'];
handler.tags = ['ai', 'music', 'audio'];
handler.command = ['غنيلي', 'غنيلي-صوت', 'غنيلي-توليد'];

export default handler;