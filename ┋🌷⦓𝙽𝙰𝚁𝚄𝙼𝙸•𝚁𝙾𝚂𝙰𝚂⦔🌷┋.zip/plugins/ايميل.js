// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios';
import pkg from "@whiskeysockets/baileys";
const { generateWAMessageFromContent, proto } = pkg;

// تخزين الإيميلات المؤقتة لكل مستخدم
let userEmails = new Map();

const createEmailButtons = (email) => {
    return [
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "📥 عرض الرسائل",
                id: `.رسائل ${email}`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🔄 إنشاء جديد",
                id: `.ايميل`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "📋 نسخ الإيميل",
                id: `.نسخ ${email}`
            })
        }
    ];
};

let handler = async (m, { conn }) => {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const generateUrl = 'https://helm-api.vercel.app/api/gmail/gmail/generate';
        const response = await axios.get(generateUrl);
        
        if (response.data?.status === 'success' && response.data?.email) {
            const email = response.data.email;
            
            // حفظ الإيميل للمستخدم
            userEmails.set(m.sender, {
                email: email,
                timestamp: Date.now()
            });
            
            const buttons = createEmailButtons(email);
            
            const msg = generateWAMessageFromContent(
                m.chat,
                {
                    viewOnceMessage: {
                        message: {
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: `📧 *البريد المؤقت* 📧

━━━━━━━━━━━━━━━━━
✅ *تم إنشاء الإيميل بنجاح!*

📌 *الإيميل:* \`${email}\`

⏳ *مدة الصلاحية:* مؤقت
💡 *اضغط على الأزرار أدناه لإدارة الإيميل*

━━━━━━━━━━━━━━━━━
👨‍💻 *Developer:* 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴 ⚡
━━━━━━━━━━━━━━━━━

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "Gmail Temporary Mail | اضغط على الأزرار"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    hasMediaAttachment: false,
                                    title: "📧 TEMP MAIL"
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons
                                })
                            })
                        }
                    }
                },
                {}
            );
            
            await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
            
        } else {
            throw new Error('فشل إنشاء الإيميل');
        }
        
    } catch (error) {
        console.error('خطأ:', error);
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        await conn.sendMessage(m.chat, {
            text: `❌ *فشل إنشاء الإيميل المؤقت*

📛 ${error.message}

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
        }, { quoted: m });
    }
};

// معالج عرض الرسائل مع أزرار قابلة لإعادة الاستخدام
handler.before = async (m, { conn }) => {
    if (!m.text) return;
    
    // عرض الرسائل
    if (m.text.startsWith('.رسائل ')) {
        const email = m.text.replace('.رسائل ', '').trim();
        
        await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
        
        try {
            const fetchUrl = `https://helm-api.vercel.app/api/gmail/gmail/fetch?address=${encodeURIComponent(email)}`;
            const response = await axios.get(fetchUrl);
            
            if (response.data?.status === 'success') {
                const mails = response.data.mails || [];
                const count = response.data.count || 0;
                
                if (count === 0) {
                    // إعادة إرسال الأزرار مع الإيميل نفسه
                    const buttons = createEmailButtons(email);
                    const msg = generateWAMessageFromContent(
                        m.chat,
                        {
                            viewOnceMessage: {
                                message: {
                                    interactiveMessage: proto.Message.InteractiveMessage.create({
                                        body: proto.Message.InteractiveMessage.Body.create({
                                            text: `📭 *لا توجد رسائل بعد*

📧 *الإيميل:* ${email}

💡 *انتظر وصول رسالة ثم اضغط على "تحديث"*

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
                                        }),
                                        footer: proto.Message.InteractiveMessage.Footer.create({
                                            text: "Gmail Temporary Mail"
                                        }),
                                        header: proto.Message.InteractiveMessage.Header.create({
                                            hasMediaAttachment: false,
                                            title: "📭 INBOX"
                                        }),
                                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                            buttons
                                        })
                                    })
                                }
                            }
                        },
                        {}
                    );
                    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                    return;
                }
                
                let message = `📬 *الرسائل الواردة* 📬

━━━━━━━━━━━━━━━━━
📧 *الإيميل:* ${email}
📊 *عدد الرسائل:* ${count}
━━━━━━━━━━━━━━━━━\n\n`;
                
                for (let i = 0; i < Math.min(mails.length, 5); i++) {
                    const mail = mails[i];
                    message += `📌 *الرسالة ${i + 1}*
├ 📝 *الموضوع:* ${mail.subject || 'بدون موضوع'}
├ 👤 *المرسل:* ${mail.from || 'غير معروف'}
├ ⏰ *الوقت:* ${mail.date || 'غير معروف'}
└ 📄 *المحتوى:* ${mail.body?.substring(0, 100) || 'لا يوجد محتوى'}${mail.body?.length > 100 ? '...' : ''}\n\n`;
                }
                
                message += `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`;
                
                // إعادة إرسال الأزرار مع الإيميل نفسه
                const buttons = createEmailButtons(email);
                
                const msg = generateWAMessageFromContent(
                    m.chat,
                    {
                        viewOnceMessage: {
                            message: {
                                interactiveMessage: proto.Message.InteractiveMessage.create({
                                    body: proto.Message.InteractiveMessage.Body.create({ text: message }),
                                    footer: proto.Message.InteractiveMessage.Footer.create({ text: "Gmail Temp Mail | اضغط على الأزرار" }),
                                    header: proto.Message.InteractiveMessage.Header.create({
                                        hasMediaAttachment: false,
                                        title: "📬 INBOX"
                                    }),
                                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
                                })
                            }
                        }
                    },
                    {}
                );
                
                await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
                
            } else {
                throw new Error('فشل جلب الرسائل');
            }
            
        } catch (error) {
            console.error('خطأ:', error);
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
            await conn.sendMessage(m.chat, {
                text: `❌ *فشل جلب الرسائل*

📛 ${error.message}

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
            }, { quoted: m });
        }
    }
    
    // معالج نسخ الإيميل
    if (m.text.startsWith('.نسخ ')) {
        const email = m.text.replace('.نسخ ', '').trim();
        
        // إعادة إرسال الأزرار مع الإيميل نفسه
        const buttons = createEmailButtons(email);
        
        const msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: `📧 *تم نسخ الإيميل*

\`${email}\`

✅ يمكنك استخدامه الآن

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: "Gmail Temporary Mail | اضغط على الأزرار"
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: false,
                                title: "📧 COPY"
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons
                            })
                        })
                    }
                }
            },
            {}
        );
        
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    }
};

handler.command = ['ايميل', 'temp'];
export default handler;