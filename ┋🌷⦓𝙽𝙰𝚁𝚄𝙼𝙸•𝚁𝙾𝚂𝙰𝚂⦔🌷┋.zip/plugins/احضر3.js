import axios from 'axios'
import * as cheerio from 'cheerio'

let handler = async (m, { conn, text }) => {

if (!text)
return m.reply('📌 مثال:\n.احضر3 https://example.com')

await conn.sendMessage(m.chat,{
react:{text:'⏳',key:m.key}
})

let الصور = []
let الفيديوهات = []
let اطارات = []

// روابط API بديلة
let apiList = [
`https://api.allorigins.win/raw?url=${encodeURIComponent(text)}`,
`https://api.codetabs.com/v1/proxy/?quest=${text}`,
`https://thingproxy.freeboard.io/fetch/${text}`
]

let data = null

for (let api of apiList) {
try {
let res = await axios.get(api, { 
timeout: 15000,
headers: { 'User-Agent': 'Mozilla/5.0' }
})
if (res.data && typeof res.data === 'string' && (res.data.includes('html') || res.data.length > 500)) {
data = res.data
break
}
} catch(e) {}
}

if (!data) {
try {
data = (await axios.get(text, {
timeout: 15000,
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Language': 'ar,en-US;q=0.7,en;q=0.3'
}
})).data
} catch(e) {}
}

if (!data) {
return m.reply(`❌ تعذر الوصول إلى الموقع: ${text}`)
}

try {
const $ = cheerio.load(data)

const fixUrl = (url) => {
if (!url) return null
if (url.startsWith('//')) return 'https:' + url
if (url.startsWith('/')) return new URL(url, text).href
if (url.startsWith('http')) return url
return null
}

// دالة متطورة لاستخراج أعلى جودة من الرابط
const getBestQualityFromUrls = (urls) => {
let bestUrl = urls[0]
let bestNumber = 0

for (let url of urls) {
// البحث عن أرقام مثل: 1080, 720, 480, 360, 240
let matches = url.match(/(\d{3,4})[pPx]|[-_](\d{3,4})[-_]|(\d{3,4})\.mp4|(\d{3,4})\//g)
if (matches) {
for (let match of matches) {
let num = parseInt(match.replace(/[^0-9]/g, ''))
if (!isNaN(num) && num > bestNumber && num >= 360) {
bestNumber = num
bestUrl = url
}
}
}
// كمان نفحص如果是 رابط YouTube
if (url.includes('youtube') || url.includes('youtu.be')) {
bestUrl = url
break
}
}
return bestUrl
}

// جلب كل الفيديوهات
let كل_الفيديوهات = []

// من video tags
$('video').each((i,el)=>{
let src = $(el).attr('src')
if(src) {
let fixed = fixUrl(src)
if(fixed) كل_الفيديوهات.push(fixed)
}
$(el).find('source').each((i,el2)=>{
let s = $(el2).attr('src')
if(s) {
let fixed = fixUrl(s)
if(fixed) كل_الفيديوهات.push(fixed)
}
})
})

// من source tags
$('source').each((i,el)=>{
let src = $(el).attr('src')
let type = $(el).attr('type') || ''
if(src && type.includes('video')) {
let fixed = fixUrl(src)
if(fixed) كل_الفيديوهات.push(fixed)
}
})

// من الروابط
$('a').each((i,el)=>{
let href = $(el).attr('href')
if(href && href.match(/\.(mp4|webm|mov|mkv|m3u8|ts)(\?|$)/i)) {
let fixed = fixUrl(href)
if(fixed) كل_الفيديوهات.push(fixed)
}
})

// من data attributes
$('[data-video], [data-src]').each((i,el)=>{
let video = $(el).attr('data-video')
let src = $(el).attr('data-src')
if(video && video.match(/\.(mp4|webm)/i)) {
let fixed = fixUrl(video)
if(fixed) كل_الفيديوهات.push(fixed)
}
if(src && src.match(/\.(mp4|webm)/i)) {
let fixed = fixUrl(src)
if(fixed) كل_الفيديوهات.push(fixed)
}
})

// إزالة التكرار
كل_الفيديوهات = [...new Set(كل_الفيديوهات)]

// تجميع الفيديوهات المتشابهة (نفس الاسم بدون الأرقام)
let videoGroups = {}
for (let video of كل_الفيديوهات) {
// إزالة الأرقام والجودة من الاسم
let baseName = video.replace(/\d{3,4}[pPx]?/gi, '').replace(/[-_]\d{3,4}[-_]/g, '').replace(/\.\d{3,4}\./g, '.').toLowerCase()
if (!videoGroups[baseName]) videoGroups[baseName] = []
videoGroups[baseName].push(video)
}

// اختيار أعلى جودة لكل مجموعة
for (let group in videoGroups) {
let bestVideo = getBestQualityFromUrls(videoGroups[group])
if (bestVideo) {
الفيديوهات.push(bestVideo)
}
}

// إذا ما في مجموعات، رتب تنازلي وخذ الأعلى
if (الفيديوهات.length === 0 && كل_الفيديوهات.length > 0) {
// ترتيب تنازلي حسب الجودة
كل_الفيديوهات.sort((a, b) => {
let numA = parseInt(a.match(/(\d{3,4})/)?.[0] || 0)
let numB = parseInt(b.match(/(\d{3,4})/)?.[0] || 0)
return numB - numA
})
الفيديوهات = كل_الفيديوهات
}

// جلب الصور
$('img').each((i,el)=>{
let src = $(el).attr('src') || $(el).attr('data-src') || $(el).attr('data-lazy-src')
if(src) {
let fixed = fixUrl(src)
if(fixed && fixed.match(/\.(jpg|jpeg|png|gif|webp)/i)) {
الصور.push(fixed)
}
}
})

// جلب iframe
$('iframe').each((i,el)=>{
let src = $(el).attr('src')
if(src && (src.includes('youtube.com/embed') || src.includes('youtu.be'))) {
اطارات.push(src)
}
})

الصور = [...new Set(الصور)]
اطارات = [...new Set(اطارات)]

// ترتيب الفيديوهات من الأعلى جودة للأدنى
الفيديوهات.sort((a, b) => {
let numA = parseInt(a.match(/(\d{3,4})/)?.[0] || 0)
let numB = parseInt(b.match(/(\d{3,4})/)?.[0] || 0)
return numB - numA
})

let نتيجة = `
╭•─•─•𓆩 ✦ سكــان ✦ 𓆪•─•─•╮

🌐 ${text}

🎬 الفيديوهات: ${الفيديوهات.length}
🖼 الصور: ${الصور.length}
📦 اطارات: ${اطارات.length}

╰•─•─•─•𓆩 ✦ 𓆪•─•─•─•─•╯
`

await m.reply(نتيجة)

// إرسال كل الفيديوهات (من الأعلى جودة للأدنى)
if (الفيديوهات.length > 0) {
let numSent = 0
let numFailed = 0

for (let i = 0; i < الفيديوهات.length; i++) {
if (numSent >= 15) break

try {
await conn.sendMessage(m.chat, {
video: { url: الفيديوهات[i] },
caption: `🎬 فيديو ${numSent + 1} (جودة: ${الفيديوهات[i].match(/(\d{3,4})/)?.[0] || '?'}p)`
})
numSent++
await new Promise(r => setTimeout(r, 2000))
} catch(e) {
numFailed++
continue
}
}

if (numFailed > 0) {
await m.reply(`⚠️ تم إرسال ${numSent} فيديو، فشل ${numFailed}`)
}
}

// إرسال الصور
if (الصور.length > 0) {
let numSent = 0
for (let img of الصور) {
if (numSent >= 20) break
try {
await conn.sendMessage(m.chat, {
image: { url: img },
caption: `🖼 صورة ${numSent + 1}`
})
numSent++
await new Promise(r => setTimeout(r, 500))
} catch(e) {}
}
}

if (اطارات.length > 0) {
let textFrame = '📦 روابط يوتيوب:\n\n'
for (let f of اطارات.slice(0, 10)) {
textFrame += `• ${f}\n`
}
await m.reply(textFrame)
}

if (الفيديوهات.length === 0 && الصور.length === 0) {
m.reply('⚠️ ما لقيتش فيديوهات أو صور')
}

} catch(e) {
m.reply(`❌ خطأ: ${e.message}`)
}
}

handler.command = ['احضر3']
export default handler
