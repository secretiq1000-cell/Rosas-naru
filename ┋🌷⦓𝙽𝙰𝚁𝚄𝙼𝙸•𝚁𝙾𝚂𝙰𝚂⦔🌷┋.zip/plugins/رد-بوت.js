let handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, {
    video: { url: "https://files.catbox.moe/l6pkpp.mp4" },
    caption: "> مـرحـبـا اســـــــمـي دانــــي الـشــبـح\n> مـــــطـوري  « مــــودي الــحاكم »\n\nاستـخـدم امـر (.اوامـر) لطلب الـقـائـمـة",
    ptv: true, // هذا يحول الفيديو إلى ملاحظة فيديو (دائرية)
    mimetype: "video/mp4"
  }, { quoted: m })
}

handler.customPrefix = /^يابوت|داني|عم بوت|بوتة|بوتت$/i
handler.command = new RegExp

export default handler