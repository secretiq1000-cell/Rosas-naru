import axios from 'axios'
import * as cheerio from 'cheerio'

let handler = async (m, { conn, text }) => {

if (!text)
return m.reply('📌 مثال:\n.احضر2 https://example.com')

await conn.sendMessage(m.chat,{
react:{text:'⏳',key:m.key}
})

let الصور = []
let الفيديوهات = []
let اطارات = []

// روابط API بديلة
let apiList = [
`https://api.allorigins.win/raw?url=${encodeURIComponent(text)}`,
`https://api.codetabs.com/v1/proxy/?quest=${text}`,
`https://thingproxy.freeboard.io/fetch/${text}`
]

let data = null

for (let api of apiList) {
try {
let res = await axios.get(api, { 
timeout: 15000,
headers: { 'User-Agent': 'Mozilla/5.0' }
})
if (res.data && typeof res.data === 'string' && (res.data.includes('html') || res.data.length > 500)) {
data = res.data
break
}
} catch(e) {}
}

if (!data) {
try {
data = (await axios.get(text, {
timeout: 15000,
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
'Accept-Language': 'ar,en-US;q=0.7,en;q=0.3'
}
})).data
} catch(e) {}
}

if (!data) {
return m.reply(`❌ تعذر الوصول إلى الموقع: ${text}`)
}

try {
const $ = cheerio.load(data)

const fixUrl = (url) => {
if (!url) return null
if (url.startsWith('//')) return 'https:' + url
if (url.startsWith('/')) return new URL(url, text).href
if (url.startsWith('http')) return url
return null
}

// دالة لاستخراج الجودة من الرابط
const getQuality = (url) => {
if (!url) return 0
let match = url.match(/(\d{3,4})[pPx]/) || 
            url.match(/[-_](\d{3,4})[-_]/) || 
            url.match(/(\d{3,4})\.mp4/) ||
            url.match(/[\/](\d{3,4})[\/]/)
if (match) {
let num = parseInt(match[1])
if (!isNaN(num)) return num
}
return 0
}

// جلب كل الفيديوهات
let كل_الفيديوهات = []

// من video tags
$('video').each((i,el)=>{
let src = $(el).attr('src')
if(src) {
let fixed = fixUrl(src)
if(fixed) كل_الفيديوهات.push(fixed)
}
$(el).find('source').each((i,el2)=>{
let s = $(el2).attr('src')
if(s) {
let fixed = fixUrl(s)
if(fixed) كل_الفيديوهات.push(fixed)
}
})
})

// من source tags
$('source').each((i,el)=>{
let src = $(el).attr('src')
let type = $(el).attr('type') || ''
if(src && type.includes('video')) {
let fixed = fixUrl(src)
if(fixed) كل_الفيديوهات.push(fixed)
}
})

// من الروابط
$('a').each((i,el)=>{
let href = $(el).attr('href')
if(href && href.match(/\.(mp4|webm|mov|mkv|m3u8|ts)(\?|$)/i)) {
let fixed = fixUrl(href)
if(fixed) كل_الفيديوهات.push(fixed)
}
})

// من data attributes
$('[data-video], [data-src]').each((i,el)=>{
let video = $(el).attr('data-video')
let src = $(el).attr('data-src')
if(video && video.match(/\.(mp4|webm)/i)) {
let fixed = fixUrl(video)
if(fixed) كل_الفيديوهات.push(fixed)
}
if(src && src.match(/\.(mp4|webm)/i)) {
let fixed = fixUrl(src)
if(fixed) كل_الفيديوهات.push(fixed)
}
})

// إزالة التكرار
كل_الفيديوهات = [...new Set(كل_الفيديوهات)]

// جلب الفيديوهات بجودة 360 و 720 (ونخليها كلها)
let videos360 = []
let videos720 = []
let videosOther = []

for (let video of كل_الفيديوهات) {
let quality = getQuality(video)
if (quality === 360) {
videos360.push({ url: video, quality: 360 })
} else if (quality === 720) {
videos720.push({ url: video, quality: 720 })
} else if (quality === 480 || quality === 1080 || quality > 720) {
videosOther.push({ url: video, quality: quality })
} else if (quality === 0 && !video.match(/240|270/)) {
// فيديوهات بدون جودة محددة نتجاهل الـ 240/270
videosOther.push({ url: video, quality: 480 })
}
}

// دمج الكل: 360 أولاً ثم 720 ثم الباقي
let allVideos = [...videos360, ...videos720, ...videosOther]

// إزالة التكرار بناءً على الرابط
let uniqueVideos = []
let seenUrls = new Set()
for (let v of allVideos) {
if (!seenUrls.has(v.url)) {
seenUrls.add(v.url)
uniqueVideos.push(v)
}
}
allVideos = uniqueVideos

// جلب الصور
$('img').each((i,el)=>{
let src = $(el).attr('src') || $(el).attr('data-src') || $(el).attr('data-lazy-src') || $(el).attr('data-original')
if(src) {
let fixed = fixUrl(src)
if(fixed && fixed.match(/\.(jpg|jpeg|png|gif|webp)/i)) {
الصور.push(fixed)
}
}
})

// جلب iframe
$('iframe').each((i,el)=>{
let src = $(el).attr('src')
if(src && (src.includes('youtube.com/embed') || src.includes('youtu.be'))) {
اطارات.push(src)
}
})

الصور = [...new Set(الصور)]
اطارات = [...new Set(اطارات)]

let نتيجة = `
╭•─•─•𓆩 ✦ سكــان ✦ 𓆪•─•─•╮

🌐 ${text}

🖼 الصور: ${الصور.length}
🎬 فيديوهات 360: ${videos360.length}
🎬 فيديوهات 720: ${videos720.length}
🎬 فيديوهات اخرى: ${videosOther.length}
📦 اطارات: ${اطارات.length}

╰•─•─•─•─•𓆩 ✦ 𓆪•─•─•─•╯
`

await m.reply(نتيجة)

// ===== إرسال الصور أولاً =====
if (الصور.length > 0) {
let numSent = 0
for (let img of الصور) {
if (numSent >= 25) break
try {
await conn.sendMessage(m.chat, {
image: { url: img },
caption: `🖼 صورة ${numSent + 1}/${Math.min(الصور.length, 25)}`
})
numSent++
await new Promise(r => setTimeout(r, 500))
} catch(e) {}
}
}

// ===== ثم إرسال الفيديوهات =====
if (allVideos.length > 0) {
let numSent = 0
let numFailed = 0

for (let i = 0; i < allVideos.length; i++) {
if (numSent >= 20) break

let video = allVideos[i]
let qualityText = `${video.quality}p`

try {
await conn.sendMessage(m.chat, {
video: { url: video.url },
caption: `🎬 فيديو ${numSent + 1}\n📺 الجودة: ${qualityText}`
})
numSent++
await new Promise(r => setTimeout(r, 2000))
} catch(e) {
numFailed++
continue
}
}

if (numFailed > 0) {
await m.reply(`⚠️ تم إرسال ${numSent} فيديو، فشل ${numFailed}`)
}
}

if (اطارات.length > 0) {
let textFrame = '📦 روابط يوتيوب:\n\n'
for (let f of اطارات.slice(0, 10)) {
textFrame += `• ${f}\n`
}
await m.reply(textFrame)
}

if (الصور.length === 0 && allVideos.length === 0) {
m.reply('⚠️ ما لقيتش صور أو فيديوهات')
}

} catch(e) {
m.reply(`❌ خطأ: ${e.message}`)
}
}

handler.command = ['احضر2']
export default handler
