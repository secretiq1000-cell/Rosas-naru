import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import axios from 'axios';
import fetch from 'node-fetch';
import crypto from 'crypto';
import yts from 'yt-search';
import fs from 'fs';
import path from 'path';

/* ========== الإعدادات العامة ========== */
const SEND_LIMIT_AUDIO = 70 * 1024 * 1024   // 70MB
const SEND_LIMIT_VIDEO = 100 * 1024 * 1024 // 100MB
const AXIOS_TIMEOUT = 60000
const DELETE_AFTER_HOURS = 2 // حذف الملفات بعد ساعتين
const TEMP_DIR = './tmp' // مجلد الملفات المؤقتة

// إنشاء مجلد التخزين المؤقت إذا لم يكن موجوداً
if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR, { recursive: true })
}

// إعداد axios
const http = axios.create({
  timeout: AXIOS_TIMEOUT,
  maxRedirects: 5,
  validateStatus: s => s >= 200 && s < 400
})

/* خزانة لتخزين معلومات الملفات المرسلة */
const sentFiles = new Map()

/* ====== SaveTube decrypt key ====== */
const anu = Buffer.from('C5D58EF67A7584E4A29F6C35BBC4EB12', 'hex')

function decryptSaveTube(enc) {
  const b = Buffer.from(enc.replace(/\s/g, ''), 'base64')
  const iv = b.subarray(0, 16)
  const data = b.subarray(16)
  const d = crypto.createDecipheriv('aes-128-cbc', anu, iv)
  return JSON.parse(Buffer.concat([d.update(data), d.final()]).toString())
}

/* ====== أدوات مساعدة ====== */
const headInfo = async (url) => {
    try {
        const response = await http.head(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        })
        return { 
            ok: response.status >= 200 && response.status < 400, 
            size: Number(response.headers['content-length'] || 0), 
            type: response.headers['content-type'] || '' 
        }
    } catch {
        try {
            const response = await http.get(url, { 
                responseType: 'stream',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            })
            return { 
                ok: response.status >= 200 && response.status < 400, 
                size: Number(response.headers['content-length'] || 0), 
                type: response.headers['content-type'] || '' 
            }
        } catch {
            return { ok: false, size: 0, type: '' }
        }
    }
}

const sizeStr = (n) => {
    if (!Number.isFinite(n)) return '-'
    const units = ['B', 'KB', 'MB', 'GB']
    let i = 0
    while (n >= 1024 && i < units.length - 1) { 
        n /= 1024
        i++ 
    }
    return `${n.toFixed(1)} ${units[i]}`
}

/* ====== وظائف التحميل من المصادر المختلفة ====== */

// المصدر 1: SaveNow.to (polling)
async function saveNowDownload(url, format) {
  const key = 'dfcb6d76f2f6a9894gjkege8a4ab232222'
  const initUrl = `https://p.savenow.to/ajax/download.php?copyright=0&format=${format}&url=${encodeURIComponent(url)}&api=${key}`

  const init = await fetch(initUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Android 13; Mobile; rv:146.0) Gecko/146.0 Firefox/146.0',
      Referer: 'https://y2down.cc/enSB/'
    }
  })
  const data = await init.json()
  if (!data.success) throw new Error('فشل بدء التحميل (SaveNow)')

  const progressUrl = `https://p.savenow.to/api/progress?id=${encodeURIComponent(data.id)}`

  let attempts = 0
  while (attempts < 30) {
    await new Promise(resolve => setTimeout(resolve, 2000))
    const response = await fetch(progressUrl, {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })
    const status = await response.json()
    if (status.progress === 1000 && status.download_url) {
      return {
        title: data.title || data.info?.title || 'audio/video',
        url: status.download_url,
        alternatives: status.alternative_download_urls || [],
        source: 'saveNow'
      }
    }
    attempts++
  }

  throw new Error('انتهى وقت انتظار SaveNow')
}

// المصدر 2: SaveTube
async function saveTubeDownload(url, type, quality) {
  try {
    const cdnRes = await axios.get('https://media.savetube.me/api/random-cdn', { timeout: 10000 })
    const cdn = cdnRes.data?.cdn
    if (!cdn) throw new Error('لم يتم جلب CDN من SaveTube')

    const info = await axios.post(`https://${cdn}/v2/info`, { url }, {
      headers: {
        'Content-Type': 'application/json',
        origin: 'https://ytsave.savetube.me',
        referer: 'https://ytsave.savetube.me/',
        'User-Agent': 'Mozilla/5.0'
      },
      timeout: 15000
    })

    if (!info.data?.status) throw new Error('فشل الحصول على معلومات (SaveTube)')

    const json = decryptSaveTube(info.data.data)

    const r = await axios.post(`https://${cdn}/download`, {
      id: json.id,
      key: json.key,
      downloadType: type,
      quality: String(quality)
    }, {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0',
        origin: 'https://ytsave.savetube.me',
        referer: 'https://ytsave.savetube.me/'
      },
      timeout: 20000
    })

    const downloadUrl = r.data?.data?.downloadUrl
    if (!downloadUrl) throw new Error('فشل الحصول على رابط التحميل (SaveTube)')

    return {
      title: json.title || 'video',
      thumbnail: json.thumbnail,
      duration: json.duration,
      url: downloadUrl,
      source: 'saveTube'
    }
  } catch (error) {
    throw new Error(`SaveTube: ${error.message}`)
  }
}

// المصدر 3: VidsSave
async function vidsSaveDownload(url, type, quality = null) {
  try {
    const res = await axios.post('https://api.vidssave.com/api/contentsite_api/media/parse',
      new URLSearchParams({
        auth: '20250901majwlqo',
        domain: 'api-ak.vidssave.com',
        origin: 'cache',
        link: url
      }).toString(), {
        headers: {
          'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
          'content-type': 'application/x-www-form-urlencoded',
          origin: 'https://vidssave.com',
          referer: 'https://vidssave.com/'
        },
        timeout: 15000
      }
    )

    const data = res.data?.data
    if (!data) throw new Error('فشل الحصول على بيانات (VidsSave)')
    const { title, thumbnail, duration, resources } = data

    let media
    if (type === 'audio') {
      media = resources.find(r => r.type === 'audio')
    } else {
      media = quality
        ? resources.find(r => r.type === 'video' && String(r.quality) === String(quality))
        : resources.find(r => r.type === 'video')
    }

    if (!media) throw new Error(`لم يتم العثور على ${type === 'audio' ? 'صوت' : 'فيديو'} في VidsSave`)

    return {
      title,
      thumbnail,
      duration,
      url: media.download_url,
      quality: media.quality,
      size: media.size,
      source: 'vidsSave'
    }
  } catch (error) {
    throw new Error(`VidsSave: ${error.message}`)
  }
}

// المصدر 4: YtMp3.gg (audio)
async function ytMp3Download(url, bitrate = '128') {
  try {
    const { data: v } = await axios.post('https://hub.y2mp3.co/', {
      audioBitrate: bitrate,
      audioFormat: 'mp3',
      brandName: 'ytmp3.gg',
      downloadMode: 'audio',
      url: url
    }, {
      headers: {
        'content-type': 'application/json',
        origin: 'https://ytmp3.gg',
        referer: 'https://ytmp3.gg/',
        'user-agent': 'Mozilla/5.0'
      },
      timeout: 15000
    })

    if (!v || !v.url) throw new Error('فشل الحصول على رابط (ytMp3)')
    return { title: v.filename || 'audio', url: v.url, size: v.size || null, source: 'ytMp3' }
  } catch (error) {
    throw new Error(`YtMp3: ${error.message}`)
  }
}

// المصدر 5: DDownr (polling)
async function ddownrDownload(url, type, format) {
  try {
    const params = type === 'mp3'
      ? { copyright: '0', format: type, audio_quality: format, url, api: 'dfcb6d76f2f6a9894gjkege8a4ab232222' }
      : { copyright: '0', format: format, url, api: 'dfcb6d76f2f6a9894gjkege8a4ab232222' }

    const metaRes = await axios.get('https://p.lbserver.xyz/ajax/download.php', { params, timeout: 10000 })
    const metadata = metaRes.data
    if (!metadata?.progress_url) throw new Error('فشل بدء DDownr')

    let progress = 0
    let json = null

    for (let i = 0; i < 300; i++) {
      const r = await axios.get(metadata.progress_url, { timeout: 10000 })
      json = r.data
      progress = json?.progress || progress
      if (progress >= 1000 && json.download_url) {
        return {
          title: metadata.title || metadata.info?.title || 'video',
          thumbnail: metadata.info?.image,
          url: json.download_url,
          alternatives: json.alternative_download_urls || [],
          source: 'ddownr'
        }
      }
      await new Promise(resolve => setTimeout(resolve, 40))
    }

    throw new Error('انتهى وقت انتظار DDownr')
  } catch (error) {
    throw new Error(`DDownr: ${error.message}`)
  }
}

/* ====== دوال المساعدة لاختيار أسرع مصدر ====== */
function tryWithTimeout(fnPromise, ms = 15000) {
  return new Promise((resolve, reject) => {
    let finished = false
    const timer = setTimeout(() => {
      if (!finished) {
        finished = true
        reject(new Error('timeout'))
      }
    }, ms)

    fnPromise()
      .then(res => {
        if (!finished) {
          finished = true
          clearTimeout(timer)
          resolve(res)
        }
      })
      .catch(err => {
        if (!finished) {
          finished = true
          clearTimeout(timer)
          reject(err)
        }
      })
  })
}

function firstResolved(promises) {
  return new Promise((resolve, reject) => {
    let rejections = 0
    const total = promises.length
    if (total === 0) return reject(new Error('No candidates'))
    promises.forEach(p => {
      p.then(res => resolve(res)).catch(() => {
        rejections++
        if (rejections === total) {
          reject(new Error('all candidates failed'))
        }
      })
    })
  })
}

// تحويل جودة الصوت إلى الصيغة المناسبة لكل مصدر
function mapAudioQuality(quality) {
    const qualityMap = {
        'mp3_128': '128',
        'mp3_320': '320',
        'flac': 'flac',
        'wav': 'wav',
        'webm': 'webm',
        'ogg': 'ogg'
    }
    return qualityMap[quality] || '128'
}

// تحويل جودة الفيديو للصيغة المناسبة
function mapVideoQuality(quality) {
    const qualityMap = {
        '144': '144',
        '240': '240',
        '360': '360',
        '480': '480',
        '720': '720',
        '1080': '1080',
        '1440': '1440',
        '4k': '2160'
    }
    return qualityMap[quality] || '360'
}

/**
 * getFastestSource(url, type, quality)
 * type: 'audio' | 'video'
 */
async function getFastestSource(url, type = 'video', quality = '360') {
  const candidates = []
  
  const audioQuality = mapAudioQuality(quality)
  const videoQuality = mapVideoQuality(quality)

  if (type === 'audio') {
    candidates.push(tryWithTimeout(() => saveNowDownload(url, 'mp3'), 12_000))
    candidates.push(tryWithTimeout(() => ytMp3Download(url, audioQuality), 10_000))
    candidates.push(tryWithTimeout(() => saveTubeDownload(url, 'audio', audioQuality), 12_000))
    candidates.push(tryWithTimeout(() => vidsSaveDownload(url, 'audio'), 12_000))
    candidates.push(tryWithTimeout(() => ddownrDownload(url, 'mp3', audioQuality), 14_000))
  } else {
    candidates.push(tryWithTimeout(() => vidsSaveDownload(url, 'video', videoQuality), 10_000))
    candidates.push(tryWithTimeout(() => saveNowDownload(url, videoQuality), 12_000))
    candidates.push(tryWithTimeout(() => saveTubeDownload(url, 'video', videoQuality), 12_000))
    candidates.push(tryWithTimeout(() => ddownrDownload(url, 'mp4', videoQuality), 14_000))
  }

  try {
    const result = await firstResolved(candidates)
    if (!result || !result.url) throw new Error('invalid result')
    return { 
      title: result.title || 'media', 
      url: result.url, 
      quality: result.quality, 
      size: result.size, 
      source: result.source || 'unknown' 
    }
  } catch (e) {
    // fallback sequential longer timeouts
    const seqList = type === 'audio'
      ? [
        () => tryWithTimeout(() => saveNowDownload(url, 'mp3'), 20000),
        () => tryWithTimeout(() => ytMp3Download(url, audioQuality), 15000),
        () => tryWithTimeout(() => saveTubeDownload(url, 'audio', audioQuality), 20000),
        () => tryWithTimeout(() => vidsSaveDownload(url, 'audio'), 20000),
        () => tryWithTimeout(() => ddownrDownload(url, 'mp3', audioQuality), 22000)
      ]
      : [
        () => tryWithTimeout(() => vidsSaveDownload(url, 'video', videoQuality), 20000),
        () => tryWithTimeout(() => saveNowDownload(url, videoQuality), 22000),
        () => tryWithTimeout(() => saveTubeDownload(url, 'video', videoQuality), 22000),
        () => tryWithTimeout(() => ddownrDownload(url, 'mp4', videoQuality), 24000)
      ]

    for (const fn of seqList) {
      try {
        const res = await fn()
        if (res && res.url) return { 
          title: res.title || 'media', 
          url: res.url, 
          quality: res.quality, 
          size: res.size, 
          source: res.source || 'unknown' 
        }
      } catch (_) { /* try next */ }
    }

    throw new Error('جميع المصادر فشلت أو استغرقت وقتاً طويلاً')
  }
}

/* ====== دوال تحميل وإرسال الملفات (معدلة) ====== */
async function downloadToTempFile(url, type, quality, title) {
    const timestamp = Date.now()
    const safeTitle = title.replace(/[^\w\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF\s-]/g, '_').substring(0, 100)
    
    let extension = 'mp3'
    if (type === 'audio') {
        if (quality.includes('flac')) extension = 'flac'
        else if (quality.includes('wav')) extension = 'wav'
        else if (quality.includes('webm')) extension = 'webm'
        else if (quality.includes('ogg')) extension = 'ogg'
        else extension = 'mp3'
    } else {
        extension = 'mp4'
    }
    
    const filename = `${safeTitle}_${quality}_${timestamp}.${extension}`
    const filePath = path.join(TEMP_DIR, filename)
    
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream',
            timeout: AXIOS_TIMEOUT,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': '*/*',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
                'Referer': 'https://www.youtube.com/'
            },
            maxRedirects: 5
        })
        
        const writer = fs.createWriteStream(filePath)
        response.data.pipe(writer)
        
        return new Promise((resolve, reject) => {
            writer.on('finish', () => resolve(filePath))
            writer.on('error', reject)
            
            setTimeout(() => {
                writer.destroy()
                reject(new Error('انتهى وقت تحميل الملف'))
            }, AXIOS_TIMEOUT)
        })
        
    } catch (error) {
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath)
        }
        throw new Error(`فشل في تحميل الملف: ${error.message}`)
    }
}

// دالة جديدة للتحميل المباشر بدون تخزين
async function sendDirectStream(conn, m, url, title, caption, type = 'audio') {
    try {
        const response = await axios({
            method: 'GET',
            url: url,
            responseType: 'stream',
            timeout: AXIOS_TIMEOUT,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        })
        
        const chunks = []
        for await (const chunk of response.data) {
            chunks.push(chunk)
            if (Buffer.concat(chunks).length > SEND_LIMIT_AUDIO && type === 'audio') break
            if (Buffer.concat(chunks).length > SEND_LIMIT_VIDEO && type === 'video') break
        }
        
        const buffer = Buffer.concat(chunks)
        
        if (type === 'audio') {
            await conn.sendMessage(m.chat, {
                audio: buffer,
                mimetype: 'audio/mpeg',
                fileName: `${title}.mp3`,
                caption: caption
            }, { quoted: m })
        } else {
            await conn.sendMessage(m.chat, {
                video: buffer,
                caption: caption
            }, { quoted: m })
        }
        
        return true
    } catch (error) {
        console.error('Direct stream error:', error)
        return false
    }
}

// دالة بديلة للتحميل باستخدام fetch
async function downloadWithFetch(url, filePath) {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), AXIOS_TIMEOUT)
    
    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': '*/*'
            },
            signal: controller.signal
        })
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`)
        }
        
        const buffer = await response.arrayBuffer()
        fs.writeFileSync(filePath, Buffer.from(buffer))
        
        clearTimeout(timeout)
        return filePath
    } catch (error) {
        clearTimeout(timeout)
        throw error
    }
}

/* جدولة الحذف التلقائي */
function scheduleFileDeletion(filePath, messageKey) {
    const deleteTime = DELETE_AFTER_HOURS * 60 * 60 * 1000
    
    setTimeout(async () => {
        try {
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath)
                console.log(`🗑️ تم حذف الملف: ${path.basename(filePath)}`)
            }
            sentFiles.delete(messageKey)
        } catch (error) {
            console.error('❌ خطأ في حذف الملف:', error)
        }
    }, deleteTime)
}

/* وظائف الإرسال المعدلة */
async function sendAudio(conn, m, url, quality = 'mp3_128') {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const qualityLabels = {
      'mp3_128': 'MP3 128kbps',
      'mp3_320': 'MP3 320kbps',
      'flac': 'FLAC',
      'wav': 'WAV',
      'webm': 'WebM Audio',
      'ogg': 'OGG'
    }
    
    try {
        const best = await getFastestSource(url, 'audio', quality)
        if (!best || !best.url) throw new Error('لم يتم الحصول على رابط تحميل')

        const { title, url: downloadUrl, source, size } = best
        
        console.log(`📥 تحميل من ${source}: ${downloadUrl.substring(0, 100)}...`)
        
        const head = await headInfo(downloadUrl)
        if (!head.ok) {
            throw new Error('الرابط غير صالح، جاري المحاولة بمصدر آخر...')
        }
        
        const fileSize = head.size || size || 0
        
        if (fileSize > SEND_LIMIT_AUDIO && fileSize > 0) {
            await conn.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
            await conn.sendMessage(m.chat, { 
                text: `⚠️ الملف كبير جداً (${sizeStr(fileSize)}).\n🔗 *الرابط المباشر:*\n${downloadUrl}\n\n🎵 *العنوان:* ${title}\n📡 *المصدر:* ${source}` 
            }, { quoted: m })
            return
        }

        const caption = `✅ *تم التحميل!*\n\n🎵 *العنوان:* ${title}\n🎧 *الجودة:* ${qualityLabels[quality] || quality}\n📡 *المصدر:* ${source}`
        
        const streamSent = await sendDirectStream(conn, m, downloadUrl, title, caption, 'audio')
        
        if (!streamSent) {
            const tempFilePath = await downloadWithFetch(downloadUrl, path.join(TEMP_DIR, `${Date.now()}_${title.substring(0, 30)}.mp3`))
            
            await conn.sendMessage(m.chat, { 
                audio: fs.readFileSync(tempFilePath), 
                mimetype: 'audio/mpeg',
                fileName: `${title}.mp3`,
                caption: caption
            }, { quoted: m })
            
            scheduleFileDeletion(tempFilePath, m.key.id)
        }
        
    } catch (error) {
        console.error("خطأ في تحميل وإرسال الصوت:", error)
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        
        try {
            const fallback = await getFastestSource(url, 'audio', quality)
            if (fallback && fallback.url) {
                return m.reply(`⚠️ تعذر تحميل الملف بسبب: ${error.message}\n\n🔗 *الرابط المباشر للتحميل:*\n${fallback.url}\n\n📌 قم بتحميله يدوياً من الرابط أعلاه.`)
            }
        } catch {}
        
        return m.reply(`❌ فشل التحميل:\n${error.message}`)
    }

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

async function sendVideo(conn, m, url, quality = '360') {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    const qualityLabels = {
      '144': '144p',
      '240': '240p',
      '360': '360p',
      '480': '480p',
      '720': '720p',
      '1080': '1080p',
      '1440': '1440p',
      '4k': '4K'
    }
    
    try {
        const best = await getFastestSource(url, 'video', quality)
        if (!best || !best.url) throw new Error('لم يتم الحصول على رابط تحميل')

        const { title, url: downloadUrl, source, size } = best
        
        console.log(`📥 تحميل فيديو من ${source}: ${downloadUrl.substring(0, 100)}...`)
        
        const head = await headInfo(downloadUrl)
        if (!head.ok) {
            throw new Error('الرابط غير صالح أو منتهي الصلاحية')
        }
        
        const fileSize = head.size || size || 0
        
        if (fileSize > SEND_LIMIT_VIDEO && fileSize > 0) {
            await conn.sendMessage(m.chat, { react: { text: '⚠️', key: m.key } })
            await conn.sendMessage(m.chat, { 
                text: `⚠️ الملف كبير جداً (${sizeStr(fileSize)}).\n🔗 *الرابط المباشر:*\n${downloadUrl}\n\n🎬 *الاسم:* ${title}\n📡 *المصدر:* ${source}` 
            }, { quoted: m })
            return
        }

        const caption = `✅ *تم التحميل!*\n\n🎬 *العنوان:* ${title}\n📹 *الجودة:* ${qualityLabels[quality] || quality}\n📡 *المصدر:* ${source}`
        
        const streamSent = await sendDirectStream(conn, m, downloadUrl, title, caption, 'video')
        
        if (!streamSent) {
            const tempFilePath = await downloadWithFetch(downloadUrl, path.join(TEMP_DIR, `${Date.now()}_${title.substring(0, 30)}.mp4`))
            
            await conn.sendMessage(m.chat, { 
                video: fs.readFileSync(tempFilePath), 
                caption: caption
            }, { quoted: m })
            
            scheduleFileDeletion(tempFilePath, m.key.id)
        }
        
    } catch (error) {
        console.error("خطأ في تحميل وإرسال الفيديو:", error)
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        
        try {
            const fallback = await getFastestSource(url, 'video', quality)
            if (fallback && fallback.url) {
                return m.reply(`⚠️ تعذر تحميل الفيديو بسبب: ${error.message}\n\n🔗 *الرابط المباشر:*\n${fallback.url}`)
            }
        } catch {}
        
        return m.reply(`❌ فشل تحميل الفيديو:\n${error.message}`)
    }

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

/* ====== وظائف استخراج المعلومات ====== */
function extractVideoId(url) {
    if (!url) return null
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/)([^&\s?]+)/,
        /youtube\.com\/embed\/([^&\s?]+)/,
        /youtube\.com\/v\/([^&\s?]+)/,
        /youtube\.com\/.*[?&]v=([^&\s]+)/
    ]
    for (const pattern of patterns) {
        const match = url.match(pattern)
        if (match && match[1]) return match[1]
    }
    return null
}

function isUrl(s) { 
    try { 
        new URL(s); 
        return true 
    } catch { 
        return false 
    }
}

/* تنظيف الملفات القديمة */
function cleanupOldFiles() {
    try {
        if (!fs.existsSync(TEMP_DIR)) return
        const files = fs.readdirSync(TEMP_DIR)
        const now = Date.now()
        const maxAge = DELETE_AFTER_HOURS * 60 * 60 * 1000
        
        files.forEach(file => {
            const filePath = path.join(TEMP_DIR, file)
            try {
                const stats = fs.statSync(filePath)
                const fileAge = now - stats.mtimeMs
                
                if (fileAge > maxAge) {
                    fs.unlinkSync(filePath)
                    console.log(`🗑️ تم تنظيف الملف القديم: ${file}`)
                }
            } catch (error) {
                console.error(`خطأ في تنظيف الملف ${file}:`, error)
            }
        })
    } catch (error) {
        console.error('خطأ في تنظيف الملفات القديمة:', error)
    }
}

cleanupOldFiles()
setInterval(cleanupOldFiles, 60 * 60 * 1000)

/* ====== واجهات المستخدم التفاعلية ====== */
async function sendFormatPicker(conn, m, { title, url, thumb, usedPrefix }) {
    let media
    
    try {
        media = await prepareWAMessageMedia(
            { image: { url: thumb } }, 
            { upload: conn.waUploadToServer }
        )
    } catch {
        media = { imageMessage: null }
    }

    const buttons = [
        { 
            name: 'quick_reply', 
            buttonParamsJson: JSON.stringify({ 
                display_text: '🎵 تحميل الصوت', 
                id: `${usedPrefix}يوتيوب صوت_خيارات ${url}` 
            }) 
        },
        { 
            name: 'quick_reply', 
            buttonParamsJson: JSON.stringify({ 
                display_text: '🎬 تحميل الفيديو', 
                id: `${usedPrefix}يوتيوب فيديو_خيارات ${url}` 
            }) 
        }
    ]

    const card = {
        body: { 
            text: `📥 *${title}*\n\nاختر نوع التحميل الذي تريده:`
        },
        footer: { text: 'YouTube Downloader • جميع الجودات المتاحة' },
        header: {
            title: 'YouTube Downloader',
            hasMediaAttachment: !!media.imageMessage,
            ...(media.imageMessage ? { imageMessage: media.imageMessage } : {})
        },
        nativeFlowMessage: { 
            buttons: buttons, 
            messageParamsJson: '' 
        }
    }

    const msg = generateWAMessageFromContent(
        m.chat, 
        { 
            viewOnceMessage: { 
                message: { 
                    interactiveMessage: card 
                } 
            } 
        }, 
        { 
            userJid: conn.user.jid,
            quoted: m
        }
    )
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

async function sendAudioQualityPicker(conn, m, { title, url, thumb, usedPrefix }) {
    let media
    
    try {
        media = await prepareWAMessageMedia(
            { image: { url: thumb } }, 
            { upload: conn.waUploadToServer }
        )
    } catch {
        media = { imageMessage: null }
    }

    const audioQualities = [
        { label: '🎵 MP3 128kbps', value: 'mp3_128' },
        { label: '🎵 MP3 320kbps', value: 'mp3_320' },
        { label: '🎵 FLAC (أعلى جودة)', value: 'flac' },
        { label: '🎵 WAV (جودة عالية)', value: 'wav' },
        { label: '🎵 WebM Audio', value: 'webm' },
        { label: '🎵 OGG Audio', value: 'ogg' }
    ]

    const quick = audioQualities.map(q => ({
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({ 
            display_text: q.label, 
            id: `${usedPrefix}يوتيوب تحميل_صوت ${url} ${q.value}` 
        })
    }))

    const card = {
        body: { text: `🎵 *${title}*\n\nاختر جودة الصوت المطلوبة:` },
        footer: { text: 'YouTube Downloader • جميع جودات الصوت' },
        header: {
            title: 'YouTube Downloader',
            hasMediaAttachment: !!media.imageMessage,
            ...(media.imageMessage ? { imageMessage: media.imageMessage } : {})
        },
        nativeFlowMessage: { buttons: quick, messageParamsJson: '' }
    }

    const msg = generateWAMessageFromContent(
        m.chat, 
        { 
            viewOnceMessage: { 
                message: { 
                    interactiveMessage: card 
                } 
            } 
        }, 
        { 
            userJid: conn.user.jid,
            quoted: m 
        }
    )
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

async function sendVideoQualityPicker(conn, m, { title, url, thumb, usedPrefix }) {
    let media
    
    try {
        media = await prepareWAMessageMedia(
            { image: { url: thumb } }, 
            { upload: conn.waUploadToServer }
        )
    } catch {
        media = { imageMessage: null }
    }

    const videoQualities = [
        { label: '🎬 144p (أصغر حجم)', value: '144' },
        { label: '🎬 240p (جودة منخفضة)', value: '240' },
        { label: '🎬 360p (جودة متوسطة)', value: '360' },
        { label: '🎬 480p (جودة جيدة)', value: '480' },
        { label: '🎬 720p (HD)', value: '720' },
        { label: '🎬 1080p (Full HD)', value: '1080' },
        { label: '🎬 1440p (2K)', value: '1440' },
        { label: '🎬 4K (أعلى جودة)', value: '4k' }
    ]

    const quick = videoQualities.map(q => ({
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({ 
            display_text: q.label, 
            id: `${usedPrefix}يوتيوب تحميل_فيديو ${url} ${q.value}` 
        })
    }))

    const card = {
        body: { text: `🎬 *${title}*\n\nاختر دقّة الفيديو المطلوبة:` },
        footer: { text: 'YouTube Downloader • جميع جودات الفيديو' },
        header: {
            title: 'YouTube Downloader',
            hasMediaAttachment: !!media.imageMessage,
            ...(media.imageMessage ? { imageMessage: media.imageMessage } : {})
        },
        nativeFlowMessage: { buttons: quick, messageParamsJson: '' }
    }

    const msg = generateWAMessageFromContent(
        m.chat, 
        { 
            viewOnceMessage: { 
                message: { 
                    interactiveMessage: card 
                } 
            } 
        }, 
        { 
            userJid: conn.user.jid,
            quoted: m 
        }
    )
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

/* ====== الأمر الرئيسي ====== */
let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args.length) {
        return conn.sendMessage(m.chat, {
            text: `
╔═══════════════════════════════╗
║   🎬 YouTube Downloader 🎬   ║
╚═══════════════════════════════╝

📝 *طريقة الاستخدام:*
1. *${usedPrefix + command} <اسم الفيديو>* ← البحث وعرض خيارات التحميل
2. *${usedPrefix + command} <رابط يوتيوب>* ← تحميل مباشر

🎵 *جودات الصوت المتاحة:*
- mp3_128 (MP3 128kbps)
- mp3_320 (MP3 320kbps) 
- flac (FLAC - أعلى جودة)
- wav (WAV - جودة استوديو)
- webm (WebM Audio)
- ogg (OGG Audio)

🎬 *جودات الفيديو المتاحة:*
- 144 (144p - أصغر حجم)
- 240 (240p)
- 360 (360p - إفتراضي)
- 480 (480p)
- 720 (720p - HD)
- 1080 (1080p - Full HD)
- 1440 (1440p - 2K)
- 4k (4K - أعلى جودة)

💡 *أمثلة:*
${usedPrefix + command} أغنية حزينة
${usedPrefix + command} https://youtu.be/xxxxx
${usedPrefix + command} mp3_320 https://youtu.be/xxxxx

👨‍💻 *المطور:* 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
`.trim()
        }, { quoted: m })
    }

    // التعامل مع أوامر التحكم الداخلية
    if (args[0] === 'تحميل_صوت' && args[1]) {
        const url = args[1]
        const quality = args[2] || 'mp3_128'
        
        if (!isUrl(url) || !/youtube\.com|youtu\.be/.test(url)) {
            return m.reply('❌ يرجى إدخال رابط يوتيوب صالح.')
        }
        
        return await sendAudio(conn, m, url, quality)
    }
    
    if (args[0] === 'تحميل_فيديو' && args[1]) {
        const url = args[1]
        const quality = args[2] || '360'
        
        if (!isUrl(url) || !/youtube\.com|youtu\.be/.test(url)) {
            return m.reply('❌ يرجى إدخال رابط يوتيوب صالح.')
        }
        
        return await sendVideo(conn, m, url, quality)
    }
    
    if (args[0] === 'صوت_خيارات' && args[1]) {
        const url = args[1]
        const videoId = extractVideoId(url)
        const thumb = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null
        
        let title = 'فيديو يوتيوب'
        try {
            const searchResult = await yts({ videoId })
            if (searchResult) {
                title = searchResult.title || 'فيديو يوتيوب'
            }
        } catch {}
        
        await sendAudioQualityPicker(conn, m, { title, url, thumb, usedPrefix })
        return
    }
    
    if (args[0] === 'فيديو_خيارات' && args[1]) {
        const url = args[1]
        const videoId = extractVideoId(url)
        const thumb = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null
        
        let title = 'فيديو يوتيوب'
        try {
            const searchResult = await yts({ videoId })
            if (searchResult) {
                title = searchResult.title || 'فيديو يوتيوب'
            }
        } catch {}
        
        await sendVideoQualityPicker(conn, m, { title, url, thumb, usedPrefix })
        return
    }

    // التحقق من الأوامر المباشرة للجودات
    const audioQualities = ['mp3_128', 'mp3_320', 'flac', 'wav', 'webm', 'ogg']
    const videoQualities = ['144', '240', '360', '480', '720', '1080', '1440', '4k']
    
    if ((audioQualities.includes(args[0]) || videoQualities.includes(args[0])) && args[1]) {
        const quality = args[0]
        const url = args.slice(1).join(' ')
        
        if (!isUrl(url) || !/youtube\.com|youtu\.be/.test(url)) {
            return m.reply('❌ يرجى إدخال رابط يوتيوب صالح.')
        }
        
        const isAudio = audioQualities.includes(quality)
        
        if (isAudio) {
            return await sendAudio(conn, m, url, quality)
        } else {
            return await sendVideo(conn, m, url, quality)
        }
    }

    // البحث أو التعامل مع الرابط
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    
    let url = isUrl(args[0]) ? args[0] : null
    let meta = null
    
    if (!url) {
        const query = args.join(' ')
        const r = await yts(query).catch(() => null)
        if (!r?.videos?.length) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
            return m.reply('❌ لم يتم العثور على نتائج.')
        }
        const v = r.videos[0]
        url = v.url
        meta = { title: v.title, thumb: v.thumbnail }
    } else {
        const videoId = extractVideoId(url)
        if (videoId) {
            try {
                const searchResult = await yts({ videoId })
                if (searchResult) {
                    meta = { 
                        title: searchResult.title || 'فيديو يوتيوب', 
                        thumb: searchResult.thumbnail || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` 
                    }
                }
            } catch {
                meta = { 
                    title: 'فيديو يوتيوب', 
                    thumb: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` 
                }
            }
        }
    }
    
    const videoId = extractVideoId(url)
    const thumb = meta?.thumb || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`
    const title = meta?.title || 'فيديو يوتيوب'
    
    await sendFormatPicker(conn, m, { title, url, thumb, usedPrefix })
}

handler.help = ['يوتيوب']
handler.tags = ['downloader']
handler.command = /^(يوتيوب)$/i
handler.limit = true

export default handler
