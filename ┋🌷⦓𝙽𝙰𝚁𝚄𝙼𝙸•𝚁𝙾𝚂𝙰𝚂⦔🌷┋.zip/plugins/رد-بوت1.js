let handler = m => m;

handler.all = async function (m) {

    // منع رد البوت على نفسه (آمن لكل الاتصالات)
    if (m.key && m.key.fromMe) return;

    let responses;

    if (/^تست$/i.test(m.text)) {
        responses = ['*❍╎🧸┊ هتقولي تست هوريك الليست😉*'];
    } 
    else if (/^بوت$/i.test(m.text)) {
        responses = ['> *اسـتـنـي بـطـࢪطـࢪ 🦦*']; 
    } 
    else if (/^نارو$/i.test(m.text)) {
        responses = ['> *قـلـبـو🧸🎀*'];
    }

    if (responses) {
        let randomIndex = Math.floor(Math.random() * responses.length);

        // 🔥 الرد من نفس الاتصال (رئيسي أو فرعي)
        await this.sendMessage(
            m.chat,
            { text: responses[randomIndex] },
            { quoted: m }
        );
    }

    return true;
};

export default handler;
