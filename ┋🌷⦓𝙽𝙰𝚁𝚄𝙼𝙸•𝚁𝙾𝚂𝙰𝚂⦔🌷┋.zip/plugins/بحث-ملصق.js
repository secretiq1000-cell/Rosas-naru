// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios'
import fs from 'fs'
import path from 'path'
import { exec } from 'child_process'
import webp from 'node-webpmux'
import crypto from 'crypto'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const PACK = '𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯'
const AUTHOR = '𝑫𝑨𝑵𝑵𝒀'

// إنشاء مجلد مؤقت داخل المشروع
const tmpDir = path.join(process.cwd(), 'tmp')
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

function generateStickerID() {
  return crypto.randomBytes(16).toString('hex')
}

function buildExifBuffer(packname, author, id, description, emojis = ['🥺']) {
  const raw = {
    'sticker-pack-id': id,
    'sticker-pack-name': packname,
    'sticker-pack-publisher': author,
    'sticker-pack-desc': description,
    emojis
  }
  const data = Buffer.from(JSON.stringify(raw), 'utf8')
  const header = Buffer.from([
    0x49,0x49,0x2a,0x00,0x08,0x00,0x00,0x00,
    0x01,0x00,0x41,0x57,0x07,0x00,0x00,0x00,
    0x00,0x00,0x16,0x00,0x00,0x00
  ])
  const exif = Buffer.concat([header, data])
  exif.writeUIntLE(data.length, 14, 4)
  return exif
}

async function addExifToWebp(webpBuffer, packname, author, description) {
  const img = new webp.Image()
  await img.load(webpBuffer)
  const id = generateStickerID()
  img.exif = buildExifBuffer(packname, author, id, description)
  return await img.save(null)
}

async function convertToWebpFFmpeg(inputPath, outputPath) {
  return new Promise((resolve, reject) => {
    const cmd = `ffmpeg -y -i "${inputPath}" -vcodec libwebp -filter:v "scale=512:512:force_original_aspect_ratio=decrease,fps=15" -lossless 1 -compression_level 6 -q:v 80 "${outputPath}"`
    exec(cmd, (err) => err ? reject(err) : resolve())
  })
}

let handler = async (m, { conn, text }) => {
  try {
    const jid = m.chat
    const queryText = text.trim()

    if (!queryText) {
      return conn.sendMessage(jid, { 
        text: `⚠️ *أدخل مصطلح البحث*\n\nمثال: .بحث-ملصق غابة\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐` 
      }, { quoted: m })
    }

    await conn.sendMessage(jid, { 
      text: `🔍 *جاري البحث عن:* ${queryText}\n⏳ يرجى الانتظار...` 
    }, { quoted: m })

    const res = await axios.get(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(queryText)}`)
    const results = res.data?.data?.filter(i => i.image_url) || []

    if (results.length === 0) {
      return conn.sendMessage(jid, { 
        text: `❌ *لم يتم العثور على صور* لـ "${queryText}"\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐` 
      }, { quoted: m })
    }

    // تحديد الشخص المستهدف
    let target = m.sender
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      target = m.mentionedJid[0]
    } else if (m.quoted) {
      target = m.quoted.sender
    }
    
    const targetName = target.split('@')[0]

    const selected = results.slice(0, Math.min(3, results.length))
    let successCount = 0

    for (const [i, item] of selected.entries()) {
      try {
        const response = await axios.get(item.image_url, { responseType: 'arraybuffer', timeout: 15000 })
        const tempInput = path.join(tmpDir, `input_${Date.now()}_${i}.jpg`)
        const tempOutput = path.join(tmpDir, `sticker_${Date.now()}_${i}.webp`)

        fs.writeFileSync(tempInput, response.data)
        await convertToWebpFFmpeg(tempInput, tempOutput)

        const webpBuffer = fs.readFileSync(tempOutput)
        const description = item.description || queryText
        const stickerBuffer = await addExifToWebp(webpBuffer, PACK, AUTHOR, description)

        await conn.sendMessage(jid, { sticker: stickerBuffer }, { quoted: m })

        fs.unlinkSync(tempInput)
        fs.unlinkSync(tempOutput)
        successCount++

      } catch (err) {
        console.error('⚠️ فشل الملصق:', err.message)
      }
    }

    await conn.sendMessage(jid, { 
      text: `✅ *تم إنشاء ${successCount} ملصق* ✨\n🔍 بحث: ${queryText}\n👤 لـ @${targetName}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
      mentions: [target]
    }, { quoted: m })

  } catch (err) {
    console.error('[بحث-ملصق] خطأ:', err.message)
    await conn.sendMessage(m.chat, { 
      text: `❌ *حدث خطأ أثناء البحث*\n\n${err.message}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐` 
    }, { quoted: m })
  }
}

handler.command = ['بحث-ملصق']
handler.help = ['بحث-ملصق']
handler.category = 'tools'
handler.description = '🔍 البحث عن صور وتحويلها لملصقات باستخدام FFmpeg وwebpmux'

export default handler
