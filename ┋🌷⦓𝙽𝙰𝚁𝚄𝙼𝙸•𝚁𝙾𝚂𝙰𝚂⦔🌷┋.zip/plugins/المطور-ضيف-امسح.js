import fs from 'fs'

// 📌 قائمة الأرقام المسموح لها بالتنفيذ
const allowedNumbers = [
  '201553801908@s.whatsapp.net', // الرقم الأول
  '201553801908@s.whatsapp.net', // الرقم الأول
  '201044689315@s.whatsapp.net'  // الرقم الثاني
]

const handler = async (m, { text, command, conn }) => {
  if (!allowedNumbers.includes(m.sender)) {
    await conn.sendMessage(m.chat, { text: `*❍╎🧸┊ غير مسموح لك يا عب*د` }, { quoted: m })
    return
  }

  if (!text) throw `🤔 امم.. ما الاسم الذي أعطيه للأمر؟`

  const path = `plugins/${text}.js`

  if (command === 'ضيف') {
    if (!m.quoted || !m.quoted.text) throw `📩 لازم ترد على رسالة فيها كود ليتم حفظه!`

    fs.writeFileSync(path, m.quoted.text, 'utf8')

    m.reply(`✅ تم الحفظ باسم *${path}* بنجاح!`)
  } else if (command === 'امسح') {
    if (!fs.existsSync(path)) throw `❌ الملف *${path}* غير موجود لحذفه!`

    fs.unlinkSync(path)

    m.reply(`🗑️ تم حذف الملف *${path}* بنجاح!`)
  }
}

handler.help = ['ضيف', 'امسح']
handler.tags = ['owner']
handler.command = /^(ضيف|امسح)$/i
handler.mods = true

export default handler
