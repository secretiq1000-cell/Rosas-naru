// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys'

let players = {}
let currentQuiz = 0
let timeoutId = null
let activeGame = false

const quizzes = [
    { question: "في أي فيلم نجد العبارة الشهيرة: 'أنا أبوك'؟", answer: "حرب النجوم", options: ["حرب النجوم", "هاري بوتر", "العراب", "تيتانيك"], hint: "الفيلم ينتمي إلى فئة الخيال العلمي." },
    { question: "من هو الممثل الذي لعب دور 'الرجل الحديدي' في عالم مارفل السينمائي؟", answer: "روبرت داوني جونيور", options: ["كريس إيفانز", "كريس هيمسوورث", "روبرت داوني جونيور", "مارك روفالو"], hint: "الممثل لعب دور عبقري وملياردير." },
    { question: "ما اسم المسلسل الذي يتحدث عن مملكة 'ويستروس' وصراعها على العرش؟", answer: "صراع العروش", options: ["صراع العروش", "الأصدقاء", "اختلال ضال", "مكتبتي الصغيرة"], hint: "المسلسل يتضمن تنانين وممالك." },
    { question: "ما اسم كوكب الأرض في اللغة الإسبانية؟", answer: "Tierra", options: ["Tierra", "Terra", "Erd", "Earth"], hint: "الاسم يشير إلى الأرض." },
    { question: "من هو مؤسس شركة مايكروسوفت؟", answer: "بيل غيتس", options: ["ستيف جوبز", "بيل غيتس", "مارك زوكربيرغ", "إيلون ماسك"], hint: "الشخص المشهور بإنشاء ويندوز." }
]

const maxQuestions = 5

let handler = async (m, { conn, command, text }) => {
    // أمر بدء اللعبة
    if (command === 'مسلسلات') {
        if (activeGame) {
            return conn.sendMessage(m.chat, { text: '⚠️ هناك لعبة نشطة حالياً!' }, { quoted: m })
        }
        
        players = {}
        currentQuiz = 0
        activeGame = true
        
        await conn.sendMessage(m.chat, { text: '🎬 *بدأت الفعالية!* 🎬\n\nاستعدوا للأسئلة حول الأفلام والمسلسلات.\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐' }, { quoted: m })
        await askQuiz(conn, m)
    }
    
    // أمر الإجابة
    else if (command === 'اجابة') {
        if (!activeGame) {
            return conn.sendMessage(m.chat, { text: '⚠️ لا توجد لعبة نشطة! اكتب *مسلسلات* لبدء اللعبة.' }, { quoted: m })
        }
        
        const player = m.sender
        const playerName = player.split('@')[0]
        
        if (!players[player]) {
            players[player] = { points: 0, attempts: 0, name: playerName }
        }
        
        const userAnswer = text?.trim().toLowerCase()
        const correctAnswer = quizzes[currentQuiz].answer.toLowerCase()
        
        if (userAnswer === correctAnswer) {
            players[player].points += 1
            players[player].attempts = 0
            
            if (timeoutId) clearTimeout(timeoutId)
            
            await conn.sendMessage(m.chat, { 
                text: `✅ *إجابة صحيحة!* @${playerName}\n⭐ +1 نقطة\n\n↻ انتقل إلى السؤال التالي...`,
                mentions: [player]
            }, { quoted: m })
            
            currentQuiz++
            
            if (currentQuiz < maxQuestions) {
                setTimeout(() => askQuiz(conn, m), 2000)
            } else {
                activeGame = false
                await conn.sendMessage(m.chat, { 
                    text: `🎉 *انتهت الفعالية!* 🎉\n\n${getLeaderboard()}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
                    mentions: Object.keys(players)
                }, { quoted: m })
            }
        } else {
            players[player].attempts += 1
            
            if (players[player].attempts >= 2) {
                if (timeoutId) clearTimeout(timeoutId)
                
                await conn.sendMessage(m.chat, { 
                    text: `❌ *انتهت محاولاتك!*\n\nالإجابة الصحيحة هي: *${quizzes[currentQuiz].answer}*\n\n↻ انتقل إلى السؤال التالي...`,
                    mentions: [player]
                }, { quoted: m })
                
                players[player].attempts = 0
                currentQuiz++
                
                if (currentQuiz < maxQuestions) {
                    setTimeout(() => askQuiz(conn, m), 2000)
                } else {
                    activeGame = false
                    await conn.sendMessage(m.chat, { 
                        text: `🎉 *انتهت الفعالية!* 🎉\n\n${getLeaderboard()}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
                        mentions: Object.keys(players)
                    }, { quoted: m })
                }
            } else {
                await conn.sendMessage(m.chat, { 
                    text: `❌ *إجابة خاطئة!* @${playerName}\n📝 إجابتك: ${text}\n💡 تبقى لديك ${2 - players[player].attempts} محاولة`,
                    mentions: [player]
                }, { quoted: m })
            }
        }
    }
    
    // أمر النتائج
    else if (command === 'نتيجة') {
        if (Object.keys(players).length === 0) {
            return conn.sendMessage(m.chat, { text: '📊 لا توجد نتائج حالياً. ابدأ لعبة جديدة بـ *مسلسلات*' }, { quoted: m })
        }
        await conn.sendMessage(m.chat, { text: `📊 *النتائج الحالية:*\n\n${getLeaderboard()}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐` }, { quoted: m })
    }
}

async function askQuiz(conn, m) {
    const q = quizzes[currentQuiz]
    
    let message = `🎬 *السؤال ${currentQuiz + 1}/${maxQuestions}* 🎬\n\n❓ *${q.question}*\n\n📝 *الخيارات:*\n`
    q.options.forEach((opt, i) => {
        message += `\n${i + 1}️⃣ ${opt}`
    })
    message += `\n\n⏳ *لديك 60 ثانية للإجابة*\n💡 تلميح: ${q.hint}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    
    await conn.sendMessage(m.chat, { text: message }, { quoted: m })
    
    // تعيين مؤقت 60 ثانية
    if (timeoutId) clearTimeout(timeoutId)
    timeoutId = setTimeout(async () => {
        if (activeGame && currentQuiz < maxQuestions) {
            await conn.sendMessage(m.chat, { text: `⏰ *انتهى الوقت!*\n\nالإجابة الصحيحة: *${quizzes[currentQuiz].answer}*\n\n↻ انتقل إلى السؤال التالي...` }, { quoted: m })
            
            currentQuiz++
            if (currentQuiz < maxQuestions) {
                await askQuiz(conn, m)
            } else {
                activeGame = false
                await conn.sendMessage(m.chat, { 
                    text: `🎉 *انتهت الفعالية!* 🎉\n\n${getLeaderboard()}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
                    mentions: Object.keys(players)
                }, { quoted: m })
            }
        }
    }, 60000)
}

function getLeaderboard() {
    if (Object.keys(players).length === 0) return "لا توجد نقاط حتى الآن"
    
    const sorted = Object.entries(players).sort((a, b) => b[1].points - a[1].points)
    let leaderboard = '🏆 *لوحة النتائج:* 🏆\n\n'
    
    sorted.forEach(([player, data], index) => {
        const medal = index === 0 ? '👑' : index === 1 ? '🥈' : index === 2 ? '🥉' : '⭐'
        leaderboard += `${medal} @${data.name}: ${data.points} نقاط\n`
    })
    
    return leaderboard
}

handler.command = ['مسلسلات', 'اجابة', 'نتيجة']
handler.help = ['مسلسلات', 'اجابة', 'نتيجة']
handler.category = 'ترفيه'
handler.description = '🎬 لعبة أسئلة عن الأفلام والمسلسلات'

export default handler
