// ╭•─•─•─•─•─•─•─•─•─•┈●
// │   📸 جلب صورة بروفايل شخص
// │   يدعم (رقم / منشن / رد)
// │   𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╰•─•─•─•─•─•─•─•─•─•

let handler = async (m, { conn, text }) => {

  // تحديد الشخص
  let who = m.mentionedJid?.[0]
    || (m.quoted ? m.quoted.sender : null)
    || (text ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : null)

  if (!who)
    return m.reply('╭•─•─•─•─•\n│ اكتب رقم الشخص أو امنشنه\n╰•─•─•─•─•')

  // جلب صورة البروفايل
  let pp
  try {
    pp = await conn.profilePictureUrl(who, 'image')
  } catch {
    pp = 'https://telegra.ph/file/24fa902ead26340f3df2c.png'
  }

  // جلب النبذة
  let about = ''
  try {
    about = (await conn.fetchStatus(who)).status || 'لا توجد نبذة'
  } catch {
    about = 'لا توجد نبذة'
  }

  let caption = `
╭•─•─•─•─•─•─•─•─•
│ 📌 الرقم:
│ ${who.split('@')[0]}
│
│ 📝 النبذة:
│ ${about}
╰•─•─•─•─•─•─•─•─•
`

  await conn.sendMessage(
    m.chat,
    { image: { url: pp }, caption },
    { quoted: m }
  )
}

handler.help = ['بروفايل']
handler.tags = ['tools']
handler.command = ['بروفايل', 'صورته']

export default handler
