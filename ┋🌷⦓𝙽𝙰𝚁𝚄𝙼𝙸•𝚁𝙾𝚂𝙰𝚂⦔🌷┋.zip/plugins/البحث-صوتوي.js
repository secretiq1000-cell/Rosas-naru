//código de ytmp3
// code creador por barboza 
// Se te agradece que dejes mis créditos gracias disfruta el código

import axios from "axios"

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return conn.reply(m.chat, `*مرحباً!* أرسل رابط يوتيوب أو عنوان الفيديو.\n\n*مثال بالرابط:* ${usedPrefix}${command} https://youtu.be/5M_n2UCe7DQ\n*مثال بالعنوان:* ${usedPrefix}${command} أغنية حزينة`, m)

    await m.react('⏳')

    try {
        let url = text
        let isDirectUrl = text.includes('youtu.be') || text.includes('youtube.com')
        
        if (!isDirectUrl) {
            const searchResponse = await axios.get(`https://api.delirius.store/search/youtube?q=${encodeURIComponent(text)}&limit=1`)
            if (!searchResponse.data.status || !searchResponse.data.data.length) {
                throw new Error('No se encontraron resultados')
            }
            url = searchResponse.data.data[0].url
        }

        const { data } = await axios.get(`https://api.delirius.store/download/ytmp3?url=${url}`)

        if (!data.status || !data.data) throw new Error()

        const { title, author, image, download } = data.data

        const info = `*〔 يوتيوب MP3 〕*\n\n*العنوان:* ${title}\n*القناة:* ${author}\n\n_جاري إرسال الصوت..._`

        await conn.sendMessage(m.chat, { 
            image: { url: image }, 
            caption: info 
        }, { quoted: m })

        await conn.sendMessage(m.chat, { 
            audio: { url: download }, 
            mimetype: 'audio/mpeg', 
            fileName: `${title}.mp3` 
        }, { quoted: m })

        await m.react('✅')

    } catch (e) {
        await m.react('❌')
        await conn.reply(m.chat, `⚠️ فشل تحميل الصوت، تأكد من الرابط أو العنوان وحاول مرة أخرى.`, m)
    }
}

handler.help = ['صوتوي', 'ytmp3', 'audio']
handler.tags = ['downloader', 'البحث']
handler.command = ['صوتوي', 'ytmp3', 'audio']

export default handler