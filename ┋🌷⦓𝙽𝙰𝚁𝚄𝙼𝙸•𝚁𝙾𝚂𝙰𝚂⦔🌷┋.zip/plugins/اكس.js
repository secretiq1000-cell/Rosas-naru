// 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
import TicTacToe from "../lib/tictactoe.js";

let handler = async (m, { conn, usedPrefix, command, text }) => {
    conn.game = conn.game || {};

    // منع اللاعب من الدخول في أكثر من لعبة
    if (Object.values(conn.game).find(room =>
        room.id.startsWith("tictactoe") &&
        [room.game.playerX, room.game.playerO].includes(m.sender)
    )) {
        return conn.sendMessage(m.chat, {
            text: `❏ انت مازلت في الجيم، لحذف الجيم اكتب: *${usedPrefix}حذففف*`
        });
    }

    if (!text) {
        return conn.sendMessage(m.chat, {
            text: `✦━─━─━✦━─━─━✦

✳️اخـتـر غـرفـة مـن 1إلـي 9 

مثــال .اكس 2
 ✦━─━─━✦━─━─━✦`
        });
    }

    // البحث عن غرفة تنتظر لاعب آخر
    let room = Object.values(conn.game).find(room =>
        room.state === "WAITING" && room.name === text
    );

    if (room) {
        await conn.sendMessage(m.chat, { text: `*تم ايجاد الشخص الآخر*` });

        room.o = m.chat;
        room.game.playerO = m.sender;
        room.state = "PLAYING";

        let arr = room.game.render().map(v => ({
            X: "❎",
            O: "⭕",
            1: "1️⃣",
            2: "2️⃣",
            3: "3️⃣",
            4: "4️⃣",
            5: "5️⃣",
            6: "6️⃣",
            7: "7️⃣",
            8: "8️⃣",
            9: "9️⃣"
        }[v]));

        let str = `
انتظر @${room.game.currentTurn.split("@")[0]} هو اللاعب الأول

${arr.slice(0, 3).join("")}
${arr.slice(3, 6).join("")}
${arr.slice(6).join("")}

▢ *Room ID:* ${room.id}

❏ *القوانين*
‣ اصنع 3 صفوف من الرموز عموديًا أو أفقيًا أو بشكل مائل للفوز  
‣ اكتب *كنسل* للانسحاب
`.trim();

        await conn.sendMessage(room.x, {
            text: str,
            mentions: conn.parseMention(str),
        });

        await conn.sendMessage(room.o, {
            text: str,
            mentions: conn.parseMention(str),
        });

    } else {
        // إنشاء غرفة جديدة
        room = {
            id: "tictactoe-" + Date.now(),
            x: m.chat,
            o: "",
            game: new TicTacToe(m.sender, "o"),
            state: "WAITING",
            name: text
        };

        await conn.sendMessage(m.chat, {
            text: `❏ *توقع الشريك*\nاكتب الأمر التالي للدخول في نفس الجيم:\n\n❏ *${usedPrefix + command} ${text}*\n\n❏ *الجائزة: 4999 XP*`,
        });

        conn.game[room.id] = room;
    }
};

handler.help = ["tictactoe <id>"];
handler.tags = ["game"];
handler.command = ["tictactoe", "ttc", "اكس", "xo"];

export default handler;
