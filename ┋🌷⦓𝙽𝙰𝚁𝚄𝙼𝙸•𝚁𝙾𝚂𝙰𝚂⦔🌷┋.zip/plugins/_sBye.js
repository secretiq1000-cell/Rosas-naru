// import صوري لضمان ESM
import 'fs'

const statusRegex = /(whatsapp\.com\/stories\/|wa\.me\/stories\/)/i

export async function before(m, { conn, isAdmin, isBotAdmin, isROwner }) {
  if (!m.isGroup) return

  const chat = global?.db?.data?.chats[m.chat]
  
  // استخدام sBye بدلاً من antiLink
  if (!("sBye" in chat)) chat.sBye = true  // تهيئة إذا لم تكن موجودة
  if (!chat?.sBye) return

  const sender = m.key.participant || m.sender
  const botJid = conn.user.jid

  // ❌ استثناءات: لا يفعل شي إذا كان المطور أو المشرف
  if (isAdmin || isROwner) return

  // كشف مشاركة الستوريات
  const isStatusMention = (m.mtype === 'groupStatusMentionMessage' || m.mtype === 'statusMentionMessage')
  const hasStatusLink = statusRegex.test(m.text || '')
  
  if (!isStatusMention && !hasStatusLink) return

  // ⛔ رد على رسالة الستوري أولًا
  await conn.reply(
    m.chat,
    `*┊🦅┊:•⪼ ⌝مضاد مشاركة الحالات⌞*\n\n` +
    `> ⊢ممنوع نشر الستوريات (الحالات) هنا╎❯\n` +
    `🚫╏المستخدم: @${sender.split('@')[0]}\n` +
    `⚖️╏القانون: لا استثناء لأحد\n\n` +
    `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
    m, // ⬅️ الرد على نفس الرسالة
    { mentions: [sender] }
  )

  // 🗑️ حذف رسالة الستوري إذا كان البوت مشرفًا
  if (isBotAdmin) {
    await conn.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.key.id,
        participant: sender
      }
    })

    // طرد مباشر بدون إنذارات
    await conn.reply(
      m.chat,
      `☠️ *تم الطرد بسبب مشاركة ستوري*\n\n` +
      `👤 المستخدم: @${sender.split('@')[0]}\n` +
      `🚫 ممنوع مشاركة الستوريات في هذه المجموعة.`,
      null,
      { mentions: [sender] }
    )

    await conn.groupParticipantsUpdate(m.chat, [sender], 'remove')
  }
  // إذا لم يكن البوت مشرفًا، لا يفعل شي (لا يرسل أي رسالة طلب رفع)
}
