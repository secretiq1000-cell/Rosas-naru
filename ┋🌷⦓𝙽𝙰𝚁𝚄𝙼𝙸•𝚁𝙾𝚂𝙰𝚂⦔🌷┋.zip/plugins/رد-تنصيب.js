let handler = async (m) => {
  const reply = ` ____________________________ 
*حط النقطه قبل كلمه تنصيب يهطل لا ترعبني بي كلامك الخرافي اكتب هيك .تنصيب 💀*
:::::::::::::::::😒::::::::::::::::::: `.trim();
  await m.conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363403831715215@newsletter',
        newsletterName: '𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐💀',
        serverMessageId: 100
      }
    }
  }, { quoted: m });
};

// كلمات مفتاحية للرد التلقائي
handler.customPrefix = /^(|cod|تصنيب|code|تنصيب||تنصب|)$/i;
handler.command = new RegExp;
handler.exp = 0;

export default handler;
