let handler = async (m, { conn, command, usedPrefix }) => {

  // ─────────────── المصرح لهم ───────────────
  const allowedNumbers = [
    '201022950118@s.whatsapp.net', // الرقم الأول
    '123456789@s.whatsapp.net'  // الرقم الثاني
  ]

  // السماح فقط للأرقام المصرح لهم
  if (!allowedNumbers.includes(m.sender)) {
    return m.reply("💀 يا ولدي... هذه الأوامر مخصصة للعائلة فقط، الغرباء لا مكان لهم هنا.\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀")
  }

  let users = global.db.data.users
  let target = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : null
  let jumlah = 0

  // إذا فيه منشن → إعادة ضبط لمستخدم واحد
  if (target) {
    if (!(target in users)) {
      return m.reply(`💀 هذا الرجل ليس مسجلاً في سجلات العائلة...\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`)
    }
    users[target].command = 0
    users[target].commandLimit = 1000
    users[target].cmdLimitMsg = 0
    jumlah = 1

    return m.reply(
`*───『 تم اعادة ضبط النقاط 』───*
👤 المستخدم: @${target.replace(/@s\.whatsapp\.net/g, '')}
📉 الحد: 1000
🔄 الاستخدام: 0

💀 يا ولدي... لقد صفّيت حدوده كما أردت.

📝 *مثال:*
${usedPrefix + command} @user

𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`, null, { mentions: [target] })
  }

  // إذا بدون منشن → إعادة ضبط للجميع
  for (let id in users) {
    if (typeof users[id] === 'object') {
      users[id].command = 0
      users[id].commandLimit = 1000
      users[id].cmdLimitMsg = 0
      jumlah++
    }
  }

  return m.reply(
`*──『 تم اعادة نقاط المستخدمين 』─*
👥 عدد الأعضاء المصَفّرين: ${jumlah}
📉 الحد: 1000
🔄 الاستخدام: 0

💀 يا ولدي... كما أمرتني، أعدت ضبط أوامر الجميع.

📝 *مثال:*
${usedPrefix + command}

𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
  )
}

handler.help = ['resetcommand', 'اعاده-ضبط-النقاط', 'اعادة-ضبط-النقاط']
handler.tags = ['owner']
handler.command = /^(resetcommand|اعاده-ضبط-النقاط|اعادة-ضبط-النقاط)$/i
handler.owner = true

export default handler