let handler = async (m, { conn }) => {
  let vcard = `BEGIN:VCARD
VERSION:3.0
FN:╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ
ORG:╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ
TITLE:Metatron Executioner of Michael
EMAIL;type=INTERNET:vnmanoo@gmail.com
TEL;type=CELL;waid=201553801908:+201553801908
ADR;type=WORK:;;2-chōme-7-5 Fuchūchō;Izumi;Osaka;594-0071;Japan
URL;type=WORK:https://www.instagram.com/dy3_alexander?igsh=YzljYTk1ODg3Zg==‎
X-WA-BIZ-NAME:╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ
X-WA-BIZ-DESCRIPTION:مطور بوتات محترف وصاحب استضافات
X-WA-BIZ-HOURS:Mo-Su 00:00-23:59
END:VCARD`

  let qkontak = {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast"
    },
    message: {
      contactMessage: {
        displayName: "╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ",
        vcard
      }
    }
  }

  // 📌 إرسال الكونتاكت
  await conn.sendMessage(m.chat, {
    contacts: {
      displayName: '╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ',
      contacts: [{ vcard }]
    },
    contextInfo: {
      externalAdReply: {
        title: 'حقوق النشر © 2026 - 2027 ',
        body: 'للتواصل مباشرة عبر الواتساب',
        thumbnailUrl: 'https://i.postimg.cc/rFTT2p34/20241105-004328.jpg',
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: qkontak })

  // 📌 إرسال المقطع الصوتي بعد الكونتاكت
  await conn.sendMessage(m.chat, {
    audio: { url: "https://files.catbox.moe/bxomh0.mp3" },
    mimetype: 'audio/mpeg',
    ptt: false // true لو تبيه فويس
  }, { quoted: m })
}

handler.help = ['owner']
handler.tags = ['info']
handler.command = /^(owner|مطور|المطور)$/i

export default handler
