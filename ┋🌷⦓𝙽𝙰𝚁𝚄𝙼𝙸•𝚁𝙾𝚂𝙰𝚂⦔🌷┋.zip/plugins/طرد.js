let handler = async (m, { conn, text }) => {

  let developerNumber = '201022950118@s.whatsapp.net';

  const getTarget = () => {
    if (m.mentionedJid && m.mentionedJid[0]) return m.mentionedJid[0];
    if (m.quoted) return m.quoted.sender;
    if (text) {
      let num = text.replace(/[^0-9]/g, '');
      if (num.length > 5) return num + '@s.whatsapp.net';
    }
    return null;
  };

  let user = getTarget();

  if (!user) {
    return m.reply(
      `╔═━━••【🧬】••━━═╗
✦ مـنـشـن أو رد عـلـى الـشـخـص ✦
╚═━━••【🧬】••━━═╝`
    );
  }

  // منع طرد المطور
  if (user === developerNumber) {
    return m.reply(
      `╔═━━••【🧬】••━━═╗
✦ عايزني أطرد مطوري؟ هو انا احول زيك ✦
╚═━━••【🧬】••━━═╝`,
      null,
      { mentions: [developerNumber] }
    );
  }

  await conn.groupParticipantsUpdate(m.chat, [user], 'remove');

  await m.reply(
    `╔═━━••【🧬】••━━═╗
✦ تـم الـطـرد بـنـجـاح ✦
✦ بـأمـر ↜ @${m.sender.split('@')[0]} ✦
╚═━━••【🧬】••━━═╝`,
    null,
    { mentions: [m.sender] }
  );
};

handler.command = ['طرد', 'kick'];
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
