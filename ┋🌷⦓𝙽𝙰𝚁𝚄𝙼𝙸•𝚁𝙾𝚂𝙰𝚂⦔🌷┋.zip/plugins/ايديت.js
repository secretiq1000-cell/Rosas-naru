// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios'
import { execSync } from 'child_process'
import fs from 'fs'
import path from 'path'
import os from 'os'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

let handler = async (m, { conn, text }) => {
  const chatId = m.chat
  const query = text.trim()
  const searchText = query ? `anime edit ${query}` : 'anime edit'
  const senderName = m.pushName || m.sender.split('@')[0]

  await conn.sendMessage(chatId, { react: { text: '🎬', key: m.key } })

  // تحديد الشخص المستهدف
  let target = m.sender
  if (m.mentionedJid && m.mentionedJid.length > 0) {
    target = m.mentionedJid[0]
  } else if (m.quoted) {
    target = m.quoted.sender
  }
  const targetName = target.split('@')[0]

  // --- محاولة TikTok أولاً ---
  try {
    const { data } = await axios.get(`https://apis-starlights-team.koyeb.app/starlight/tiktoksearch?text=${encodeURIComponent(searchText)}`, { timeout: 15000 })
    const results = data.data

    if (results?.length > 0) {
      const vid = results[0]

      const caption = `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*
✨🎬 *ايديت أنمي: ${query || 'عشوائي'}* ✨

📌 *لـ:* @${targetName}
🔗 *المصدر:* TikTok
*┋🌷⦓𝙽𝙰𝚁𝚄𝙼𝙸•𝚁𝙾𝚂𝙰𝚂⦔🌷┋*
*⌬──══─┈•⤣🌺⤤•┈─══──⌬*`

      return await conn.sendMessage(chatId, { 
        video: { url: vid.nowm }, 
        caption,
        mentions: [target]
      }, { quoted: m })
    }
  } catch (err) {
    console.warn('⚠️ فشل تحميل فيديو TikTok:', err.message)
  }

  // --- محاولة YouTube باستخدام yt-dlp ---
  let tmpDir
  try {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'edit-'))
    const outPath = path.join(tmpDir, 'video.%(ext)s')

    const command = `yt-dlp "ytsearch1:${searchText}" -f "bestvideo[ext=mp4]+bestaudio/best" -o "${outPath}" --quiet --no-warnings`
    execSync(command, { stdio: 'ignore' })

    const files = fs.readdirSync(tmpDir).filter(f => f.endsWith('.mp4'))
    if (files.length === 0) throw new Error('لا يوجد ملفات فيديو بعد التحميل')

    const videoPath = path.join(tmpDir, files[0])

    const caption = `
✨🎬 *ايديت أنمي: ${query || 'عشوائي'}* ✨

📌 *لـ:* @${targetName}
🔗 *المصدر:* YouTube
*┋🌷⦓𝙽𝙰𝚁𝚄𝙼𝙸•𝚁𝙾𝚂𝙰𝚂⦔🌷┋*
*⌬──══─┈•⤣🌺⤤•┈─══──⌬*`

    await conn.sendMessage(chatId, { 
      video: fs.readFileSync(videoPath), 
      caption,
      mentions: [target]
    }, { quoted: m })
    
    fs.rmSync(tmpDir, { recursive: true, force: true })
    
  } catch (err) {
    if (tmpDir) fs.rmSync(tmpDir, { recursive: true, force: true })
    console.error('❌ YouTube Error:', err.message)
    await conn.sendMessage(chatId, { 
      text: `❌ *فشل تحميل الفيديو*\n\nالرجاء المحاولة مرة أخرى لاحقاً.\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
      mentions: [target]
    }, { quoted: m })
  }
}

handler.command = ['ايديت', 'edit']
handler.help = ['ايديت']
handler.category = 'media'
handler.description = '🎬 يرسل أي فيديو Anime Edit من TikTok أو YouTube'

export default handler
