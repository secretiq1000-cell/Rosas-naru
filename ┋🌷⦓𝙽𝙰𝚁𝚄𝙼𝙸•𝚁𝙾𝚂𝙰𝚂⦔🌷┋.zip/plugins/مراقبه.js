const eliteNumbers = ['201022950118', '201022950118'];
let monitorChanges = null;

var handler = async (m, { conn, groupMetadata, args }) => {
  if (!m.isGroup) return conn.reply(m.chat, '⚠️ هذا الأمر يعمل فقط داخل المجموعات.');

  const senderNumber = m.sender.replace('@s.whatsapp.net', '').trim();

  if (m.sender !== conn.user.jid && !eliteNumbers.some(num => senderNumber.endsWith(num))) {
    return conn.reply(m.chat, '⛔ هذا الأمر مخصص للمطور فقط.');
  }

  if (args[0] === 'فتح') {
    if (monitorChanges) return conn.reply(m.chat, '👁️ المراقبة مفعّلة بالفعل.');

    try {
      let admins = groupMetadata.participants.filter(p => p.admin).map(admin => admin.id);
      conn.reply(m.chat, '✅ تم تفعيل مراقبة المشرفين.');

      monitorChanges = setInterval(async () => {
        try {
          const updatedMetadata = await conn.groupMetadata(m.chat);
          const currentAdmins = updatedMetadata.participants.filter(p => p.admin).map(admin => admin.id);

          if (admins.length !== currentAdmins.length || !admins.every(admin => currentAdmins.includes(admin))) {
            await conn.reply(m.chat, '⚠️ تم تعديل حالة المشرفين! سيجري تصحيح الوضع الآن.');

            const toDemote = currentAdmins.filter(admin =>
              admin !== conn.user.jid && !eliteNumbers.some(num => admin.replace('@s.whatsapp.net', '').endsWith(num))
            );

            if (toDemote.length > 0) {
              await Promise.all(toDemote.map(admin => conn.groupParticipantsUpdate(m.chat, [admin], 'demote')));
            }

            const eliteJids = eliteNumbers.map(number => `${number}@s.whatsapp.net`);
            await Promise.all(eliteJids.map(elite => conn.groupParticipantsUpdate(m.chat, [elite], 'promote')));

            admins = updatedMetadata.participants.filter(p => p.admin).map(admin => admin.id);
          }
        } catch (error) {
          console.error('⚠️ خطأ أثناء مراقبة المشرفين:', error);
        }
      }, 5000);
    } catch (error) {
      console.error('خطأ أثناء تفعيل المراقبة:', error);
      conn.reply(m.chat, 'حدث خطأ أثناء محاولة تفعيل المراقبة.');
    }

  } else if (args[0] === 'قفل') {
    if (monitorChanges) {
      clearInterval(monitorChanges);
      monitorChanges = null;
      conn.reply(m.chat, '🌙 تم تعطيل مراقبة المشرفين.');
    } else {
      conn.reply(m.chat, '👁️ لا توجد مراقبة مفعلة حالياً.');
    }

  } else if (args[0] === 'حاله') {
    conn.reply(m.chat, monitorChanges ? '👁️ المراقبة مفعّلة.' : '🌙 المراقبة غير مفعلة.');

  } else {
    conn.reply(m.chat, `
╭•─•─•─•─•─•─•─•─•╮
│ 🌐 *قـائـمـة أوامـر الـمـراقـبـة* 👁️‍🗨️
│
│ ⚙️ استخدم الأوامر التالية:
│
│ 🟢 *مراقبه فتح* ➜ لتفعيل المراقبة
│ 🔴 *مراقبه قفل* ➜ لإيقاف المراقبة
│ 🔍 *مراقبه حاله* ➜ لمعرفة حالة المراقبة
│
│ 🧠 تأكد أنك مطور لتتمكن من استخدامها
╰•─•─•─•─•─•─•─•─•╯
`);
  }
};

handler.help = ['مراقبه فتح', 'مراقبه قفل', 'مراقبه حاله'];
handler.tags = ['owner'];
handler.command = /^(مراقبه)$/i;
handler.group = true;
handler.owner = true;

export default handler;
