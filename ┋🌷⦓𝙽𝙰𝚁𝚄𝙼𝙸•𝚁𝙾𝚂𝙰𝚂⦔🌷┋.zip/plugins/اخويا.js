let handler = async (m, { conn }) => {
  try {

    const sender = m.sender
    const chatId = m.chat
    let text = m.text || ''
    let mention = null

    if (m.mentionedJid && m.mentionedJid.length > 0) {
      mention = m.mentionedJid[0]
    }

    if (!mention && text) {
      const phoneMatch = text.match(/(\d{10,15})/)
      if (phoneMatch) {
        mention = `${phoneMatch[1]}@s.whatsapp.net`
      }
    }

    if (!mention && text) {
      const atMatch = text.match(/@(\d+)/)
      if (atMatch && atMatch[1]) {
        mention = `${atMatch[1]}@s.whatsapp.net`
      }
    }

    if (!mention && m.quoted && m.quoted.sender) {
      mention = m.quoted.sender
    }

    if (!mention) {
      return conn.sendMessage(chatId, {
        text: '❌ منشن الشخص اللي عايز تقول عليه اخويا\n\nمثال: .اخويا @العضو'
      }, { quoted: m })
    }

    if (sender === mention) {
      return conn.sendMessage(chatId, {
        text: '❌ مش هتقدر تاخو نفسك 😂 جرب منشن حد تاني'
      }, { quoted: m })
    }

    await conn.sendMessage(chatId, {
      react: {
        text: '🤝',
        key: m.key
      }
    })

    const senderName = sender.split('@')[0]
    const mentionName = mention.split('@')[0]

    const messagesList = [
      `🤝 @${senderName} و @${mentionName}\n\n❤️ اخوات وصحاب عمر ومفيش حاجه تفرقنا`,
      `👬 @${senderName} 🤝 @${mentionName}\n\nمن اليوم رايح انتوا اخوات ❤️🔥`,
      `💪 @${senderName} و @${mentionName}\n\nاتفقنا يا صحاب ✨ دمتم للأبد اخوات`,
      `🎉 الف مبروك للعضوين\n@${senderName} 🤝 @${mentionName}\n\nانتوا اصدقاء واخوات ❤️`,
      `🌟 اعز الناس لبعض\n@${senderName} 🤝 @${mentionName}\n\nربنا يديم المحبة 🤲`
    ]

    const randomMessage = messagesList[Math.floor(Math.random() * messagesList.length)]

    await conn.sendMessage(chatId, {
      text: randomMessage,
      mentions: [sender, mention]
    }, { quoted: m })

  } catch (err) {

    console.error('❌ خطأ في أمر اخويا:', err)

    await conn.sendMessage(m.chat, {
      text: `❌ صار خطأ:\n${err.message || err}`
    }, { quoted: m })
  }
}

handler.help = ['اخويا']
handler.command = ['اخويا', 'اخوات', 'اصدقاء']
handler.group = true

export default handler
