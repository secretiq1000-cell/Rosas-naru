let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let name = conn.getName(m.sender) || 'مستخدم';
  let taguser = '@' + m.sender.split("@")[0];

  let currentTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

  let groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
  let groupName = groupMetadata ? groupMetadata.subject : 'غير معروف';
  let groupMembers = groupMetadata ? groupMetadata.participants.length : 'غير معروف';

  let message = `
╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ *مرحــبـا ⌊${taguser}⌉*
── • ◈ • ──
*⌝🧬┊قــســم الادوات┊🧬⌞* 
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹📮›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
┤┌ ─๋︩︪─✦ *الادوات* ─˚᳝᳝𖥻

> │┊ ۬.͜ـ🛠️˖ *⟨رابـط☇* 

> │┊ ۬.͜ـ🛠️˖ *⟨لـرابط☇*

> │┊ ۬.͜ـ🛠️˖ *⟨لـرابط2☇*

> │┊ ۬.͜ـ🛠️˖ *⟨سكرين☇*

> │┊ ۬.͜ـ🛠️˖ *⟨لـصوت☇*

> │┊ ۬.͜ـ🛠️˖ *⟨لـصوره☇*

> │┊ ۬.͜ـ🛠️˖ *⟨صـورة☇*

> │┊ ۬.͜ـ🛠️˖ *⟨عـدسـة☇* 

> │┊ ۬.͜ـ🛠️˖ *⟨ستيـك☇*

> │┊ ۬.͜ـ🛠️˖ *⟨بحث-ملصق☇*

> │┊ ۬.͜ـ🛠️˖ *⟨تحسـين☇*

> │┊ ۬.͜ـ🛠️˖ *⟨تعـديل☇*

> │┊ ۬.͜ـ🛠️˖ *⟨تـاثير☇*

> │┊ ۬.͜ـ🛠️˖ *⟨تـخـيل☇*

> │┊ ۬.͜ـ🛠️˖ *⟨فـنن☇*

> │┊ ۬.͜ـ🛠️˖ *⟨انشاء-صورة☇* 

> │┊ ۬.͜ـ🛠️˖ *⟨لـكود☇*

> │┊ ۬.͜ـ🛠️˖ *⟨حقـوق☇*

> │┊ ۬.͜ـ🛠️˖ *⟨اختـصار☇*

> │┊ ۬.͜ـ🛠️˖ *⟨الـطـقس☇* 

> │┊ ۬.͜ـ🛠️˖ *⟨ترجـم☇*

> │┊ ۬.͜ـ🛠️˖ *⟨رسـم☇*

> │┊ ۬.͜ـ🛠️˖ *⟨ارسـم☇* 

> │┊ ۬.͜ـ🛠️˖ *⟨فـضـح☇*

> │┊ ۬.͜ـ🛠️˖ *⟨رابـطي☇* 

> │┊ ۬.͜ـ🛠️˖ *⟨جـروبـي☇* 

> │┊ ۬.͜ـ🛠️˖ *⟨تفاعـل-قنـاة☇*

> │┊ ۬.͜ـ🛠️˖ *⟨كلمات_فيديو☇*

> │┊ ۬.͜ـ🛠️˖ *⟨لـكرتون☇*

> │┊ ۬.͜ـ🛠️˖ *⟨حـلل☇*

> │┊ ۬.͜ـ🛠️˖ *⟨انـا☇*

> │┊ ۬.͜ـ🛠️˖ *⟨بروفايل☇*

> │┊ ۬.͜ـ🛠️˖ *⟨بروفايل2☇*

> │┊ ۬.͜ـ🛠️˖ *⟨صـورته☇*

> │┊ ۬.͜ـ🛠️˖ *⟨حـساب☇*

> │┊ ۬.͜ـ🛠️˖ *⟨البـلوكات☇*

> │┊ ۬.͜ـ🛠️˖ *⟨هاتف☇*

> │┊ ۬.͜ـ🛠️˖ *⟨بـلاغ☇*
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈─๋︩︪─═⊐‹🧬𝑫𝑨𝑵𝑵𝒀🧬›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
`;

  const emojiReaction = '🛠️';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    await conn.sendMessage(m.chat, { 
      image: { url: 'https://i.postimg.cc/J4C7DVRy/IMG-20251230-WA0101.jpg' },
      caption: message,
      mentions: [m.sender]
    });
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق3)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;
