
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import yts from 'yt-search';
import axios from 'axios';

const handler = async (m, { conn, args, usedPrefix }) => {
    if (!args[0]) return conn.reply(m.chat, '*`اكتب الأمر وبعده العنوان أو الرابط\nمثال:\n.شغل سورة النازعات رعد الكردي\n.شغل https://youtube.com/watch?v=2bQyxlLzMqc`*', m);

    await m.react('🕓');
    try {
        let video;
        let searchQuery = args.join(" ");
        let allResults = [];
        
        if (isYoutubeUrl(searchQuery)) {
            video = await getVideoInfoFromUrl(searchQuery);
            if (video && video.titulo) {
                allResults = await searchVideos(video.titulo);
            }
            if (!allResults || allResults.length === 0) {
                allResults = [video];
            }
        } else {
            let searchResults = await searchVideos(searchQuery);
            if (!searchResults.length) throw new Error('لم يتم العثور على نتائج.');
            video = searchResults[0];
            allResults = searchResults;
        }

        let thumbnail = await prepareWAMessageMedia(
            { image: { url: video.miniatura } },
            { upload: conn.waUploadToServer }
        );

        let messageText = `> *𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻*\n\n`;
        messageText += `${video.titulo}\n\n`;
        messageText += `• *الـمـده:* ${video.duracion || 'غـيـر مـتـوفـࢪ'}\n`;
        messageText += `• *الـمـصـدࢪ:* ${video.canal || 'غير معروف'}\n`;
        messageText += `• *الزمن:* ${convertTimeToSpanish(video.publicado)}\n`;
        messageText += `• *الـࢪابـط:* ${video.url}\n`;

        const resultsForButtons = allResults.slice(0, 5);
        
        const audioSections = [
            {
                title: '🎵 تحميل صوت (MP3)',
                rows: resultsForButtons.map(v => ({
                    title: v.titulo.length > 35 ? v.titulo.slice(0, 35) + '...' : v.titulo,
                    description: `⏱ ${v.duracion || 'غير معروف'} | ${v.canal || 'غير معروف'}`,
                    id: `${usedPrefix}الصوت ${convertToLongUrl(v.url)}`
                }))
            }
        ];

        const videoSections = [
            {
                title: '🎬 تحميل فيديو (MP4)',
                rows: resultsForButtons.map(v => ({
                    title: v.titulo.length > 35 ? v.titulo.slice(0, 35) + '...' : v.titulo,
                    description: `⏱ ${v.duracion || 'غير معروف'} | ${v.canal || 'غير معروف'}`,
                    id: `${usedPrefix}الفيديو ${convertToLongUrl(v.url)}`
                }))
            }
        ];

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            hasMediaAttachment: true,
                            imageMessage: thumbnail.imageMessage
                        },
                        body: { 
                            text: messageText,
                            contextInfo: {
                                mentionedJid: [m.sender]
                            }
                        },
                        footer: { text: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐" },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '🎵 تحميل صوت MP3',
                                        sections: audioSections
                                    })
                                },
                                {
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '🎬 تحميل فيديو MP4',
                                        sections: videoSections
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        }, { quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react('✅');

    } catch (e) {
        console.error(e);
        await m.react('✖️');
        conn.reply(m.chat, '*`خطأ في البحث عن الفيديو.`*', m);
    }
};

const audioHandler = async (m, { conn, args, usedPrefix }) => {
    const url = args[0];
    if (!url) return conn.reply(m.chat, '*`يرجى توفير رابط الفيديو`*', m);
    
    await m.react('🎵');
    
    try {
        const yt_play = await yts.search(url);
        const video = yt_play.videos[0];
        
        const thumbnail = await prepareWAMessageMedia(
            { image: { url: video.thumbnail } },
            { upload: conn.waUploadToServer }
        );
        
        const dataMessage = 
`📌 *الصوت:* ${video.title}
━━━━━━━━━━━━━━━━
⏱️ *المدة:* ${secondString(video.duration.seconds)}
📺 *القناة:* ${video.author.name}
━━━━━━━━━━━━━━━━
📥 *اختر جودة الصوت:*`;

        const qualitySections = [
            {
                title: '🎵 جودة الصوت',
                rows: [
                    { title: '🎵 سريع (64kbps)', description: 'حجم صغير', id: `${usedPrefix}صو ${convertToLongUrl(url)}` },
                    { title: '🎶 متوسط (128kbps)', description: 'حجم متوسط', id: `${usedPrefix}صوت ${convertToLongUrl(url)}` },
                    { title: '🎼 عالي (320kbps)', description: 'حجم كبير', id: `${usedPrefix}صوتوي ${convertToLongUrl(url)}` },
                    { title: '🎙️ فويس', description: 'صيغة فويس', id: `${usedPrefix}فويس ${convertToLongUrl(url)}` },
                    { title: '📁 ملف صوتي', description: 'ملف عادي', id: `${usedPrefix}ملف-صوت ${convertToLongUrl(url)}` }
                ]
            }
        ];
        
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { hasMediaAttachment: true, imageMessage: thumbnail.imageMessage },
                        body: { text: dataMessage },
                        footer: { text: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐" },
                        nativeFlowMessage: {
                            buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: 'اختر الجودة', sections: qualitySections }) }]
                        }
                    }
                }
            }
        }, { quoted: m });
        
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        
    } catch (error) {
        console.error(error);
        await m.react('❌');
    }
};

const videoHandler = async (m, { conn, args, usedPrefix }) => {
    const url = args[0];
    if (!url) return conn.reply(m.chat, '*`يرجى توفير رابط الفيديو`*', m);
    
    await m.react('🎬');
    
    try {
        const yt_play = await yts.search(url);
        const video = yt_play.videos[0];
        
        const thumbnail = await prepareWAMessageMedia(
            { image: { url: video.thumbnail } },
            { upload: conn.waUploadToServer }
        );
        
        const dataMessage = 
`📌 *الفيديو:* ${video.title}
━━━━━━━━━━━━━━━━
⏱️ *المدة:* ${secondString(video.duration.seconds)}
📺 *القناة:* ${video.author.name}
━━━━━━━━━━━━━━━━
📥 *اختر جودة الفيديو:*`;

        const qualitySections = [
            {
                title: '🎬 جودة الفيديو',
                rows: [
                    { title: '🎬 360p (سريع)', description: 'حجم صغير - جودة منخفضة', id: `${usedPrefix}فيد ${convertToLongUrl(url)}` },
                    { title: '📹 480p (متوسط)', description: 'حجم متوسط - جودة جيدة', id: `${usedPrefix}فيديو ${convertToLongUrl(url)}` },
                    { title: '🎞️ 720p (HD)', description: 'حجم متوسط - جودة عالية', id: `${usedPrefix}فيديوي ${convertToLongUrl(url)}` },
                    { title: '🎥 1080p (Full HD)', description: 'حجم كبير - جودة فائقة', id: `${usedPrefix}فيديوي2 ${convertToLongUrl(url)}` },
                    { title: '📂 ملف فيديو', description: 'ملف عادي', id: `${usedPrefix}ملف-فيديو ${convertToLongUrl(url)}` }
                ]
            }
        ];
        
        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: { hasMediaAttachment: true, imageMessage: thumbnail.imageMessage },
                        body: { text: dataMessage },
                        footer: { text: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐" },
                        nativeFlowMessage: {
                            buttons: [{ name: 'single_select', buttonParamsJson: JSON.stringify({ title: 'اختر الجودة', sections: qualitySections }) }]
                        }
                    }
                }
            }
        }, { quoted: m });
        
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        
    } catch (error) {
        console.error(error);
        await m.react('❌');
    }
};

// ==================== تحميل الصوت عالي الجودة ====================
const downloadHighQualityAudio = async (m, { conn, args }) => {
    const url = args[0];
    if (!url) return conn.reply(m.chat, '*`يرجى توفير رابط الفيديو`*', m);
    
    await m.react('⏳');
    
    try {
        const { data } = await axios.get(`https://api.delirius.store/download/ytmp3?url=${url}`);
        if (!data.status || !data.data) throw new Error('فشل التحميل');
        
        const { title, author, image, download } = data.data;
        
        await conn.sendMessage(m.chat, { 
            image: { url: image }, 
            caption: `*〔 MP3 320kbps 〕*\n${title}\n${author}`
        }, { quoted: m });
        
        await conn.sendMessage(m.chat, { 
            audio: { url: download }, 
            mimetype: 'audio/mpeg', 
            fileName: `${title}.mp3` 
        }, { quoted: m });
        
        await m.react('✅');
        
    } catch (error) {
        console.error(error);
        await m.react('❌');
    }
};

// ==================== دوال التحميل (تستدعي فقط الأوامر) ====================

const downloadFastAudio = async (m, { conn, args }) => {
    await m.react('⚡');
    // يستدعي الأمر المناسب
};

const downloadNormalAudio = async (m, { conn, args }) => {
    await m.react('🎵');
};

const downloadVoice = async (m, { conn, args }) => {
    await m.react('🎙️');
};

const downloadAudioFile = async (m, { conn, args }) => {
    await m.react('📁');
};

const download360Video = async (m, { conn, args }) => {
    await m.react('🎬');
};

const download480Video = async (m, { conn, args }) => {
    await m.react('📹');
};

const download720Video = async (m, { conn, args }) => {
    await m.react('🎞️');
};

const download1080Video = async (m, { conn, args }) => {
    await m.react('🎥');
};

const downloadVideoFile = async (m, { conn, args }) => {
    await m.react('📂');
};

// ==================== دوال مساعدة ====================
function isYoutubeUrl(url) {
    return /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/|music\.youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/.test(url);
}

function convertToLongUrl(url) {
    const match = url.match(/(?:youtu\.be\/|youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/);
    return match ? `https://youtube.com/watch?v=${match[1]}` : url;
}

async function getVideoInfoFromUrl(url) {
    try {
        const videoId = extractVideoId(url);
        if (!videoId) throw new Error('رابط غير صحيح');
        const videoInfo = await yts({ videoId: videoId });
        return {
            titulo: videoInfo.title,
            url: videoInfo.url,
            miniatura: videoInfo.thumbnail,
            canal: videoInfo.author.name,
            publicado: videoInfo.uploadDate || 'غير معروف',
            vistas: videoInfo.views || 'غير معروف',
            duracion: videoInfo.duration || 'غير معروف',
            isDirectLink: true
        };
    } catch (error) {
        throw new Error('فشل في تحميل معلومات الفيديو');
    }
}

function extractVideoId(url) {
    const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|music\.youtube\.com\/watch\?v=)([a-zA-Z0-9_-]{11})/);
    return match ? match[1] : null;
}

async function searchVideos(query) {
    try {
        const res = await yts(query);
        return res.videos.slice(0, 10).map(video => ({
            titulo: video.title,
            url: video.url,
            miniatura: video.thumbnail,
            canal: video.author.name,
            publicado: video.uploadDate || 'غير معروف',
            vistas: video.views || 'غير معروف',
            duracion: video.duration || 'غير معروف'
        }));
    } catch (error) {
        return [];
    }
}

function convertTimeToSpanish(timeText) {
    if (!timeText || timeText === 'غير معروف') return 'غير معروف';
    return timeText
        .replace(/year/, 'سنة').replace(/years/, 'سنوات')
        .replace(/month/, 'شهر').replace(/months/, 'أشهر')
        .replace(/day/, 'يوم').replace(/days/, 'أيام')
        .replace(/hour/, 'ساعة').replace(/hours/, 'ساعات')
        .replace(/minute/, 'دقيقة').replace(/minutes/, 'دقائق')
        .replace(/second/, 'ثانية').replace(/seconds/, 'ثواني');
}

function secondString(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h > 0 ? h + " ساعة " : ""}${m > 0 ? m + " دقيقة " : ""}${s > 0 ? s + " ثانية" : ""}`.trim();
}

// ==================== الهاندلر الرئيسي ====================
const mainHandler = async (m, context) => {
    const { command } = context;
    
    if (command === 'شغل' || command === 'play') return handler(m, context);
    if (command === 'الصوت') return audioHandler(m, context);
    if (command === 'الفيديو') return videoHandler(m, context);
    if (command === 'صوتوي' || command === 'غنيه_عالي') return downloadHighQualityAudio(m, context);
    if (command === 'صو') return downloadFastAudio(m, context);
    if (command === 'صوت') return downloadNormalAudio(m, context);
    if (command === 'فويس') return downloadVoice(m, context);
    if (command === 'ملف-صوت') return downloadAudioFile(m, context);
    if (command === 'فيد') return download360Video(m, context);
    if (command === 'فيديو') return download480Video(m, context);
    if (command === 'فيديوي') return download720Video(m, context);
    if (command === 'فيديوي2') return download1080Video(m, context);
    if (command === 'ملف-فيديو') return downloadVideoFile(m, context);
};

mainHandler.help = ['play', 'شغل'];
mainHandler.tags = ['downloader', 'البحث'];
mainHandler.command = ['شغل', 'play', 'الصوت', 'الفيديو', 'صو', 'صوت', 'صوتوي', 'غنيه_عالي', 'فويس', 'ملف-صوت', 'فيد', 'فيديو', 'فيديوي', 'فيديوي2', 'ملف-فيديو'];

export default mainHandler;
