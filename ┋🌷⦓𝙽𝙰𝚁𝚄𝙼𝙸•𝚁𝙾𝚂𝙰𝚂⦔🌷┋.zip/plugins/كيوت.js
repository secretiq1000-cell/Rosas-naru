import fetch from 'node-fetch'

let handler = async (m, { conn, command }) => {

  try {
    // جلب قائمة الصور من المصدر
    let ne = await (await fetch('https://raw.githubusercontent.com/ArugaZ/grabbed-results/main/random/anime/neko.txt')).text()
    let nek = ne.split('\n')
    let neko = pickRandom(nek)

    // إرسال الرسالة مع زر حديث
    await conn.sendMessage(m.chat, {
      image: { url: neko },
      caption: 'Nyaww~ 🐾💗',
      buttons: [
        {
          buttonId: `/${command}`,
          buttonText: { displayText: 'التالي 🆕' },
          type: 1
        }
      ],
      headerType: 4
    }, { quoted: m })

  } catch (e) {
    console.log(e)
    await m.reply('حدث خطأ أثناء جلب الصورة.')
  }

}

handler.command = /^(كيوت)$/i
handler.tags = ['anime']
handler.help = ['كيوت']

export default handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}
