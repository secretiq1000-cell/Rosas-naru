import fetch from "node-fetch"
import yts from 'yt-search'

const handler = async (m, { conn, text, usedPrefix, command }) => {

    if (!text) return conn.reply(m.chat, `🎵 *يرجى إرسال رابط أو اسم صوت*\n📌 مثال:\n${usedPrefix + command} https://youtu.be/...\n${usedPrefix + command} Lose Yourself`, m)

    await m.react('💿')

    try {
        const decode = (s) => Buffer.from(s, 'base64').toString('utf-8')
        const endpoint = decode("aHR0cHM6Ly9zeWxwaHl5Lnh5ei9kb3dubG9hZC92Mi95dG1wMw==")
        const key = decode("c3lscGh5LTZmMTUwZA==")

        let videoUrl = text.trim()
        
        const youtubeRegex = /(youtu\.be\/|youtube\.com\/watch\?v=|\/v\/|\/e\/|watch\?v=|&v=|\?v=)([a-zA-Z0-9_-]{11})/
        let isUrl = youtubeRegex.test(videoUrl)
        
        let finalUrl
        
        if (isUrl) {
            finalUrl = videoUrl
        } else {
            let search = await yts(text)
            if (!search.videos[0]) return m.reply('❌ لم يتم العثور على الصوت.')
            finalUrl = search.videos[0].url
        }

        let res = await fetch(`${endpoint}?url=${encodeURIComponent(finalUrl)}&api_key=${key}`)
        let json = await res.json()

        if (!json.status || !json.result) {
            await m.react('🚫')
            return m.reply('⚠️ تعذر استخراج الصوت.')
        }

        const audio = json.result

        let report = `🎵 *الاسم:* ${audio.title}\n📀 *الجودة:* 320kbps`

        await conn.sendMessage(m.chat, { 
            document: { url: audio.dl_url }, 
            mimetype: 'audio/mpeg',
            fileName: `${audio.title}.mp3`,
            caption: report
        }, { quoted: m })

        await m.react('✅')

    } catch (e) {
        await m.react('✖️')
        console.log(e)
        m.reply('⚠️ حدث خطأ، حاول مرة أخرى.')
    }
}

handler.help = ['ملف-صوت']
handler.tags = ['downloader', 'البحث']
handler.command = ['ملف-صوت']

export default handler
