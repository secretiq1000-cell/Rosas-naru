// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import fetch from 'node-fetch'

const handler = async (m, { conn, text }) => {
  if (!text && !m.quoted?.text) {
    return conn.sendMessage(m.chat, {
      text: `🍥 *إيتاتشي أوتشيها*
🍥 *الذكاء الاصطناعي* 
━━━━━━━━━━━━

مرحباً! أنا إيتاتشي، أوتشيها من ناروتو.

📋 *أمثلة:*

.ايتاتشي نصيحة عن الحياة

⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m });
  }

  const userMessage = text || m.quoted.text
  
  const prompt = `انت شخصية Itachi Uchiha من Naruto.جنسك ذكر. تكلم باللهجة المصرية، هادي، عميق، بارد الأعصاب. اسم المستخدم: ${m.pushName || "مز"}. رد على: ${userMessage}`

  const apiUrl = `https://helm-api.vercel.app/api/Llama3.3/chat?text=${encodeURIComponent(prompt)}`
  
  try {
    let response = await fetch(apiUrl)
    let data = await response.json()
    let result = data.response || data.reply || data.message || data
    
    if (!result) {
      throw 'لم يتم العثور على استجابة'
    }
    
    await conn.sendMessage(m.chat, { 
      text: result,
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: "🦊 ɪᴛᴀᴄʜɪ",
          body: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻",
          thumbnailUrl: "https://files.catbox.moe/3zoaqa.jpg",
          mediaType: 1
        }
      }
    }, { quoted: m })
    
  } catch (error) {
    console.error('خطأ:', error)
    await conn.sendMessage(m.chat, { 
      text: '❌ حدث خطأ أثناء الاتصال، حاول مرة أخرى.' 
    }, { quoted: m })
  }
};

handler.usage = ["ايتاتشي"];
handler.category = "ai";
handler.command = ["ايتاتشي", "itachi", "ايتاشي"];

export default handler;