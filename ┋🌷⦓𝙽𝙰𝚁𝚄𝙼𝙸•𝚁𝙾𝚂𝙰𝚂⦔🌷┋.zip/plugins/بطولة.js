// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

let handler = async (m, { conn }) => {
  try {
    // التحقق من أنها مجموعة
    if (!m.isGroup) {
      return conn.sendMessage(m.chat, { 
        text: "❌ *هذا الأمر يعمل فقط في المجموعات*" 
      }, { quoted: m })
    }

    const metadata = await conn.groupMetadata(m.chat)
    const participants = metadata.participants.map(p => p.id)

    if (participants.length < 2) {
      return await conn.sendMessage(m.chat, { 
        text: "❌ *القروب يحتاج عضوين على الأقل لبدء البطولة.*" 
      }, { quoted: m })
    }

    const fighter1 = participants[Math.floor(Math.random() * participants.length)]
    let fighter2 = fighter1
    while (fighter2 === fighter1) {
      fighter2 = participants[Math.floor(Math.random() * participants.length)]
    }

    const name1 = fighter1.split('@')[0]
    const name2 = fighter2.split('@')[0]

    const infoText = `
🏆 *بطولة الهيبة بدأت!* 🏆

━━━━━━━━━━━━━━━━━
👤 *@${name1}*  VS  *@${name2}*
━━━━━━━━━━━━━━━━━

✨ « بطولة… أمر يضيف جو من المنافسة والفخامة داخل القروب. »

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

    await conn.sendMessage(m.chat, { 
      text: infoText, 
      mentions: [fighter1, fighter2] 
    }, { quoted: m })
    
  } catch (err) {
    console.error('❌ خطأ في أمر بطولة:', err)
    await conn.sendMessage(m.chat, { 
      text: "❌ *حدث خطأ أثناء تنفيذ الأمر*" 
    }, { quoted: m })
  }
}

handler.command = ['بطولة']
handler.help = ['بطولة']
handler.category = 'games'
handler.description = '🏆 يعلن بطولة هيبة بين الأعضاء'
handler.group = true

export default handler
