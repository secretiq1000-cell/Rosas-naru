// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  // إذا لم يكتب أي سؤال
  if (!text && !m.quoted?.text) {
    return conn.sendMessage(m.chat, {
      text: `🤖 *ليما 3.3 - الذكاء الاصطناعي* 🤖
━━━━━━━━━━━━━━━━━

مرحباً! أنا ليما، ذكاء اصطناعي متطور.

📝 *الاستخدام:* 
.ليما <سؤالك>

📋 *أمثلة:*
.ليما صلي على النبي

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m })
  }

  const prompt = text || m.quoted.text
  const apiUrl = `https://helm-api.vercel.app/api/Llama3.3/chat?text=${encodeURIComponent(prompt)}`
  
  try {
    let response = await fetch(apiUrl)
    let data = await response.json()
    let result = data.response || data.reply || data.message || data
    
    if (!result) {
      throw 'لم يتم العثور على استجابة'
    }
    
    await conn.sendMessage(m.chat, { text: result }, { quoted: m })
  } catch (error) {
    console.error('خطأ:', error)
    await conn.sendMessage(m.chat, { 
      text: '❌ حدث خطأ أثناء الاتصال بالذكاء الاصطناعي، حاول مرة أخرى.' 
    }, { quoted: m })
  }
}

handler.help = ['ليما']
handler.tags = ['AI']
handler.command = ['ليما']

export default handler