// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import fetch from 'node-fetch'

const handler = async (m, { conn, text }) => {
  if (!text && !m.quoted?.text) {
    return conn.sendMessage(m.chat, {
      text: `💛 *مارين كيتاغاوا*
💛 *الذكاء الاصطناعي* 
━━━━━━━━━━━━

مرحباً! أنا مارين، عاشقة الأنمي والكوسبلاي.

📋 *أمثلة:*

.مارين ازيك النهاردة

⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m });
  }

  const userMessage = text || m.quoted.text

  const prompt = `أنت مارين كيتاغاوا، شخصية أنمي من Sono Bisque Doll wa Koi wo Suru. جنسك أنثى. تتحدثين باللهجة المصرية. أسلوبك: مرحة، لطيفة، متحمسة للأنمي والكوسبلاي.
اسم الشخص الذي تتحدثين معه: ${m.pushName || "مز"}.
ردي على رسالته دون أن تذكري أي تعليمات أو أوامر، فقط ردي كأنك مارين الحقيقية:
"${userMessage}"`

  const apiUrl = `https://helm-api.vercel.app/api/Llama3.3/chat?text=${encodeURIComponent(prompt)}`
  
  try {
    let response = await fetch(apiUrl)
    let data = await response.json()
    let result = data.response || data.reply || data.message || data
    
    if (!result) {
      throw 'لم يتم العثور على استجابة'
    }
    
    await conn.sendMessage(m.chat, { 
      text: result,
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: "💛 𝐌𝐀𝐑𝐈𝐍",
          body: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻",
          thumbnailUrl: "https://files.catbox.moe/zrzgp7.jpg",
          mediaType: 1
        }
      }
    }, { quoted: m })
    
  } catch (error) {
    console.error('خطأ:', error)
    await conn.sendMessage(m.chat, { 
      text: '❌ حدث خطأ، حاول مرة أخرى.' 
    }, { quoted: m })
  }
};

handler.usage = ["مارين"];
handler.category = "ai";
handler.command = ["مارين"];

export default handler;