let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let name = conn.getName(m.sender) || 'مستخدم';
  let taguser = '@' + m.sender.split("@")[0];

  let currentTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

  let groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
  let groupName = groupMetadata ? groupMetadata.subject : 'غير معروف';
  let groupMembers = groupMetadata ? groupMetadata.participants.length : 'غير معروف';

  let message = `
╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊${taguser}⌉
── • ◈ • ──
*⌝🕌┊قــســم الدين┊🕌⌞* 
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹𝑫𝑨𝑵𝑵𝒀›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
┤┌ ─๋︩︪─✦ديني☇─˚᳝᳝𖥻

> │┊ ۬.͜ـ🕌˖ ⟨ايـه☇ 

> │┊ ۬.͜ـ🕌˖ ⟨تـفـسير☇

> │┊ ۬.͜ـ🕌˖ ⟨فـتاوي☇

> │┊ ۬.͜ـ🕌˖ ⟨اذكـار☇ 

> │┊ ۬.͜ـ🕌˖ ⟨اذكار-الصباح☇ 

> │┊ ۬.͜ـ🕌˖ ⟨ادعـيـة☇ 

> │┊ ۬.͜ـ🕌˖ ⟨دعاء-رمضان☇ 

> │┊ ۬.͜ـ🕌˖ ⟨اسـتغـفار☇ 

> │┊ ۬.͜ـ🕌˖ ⟨اذان☇

> │┊ ۬.͜ـ🕌˖ ⟨مواقيت☇

> │┊ ۬.͜ـ🕌˖ ⟨الـلـه☇ 

> │┊ ۬.͜ـ🕌˖ ⟨قـصـص☇

> │┊ ۬.͜ـ🕌˖ ⟨انـشوده☇ 

> │┊ ۬.͜ـ🕌˖ ⟨حـديـث☇ 

> │┊ ۬.͜ـ🕌˖ ⟨خـطـبة☇ 

┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹𝑫𝑨𝑵𝑵𝒀›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ  `;

  const emojiReaction = '🕌';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    await conn.sendMessage(m.chat, { 
      image: { url: 'https://i.postimg.cc/xC9yTFq4/IMG-20251230-WA0104.jpg' },
      caption: message,
      mentions: [m.sender]
    });
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق8)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;
