// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios'
import fs from 'fs'
import path from 'path'
import { exec } from 'child_process'
import { fileURLToPath } from 'url'
import { promisify } from 'util'

const execPromise = promisify(exec)
const __dirname = path.dirname(fileURLToPath(import.meta.url))

async function convertImageToWebpHighRes(inputBuffer, tempName = 'sticker') {
  return new Promise((resolve, reject) => {
    const tempDir = path.join(process.cwd(), 'temp')
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

    const inputPath = path.join(tempDir, `${tempName}.jpg`)
    const outputPath = path.join(tempDir, `${tempName}.webp`)

    fs.writeFileSync(inputPath, inputBuffer)

    const cmd = `ffmpeg -y -i "${inputPath}" -vf "scale='min(720,iw)':'min(720,ih)':force_original_aspect_ratio=decrease" "${outputPath}"`

    exec(cmd, (err) => {
      fs.unlinkSync(inputPath)
      if (err) return reject(err)
      try {
        const webpBuffer = fs.readFileSync(outputPath)
        fs.unlinkSync(outputPath)
        resolve(webpBuffer)
      } catch (e) {
        reject(e)
      }
    })
  })
}

let handler = async (m, { conn, text }) => {
  try {
    const jid = m.chat
    const queryText = text.trim()

    if (!queryText) {
      return conn.sendMessage(jid, { 
        text: `⚠️ *أدخل مصطلح البحث*\n\nمثال: .ملصقات غابة\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐` 
      }, { quoted: m })
    }

    await conn.sendMessage(jid, { 
      text: `🔍 *جاري البحث عن:* ${queryText}\n⏳ يرجى الانتظار...` 
    }, { quoted: m })

    const res = await axios.get(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(queryText)}`)
    const results = res.data?.data?.filter(i => i.image_url) || []

    if (results.length === 0) {
      return conn.sendMessage(jid, { 
        text: `❌ *لم يتم العثور على صور* لـ "${queryText}"\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐` 
      }, { quoted: m })
    }

    // تحديد الشخص المستهدف
    let target = m.sender
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      target = m.mentionedJid[0]
    } else if (m.quoted) {
      target = m.quoted.sender
    }
    
    const targetName = target.split('@')[0]

    const count = Math.min(5, results.length)
    const selected = results.slice(0, count)

    let successCount = 0
    for (const [i, item] of selected.entries()) {
      try {
        const imageUrl = item.image_url.replace(/_small|_medium/, '_original')
        const response = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 15000 })
        if (!response.data) continue

        const webpBuffer = await convertImageToWebpHighRes(Buffer.from(response.data), `sticker_${Date.now()}_${i}`)
        await conn.sendMessage(jid, { sticker: webpBuffer }, { quoted: m })
        successCount++
      } catch (err) {
        console.error('⚠️ فشل ملصق:', err.message)
      }
    }

    await conn.sendMessage(jid, { 
      text: `✅ *تم إنشاء ${successCount} ملصق عالي الدقة* ✨\n🔍 بحث: ${queryText}\n👤 لـ @${targetName}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
      mentions: [target]
    }, { quoted: m })

  } catch (err) {
    console.error('[ملصقات] خطأ:', err.message)
    await conn.sendMessage(m.chat, { 
      text: `❌ *حدث خطأ أثناء البحث*\n\n${err.message}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐` 
    }, { quoted: m })
  }
}

handler.command = ['ملصقات','ستيك']
handler.help = ['ملصقات']
handler.category = 'tools'
handler.description = '🔍 البحث عن صور عالية الدقة وتحويلها لملصقات WebP'

export default handler
