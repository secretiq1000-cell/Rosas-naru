// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

let handler = async (m, { conn }) => {
  // التحقق من أنها مجموعة
  if (!m.isGroup) {
    return conn.sendMessage(m.chat, { 
      text: '🚫 *هذا الأمر يعمل فقط في المجموعات*' 
    }, { quoted: m })
  }

  // جلب بيانات المجموعة
  const metadata = await conn.groupMetadata(m.chat)
  const members = metadata.participants.filter(p => p.id !== m.sender)
  
  if (members.length === 0) {
    return conn.sendMessage(m.chat, { 
      text: '😢 *لا يوجد أعضاء آخرين في المجموعة*' 
    }, { quoted: m })
  }

  // اختيار عضو عشوائي
  const random = members[Math.floor(Math.random() * members.length)]
  const name = random.id.split('@')[0]

  // رسائل عشوائية
  const messages = [
    `💘 *اللي بيحبك سرًا:* @${name}`,
    `😍 *في حد بيحبك من غير ما تعرف:* @${name}`,
    `💕 *قلب حد بيتعلق بيك:* @${name}`,
    `🥰 *في معجب سري ليك:* @${name}`,
    `🤫 *سأقول لك السر...* @${name} بيحبك!`
  ]
  
  const randomMsg = messages[Math.floor(Math.random() * messages.length)]

  const message = `${randomMsg}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

  await conn.sendMessage(m.chat, { 
    text: message, 
    mentions: [random.id] 
  }, { quoted: m })
}

handler.command = ['حب-بالسر', 'بالسر']
handler.help = ['حب-بالسر']
handler.category = 'fun'
handler.description = '💘 يكشف مين بيحبك في الجروب (فضيحة)'
handler.group = true

export default handler
