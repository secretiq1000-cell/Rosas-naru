import axios from "axios";

const الحد_الأقصى_MB = 10;

let handler = async (m, { conn, usedPrefix, command, text }) => {
  // تأكد من وجود رابط
  if (!text || !text.includes('tiktok')) {
    return conn.reply(m.chat, '❤️ ╰─⊱ *أدخل رابط TikTok صحيح* ⊱─╮', m);
  }

  // فك اختصار الرابط إذا كان vm.tiktok.com
  let الرابط_الأصلي = text;
  if (text.includes('vm.tiktok.com')) {
    try {
      const response = await axios.get(text, {
        maxRedirects: 0,
        validateStatus: (status) => status === 301 || status === 302 || status === 200
      });
      الرابط_الأصلي = response.headers.location || text;
    } catch (e) {
      console.log('خطأ في فك الاختصار:', e.message);
    }
  }

  try {
    await m.react('⏳');

    const رابط_الفيديو = await احصل_فيديو_TikTok_HD(الرابط_الأصلي);

    if (!رابط_الفيديو) {
      throw new Error('تعذر الحصول على الفيديو - قد يكون API الموقع معطلاً');
    }

    // التحقق من صحة الرابط وحجم الفيديو
    try {
      const head = await axios.head(رابط_الفيديو, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
        timeout: 10000
      });

      const الحجم_الفعلي = head.headers['content-length'];
      if (الحجم_الفعلي) {
        const الحجم_MB = parseInt(الحجم_الفعلي) / (1024 * 1024);
        if (الحجم_MB > الحد_الأقصى_MB) {
          return conn.reply(
            m.chat,
            `❌ حجم الفيديو *${الحجم_MB.toFixed(2)} MB* وتجاوز الحد المسموح (${الحد_الأقصى_MB} MB).`,
            m
          );
        }
      }
    } catch (e) {
      console.log('تحذير: لا يمكن التحقق من حجم الفيديو، محاولة الإرسال مباشرة');
    }

    await conn.sendMessage(m.chat, {
      video: { url: رابط_الفيديو },
      caption: `
╔═━━••【🧬】••━━═╗
✦ [ TikTok بدون علامة مائية - HD ] ✅ ✦
╚═━━••【📮】••━━═╝`
    }, { quoted: m });

    await m.react('✅');
  } catch (e) {
    console.error('الخطأ التفصيلي:', e.message);
    await m.react('❌');
    
    let رسالة_الخطأ = '⚠️ *حدث خطأ أثناء معالجة الفيديو*\n\n';
    if (e.message.includes('getaddrinfo') || e.message.includes('ENOTFOUND')) {
      رسالة_الخطأ += '❌ لا يمكن الاتصال بخدمة التحميل';
    } else if (e.message.includes('404')) {
      رسالة_الخطأ += '❌ رابط الفيديو غير صالح أو منتهي الصلاحية';
    } else if (e.message.includes('timeout')) {
      رسالة_الخطأ += '⏰ انتهت المهلة أثناء محاولة جلب الفيديو';
    } else {
      رسالة_الخطأ += `📛 ${e.message}`;
    }
    conn.reply(m.chat, رسالة_الخطأ, m);
  }
};

handler.help = ['تيك2 <رابط>'];
handler.tags = ['التحميلات'];
handler.command = ['تيك2'];

export default handler;

// ─────────────────────────────────────
// دالة التحميل باستخدام SSSTik.io API
// ─────────────────────────────────────

async function احصل_فيديو_TikTok_HD(url) {
  try {
    // إضافة hd=1 للحصول على جودة عالية
    const params = new URLSearchParams();
    params.append('url', url);
    params.append('hd', '1');
    
    const { data } = await axios.post('https://ssstik.io/api/abc', params, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Referer': 'https://ssstik.io/',
        'Origin': 'https://ssstik.io',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'ar,en;q=0.9',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin'
      },
      timeout: 15000
    });
    
    // تحليل الرد من API
    if (typeof data === 'string') {
      // بعض الأحيان الرد يكون نصي، نحاول استخراج الرابط
      const match = data.match(/https?:\/\/[^\s"']+\.mp4/);
      if (match) return match[0];
      return null;
    }
    
    // إذا كان الرد JSON
    if (data && data.video_no_watermark) {
      return data.video_no_watermark;
    } else if (data && data.video) {
      return data.video;
    } else if (data && data.url) {
      return data.url;
    }
    
    console.log('رد API غير متوقع:', data);
    return null;
    
  } catch (e) {
    console.error('خطأ في SSSTik.io:', e.message);
    if (e.response) {
      console.error('رد الخادم:', e.response.status, e.response.data);
    }
    
    // محاولة بديلة باستخدام TikWM API إذا فشل SSSTik
    return await محاولة_بديلة_TikWM(url);
  }
}

// دالة احتياطية باستخدام TikWM
async function محاولة_بديلة_TikWM(url) {
  try {
    const { data } = await axios.get(`https://www.tikwm.com/api/`, {
      params: { url },
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://www.tikwm.com/'
      },
      timeout: 10000
    });

    const النتيجة = data?.data;
    if (!النتيجة) return null;

    return النتيجة.hdplay || النتيجة.play_2 || النتيجة.play || null;
  } catch (e) {
    console.error('خطأ في TikWM الاحتياطي:', e.message);
    return null;
  }
}
