import yts from "yt-search"
import { spawn } from 'child_process'
import fs from 'fs'
import path from 'path'
import os from 'os'

let ytmp3mobi = async (youtubeUrl, format = "mp4") => {
    const regYoutubeId = /(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
    const match = youtubeUrl.match(regYoutubeId)
    const videoId = match ? match[1] : null

    if (!videoId) throw Error("❌ لم أتمكن من استخراج معرف الفيديو")

    const urlParam = { v: videoId, f: format, _: Date.now() }
    const headers = { "Referer": "https://id.ytmp3.mobi/" }

    const fetchJson = async (url) => {
        const res = await fetch(url, { headers })
        const text = await res.text()
        try {
            return JSON.parse(text)
        } catch {
            throw Error("خطأ في الاستجابة")
        }
    }

    const { convertURL } = await fetchJson("https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=" + Math.random())
    const { progressURL, downloadURL } = await fetchJson(`${convertURL}&${new URLSearchParams(urlParam).toString()}`)

    let error, progress, title
    for (let i = 0; i < 15; i++) {
        await new Promise(resolve => setTimeout(resolve, 3000))
        const result = await fetchJson(progressURL)
        error = result.error
        progress = result.progress
        title = result.title
        if (error) throw Error(`خطأ: ${error}`)
        if (progress === 3) break
    }
    if (progress !== 3) throw Error("انتهى الوقت")

    return { title, downloadURL }
}

async function videoToAudio(videoUrl) {
    const tmpIn = path.join(os.tmpdir(), `input_${Date.now()}.mp4`)
    const tmpOut = path.join(os.tmpdir(), `output_${Date.now()}.mp3`)
    
    const response = await fetch(videoUrl)
    const buffer = await response.arrayBuffer()
    fs.writeFileSync(tmpIn, Buffer.from(buffer))
    
    await new Promise((resolve, reject) => {
        const ff = spawn('ffmpeg', [
            '-y', '-i', tmpIn, '-vn', 
            '-acodec', 'libmp3lame', 
            '-b:a', '128k', tmpOut
        ])
        ff.on('close', (code) => {
            if (code !== 0) reject(new Error(`ffmpeg error ${code}`))
            else resolve()
        })
        ff.on('error', reject)
    })
    
    const audioBuffer = fs.readFileSync(tmpOut)
    
    try {
        fs.unlinkSync(tmpIn)
        fs.unlinkSync(tmpOut)
    } catch(e) {}
    
    return audioBuffer
}

let handler = async (m, { conn, args, command }) => {
    try {
        if (!args[0]) {
            return m.reply(`🎵 طريقة الاستخدام:
.${command} رابط_يوتيوب أو عنوان_الفيديو

📌 مثال:
.${command} https://youtube.com/watch?v=3hlWLvE8my8
.${command} اغنية ضاع الحلم منا`)
        }

        let query = args.join(" ")
        let videoUrl
        let videoTitle = ""

        const youtubeRegex = /(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
        const match = query.match(youtubeRegex)

        if (match) {
            videoUrl = query
            await m.reply("⏳ جاري تجهيز الصوت، انتظر قليلاً...")
        } else {
            const searchResults = await yts(query)
            if (!searchResults || !searchResults.videos.length) {
                return m.reply("❌ لم أجد أي نتائج للبحث المطلوب.")
            }
            const firstVideo = searchResults.videos[0]
            videoUrl = firstVideo.url
            videoTitle = firstVideo.title
            await m.reply(`✅ تم العثور على: *${videoTitle}*\n⏳ جاري التحميل ...\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`)
        }

        const { title, downloadURL } = await ytmp3mobi(videoUrl, "mp4")
        const audioBuffer = await videoToAudio(downloadURL)
        
        await conn.sendMessage(m.chat, {
            audio: audioBuffer,
            mimetype: "audio/mpeg",
            fileName: `${title || videoTitle}.mp3`
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        m.reply(`❌ خطأ: ${e.message}`)
    }
}

handler.command = ['اغنية', 'اغنيه']
handler.help = ['اغنية', 'اغنيه']
handler.tags = ['downloader']

export default handler
