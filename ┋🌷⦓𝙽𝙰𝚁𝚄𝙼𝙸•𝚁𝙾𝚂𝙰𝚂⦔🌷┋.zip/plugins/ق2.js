let handler = async (m, { conn }) => {
  let taguser = '@' + m.sender.split("@")[0];

  let message = `
╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊${taguser}⌉
── • ◈ • ──
*⌝⛄┊قــســم المشرفين┊⌞* 
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹🧬›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
┤┌ ─๋︩︪─✦ *أوامــر المشرفين* ☇─˚᳝᳝𖥻

> │┊ 🛡️ *منـشن* 

> │┊ 🛡️ *نـداء*  

> │┊ 🛡️ *جـروب*

> │┊ 🛡️ *وقـت* 

> │┊ 🛡️ *كـتـم* 

> │┊ 🛡️ *فك-كتم* 

> │┊ 🛡️ *طـرد*

> │┊ 🛡️ *طرد-دوله* 

> │┊ 🛡️ *سـحر*  

> │┊ 🛡️ *انـذار*  

> │┊ 🛡️ *انذارات*  

> │┊ 🛡️ *لينك*  

> │┊ 🛡️ *اعفـاء*  

> │┊ 🛡️ *ترقـيه*  

> │┊ 🛡️ *المتصلين* 

> │┊ 🛡️ *قــبول*

> │┊ 🛡️ *دعـوه*  

> │┊ 🛡️ *تجديد*  

> │┊ 🛡️ *مخـفي*  

> │┊ 🛡️ *حـذف*

> │┊ 🛡️ *مراقـبه*  
┤└─ׅ─ׅ┈ ─๋︩︪<🧬> ──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹𝑫𝑨𝑵𝑵𝒀›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ  
`;

  const emojiReaction ='🛡️';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    await conn.sendMessage(m.chat, { 
      image: { url: 'https://i.postimg.cc/9XRzwYTJ/IMG-20251230-WA0030.jpg' },
      caption: message,
      mentions: [m.sender]
    });
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق2)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;
