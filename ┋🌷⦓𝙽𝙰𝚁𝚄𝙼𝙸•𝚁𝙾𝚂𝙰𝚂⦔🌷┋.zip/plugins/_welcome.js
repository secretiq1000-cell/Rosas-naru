import fs from 'fs'
import { WAMessageStubType } from '@whiskeysockets/baileys'

async function generarBienvenida({ conn, userId, groupMetadata, chat }) {
    try {
        const username = `@${userId.split('@')[0]}`
        const pp = await conn.profilePictureUrl(userId, 'image').catch(() => 'https://i.postimg.cc/nLhMmCXy/20250703-115649.png')
        const fecha = new Date().toLocaleDateString("ar-EG", { timeZone: "Africa/Cairo", day: 'numeric', month: 'long', year: 'numeric' })
        
        // ✅ التحقق من وجود groupMetadata
        if (!groupMetadata) {
            return {
                pp: pp,
                caption: `🌷 *مرحباً بك في المجموعة!* 🌷\n\n👤 *العضو الجديد:* ${username}\n📅 *التاريخ:* ${fecha}\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻`,
                mentions: [userId]
            }
        }
        
        const groupSize = (groupMetadata.participants?.length || 0) + 1
        const desc = groupMetadata.desc?.toString() || '📝 *لا يوجد وصف للمجموعة*'
        
        // ✅ FIX: التحقق من أن chat.sWelcome هو نص
        let mensaje = ''
        if (chat?.sWelcome && typeof chat.sWelcome === 'string') {
            mensaje = chat.sWelcome
                .replace(/{usuario}/g, username)
                .replace(/{grupo}/g, `*${groupMetadata.subject || 'المجموعة'}*`)
                .replace(/{desc}/g, desc)
        } else {
            // رسالة افتراضية إذا لم تكن هناك رسالة مخصصة
            mensaje = 'أهلاً وسهلاً بك في مجموعتنا! 🎉'
        }
        
        const caption = `🌷 *مرحباً بك في العائلة!* 🌷\n\n` +
                       `🕶️ *المجموعة:* ${groupMetadata.subject || 'المجموعة'}\n` +
                       `👤 *العضو الجديد:* ${username}\n` +
                       `📝 *الرسالة:* ${mensaje}\n` +
                       `📋 *وصف المجموعة:*\n${desc}\n\n` +
                       `👥 *عدد الأعضاء الآن:* ${groupSize}\n` +
                       `📅 *التاريخ:* ${fecha}\n\n` +
                       `*بــوت نـاࢪومـي روسـاس يرحب بك في مجموعتنا...*\n` +
                       `*استخدم .الاوامر لرؤية الأوامر المتاحة.*\n\n` +
                       `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻`
        
        return { pp, caption, mentions: [userId] }
        
    } catch (error) {
        console.error('Error en generarBienvenida:', error)
        return {
            pp: 'https://i.postimg.cc/nLhMmCXy/20250703-115649.png',
            caption: `🌷 *مرحباً بك في المجموعة!* 🌷\n\n👤 *العضو الجديد:* @${userId?.split('@')[0] || 'مستخدم'}\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 🌷`,
            mentions: [userId]
        }
    }
}

async function generarDespedida({ conn, userId, groupMetadata, chat }) {
    try {
        const username = `@${userId.split('@')[0]}`
        const pp = await conn.profilePictureUrl(userId, 'image').catch(() => 'https://i.postimg.cc/nLhMmCXy/20250703-115649.png')
        const fecha = new Date().toLocaleDateString("ar-EG", { timeZone: "Africa/Cairo", day: 'numeric', month: 'long', year: 'numeric' })
        
        // ✅ التحقق من وجود groupMetadata
        if (!groupMetadata) {
            return {
                pp: pp,
                caption: `🌷 *وداعاً...* 🌷\n\n👤 *العضو المغادر:* ${username}\n📅 *التاريخ:* ${fecha}\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 👻`,
                mentions: [userId]
            }
        }
        
        const groupSize = Math.max(0, (groupMetadata.participants?.length || 1) - 1)
        const desc = groupMetadata.desc?.toString() || '📝 *لا يوجد وصف للمجموعة*'
        
        // ✅ FIX: التحقق من أن chat.sBye هو نص (ليس true/false)
        let mensaje = ''
        if (chat?.sBye && typeof chat.sBye === 'string') {
            mensaje = chat.sBye
                .replace(/{usuario}/g, username)
                .replace(/{grupo}/g, groupMetadata.subject || 'المجموعة')
                .replace(/{desc}/g, `*${desc}*`)
        } else {
            // رسالة افتراضية إذا لم تكن هناك رسالة مخصصة أو إذا كان true/false
            mensaje = 'وداعاً... نتمنى لك التوفيق! 👋'
        }
        
        const caption = `💀 *وداعاً يا صديقي...* 💀\n\n` +
                       `🕶️ *المجموعة:* ${groupMetadata.subject || 'المجموعة'}\n` +
                       `👤 *العضو المغادر:* ${username}\n` +
                       `📝 *الرسالة:* ${mensaje}\n` +
                       `📋 *وصف المجموعة:*\n${desc}\n\n` +
                       `👥 *عدد الأعضاء الآن:* ${groupSize}\n` +
                       `📅 *التاريخ:* ${fecha}\n\n` +
                       `*بــوت دانـي يتمنى لك حظاً سعيداً...*\n` +
                       `*لا تنسى أن العائلة تنتظر عودتك دائماً.*\n\n` +
                       `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
        
        return { pp, caption, mentions: [userId] }
        
    } catch (error) {
        console.error('Error en generarDespedida:', error)
        return {
            pp: 'https://i.postimg.cc/nLhMmCXy/20250703-115649.png',
            caption: `💀 *وداعاً...* 💀\n\n👤 *العضو المغادر:* @${userId?.split('@')[0] || 'مستخدم'}\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`,
            mentions: [userId]
        }
    }
}

let handler = m => m

handler.before = async function (m, { conn, participants, groupMetadata }) {
    try {
        // ✅ التحقق الأساسي
        if (!m.messageStubType || !m.isGroup) return !0
        
        // ✅ التحقق من وجود قاعدة البيانات
        if (!global.db?.data?.chats?.[m.chat]) {
            console.log('❌ لا توجد بيانات للمجموعة في قاعدة البيانات')
            return !0
        }
        
        const chat = global.db.data.chats[m.chat]
        if (!chat.welcome) return !0
        
        const primaryBot = chat.primaryBot
        if (primaryBot && conn.user.jid !== primaryBot) return !0
        
        const userId = m.messageStubParameters?.[0]
        if (!userId) return !0
        
        // ✅ استخدام groupMetadata من الـ handler (الذي يأتي من handler.js)
        let metadata = groupMetadata
        if (!metadata) {
            try {
                // محاولة الحصول على metadata إذا لم يكن موجوداً
                metadata = await conn.groupMetadata(m.chat)
            } catch (metadataError) {
                console.log('⚠️ فشل في الحصول على groupMetadata:', metadataError.message)
                // استخدام بيانات بديلة
                metadata = {
                    subject: m.chat.split('@')[0],
                    participants: participants || [],
                    desc: ''
                }
            }
        }
        
        // ✅ إعداد contextInfo
        const rcanal = {
            contextInfo: {
                mentionedJid: [],
                forwardingScore: 0,
                isForwarded: false
            }
        }
        
        // ✅ ترحيب عند دخول عضو جديد
        if (m.messageStubType === WAMessageStubType.GROUP_PARTICIPANT_ADD) {
            const { pp, caption, mentions } = await generarBienvenida({
                conn,
                userId,
                groupMetadata: metadata,
                chat
            })
            
            rcanal.contextInfo.mentionedJid = mentions || [userId]
            
            await conn.sendMessage(m.chat, {
                image: { url: pp },
                caption: caption,
                mentions: mentions,
                ...rcanal
            }, { quoted: null })
            
            console.log(`✅ تم الترحيب بـ ${userId.split('@')[0]} في المجموعة`)
        }
        
        // ✅ توديع عند خروج عضو
        if (m.messageStubType === WAMessageStubType.GROUP_PARTICIPANT_REMOVE || 
            m.messageStubType === WAMessageStubType.GROUP_PARTICIPANT_LEAVE) {
            const { pp, caption, mentions } = await generarDespedida({
                conn,
                userId,
                groupMetadata: metadata,
                chat
            })
            
            rcanal.contextInfo.mentionedJid = mentions || [userId]
            
            await conn.sendMessage(m.chat, {
                image: { url: pp },
                caption: caption,
                mentions: mentions,
                ...rcanal
            }, { quoted: null })
            
            console.log(`✅ تم توديع ${userId.split('@')[0]} من المجموعة`)
        }
        
    } catch (error) {
        console.error('❌ خطأ في معالج الترحيب:', error.message)
        return !0
    }
}

export { generarBienvenida, generarDespedida }
export default handler