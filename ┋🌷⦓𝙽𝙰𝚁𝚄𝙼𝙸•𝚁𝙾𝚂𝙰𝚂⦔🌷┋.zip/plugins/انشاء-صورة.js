import axios from 'axios';
import baileys from '@whiskeysockets/baileys';

const { proto, generateWAMessageFromContent} = baileys;

async function sendList(conn, jid, data, quoted) {
  const msg = generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({ text: data.body}),
          footer: proto.Message.InteractiveMessage.Footer.create({ text: data.footer}),
          header: proto.Message.InteractiveMessage.Header.create({ title: data.title}),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
              name: 'single_select',
              buttonParamsJson: JSON.stringify({
                title: data.buttonText,
                sections: data.sections
})
}]
})
})
}
}
}, { quoted});

  await conn.relayMessage(jid, msg.message, { messageId: msg.key.id});
}

const styles = {
  default: "الواقعية",
  ghibli: "فن غيبلي",
  cyberpunk: "سايبربانك",
  anime: "أنمي",
  portrait: "بورتريه",
  chibi: "تشيبي",
  pixel: "فن البكسل",
  oil: "الرسم الزيتي",
  "3d": "ثلاثي الأبعاد"
};

const sizes = {
  "1:1": "مربع (1024x1024)",
  "3:2": "أفقي (1080x720)",
  "2:3": "عمودي (720x1080)"
};

const handler = async (m, { conn, text, command, usedPrefix}) => {
  const selected = m?.listResponseMessage?.singleSelectReply?.selectedRowId;
  const query = selected || text?.trim();
  if (!query) return m.reply('المرجو تقديم بعد الامر وصف الصوره\nيدعم جميع الغات');

  const parts = query.replace(usedPrefix + command, '').trim().split(' ');
  const style = parts[0];
  const size = parts[1];
  const prompt = parts.slice(2).join(' ');

  if (!styles[style]) {
    await m.reply('🔄 جاري تجهيز الأنماط...');
    const sections = [{
      title: '🎨 اختر النمط',
      rows: Object.entries(styles).map(([key, name]) => ({
        title: name,
        description: `نمط ${name}`,
        id: `${usedPrefix}${command} ${key} ${query}`
}))
}];

    return await sendList(conn, m.chat, {
      title: '🖌️ أنماط الرسم',
      body: `الوصف: ${query}`,
      footer: 'اختر نمطًا لتوليد الصورة',
      buttonText: '🎨 اختر النمط',
      sections
}, m);
}

  if (!sizes[size]) {
    await m.reply('🔄 جاري تجهيز الأحجام...');
    const sections = [{
      title: '📐 اختر الحجم',
      rows: Object.entries(sizes).map(([key, name]) => ({
        title: name,
        description: `الحجم: ${key}`,
        id: `${usedPrefix}${command} ${style} ${key} ${parts.slice(1).join(' ')}`
}))
}];

    return await sendList(conn, m.chat, {
      title: '📏 أحجام الصورة',
      body: `النمط: ${styles[style]}`,
      footer: 'اختر حجمًا لتوليد الصورة',
      buttonText: '📐 اختر الحجم',
      sections
}, m);
}

  await m.reply('🧠 جاري توليد الصورة...');
  try {
    const res = await axios.get(`https://obito-mr-apis.vercel.app/api/ai/deepImg?txt=${encodeURIComponent(prompt)}&style=${style}&size=${size}`);
    const image = res.data?.data?.image_url;
    if (!image) throw new Error('لم يتم العثور على رابط الصورة');

    await conn.sendMessage(m.chat, {
      image: { url: image},
      caption: `🖼️ *${res.data.data.prompt}*\n🎨 النمط: ${res.data.data.style}\n📐 الحجم: ${res.data.data.size}`
}, { quoted: m});
} catch (e) {
    console.error(e);
    await m.reply('❌ حدث خطأ أثناء توليد الصورة.');
}
};

handler.command = ['انشاء-صورة'];
handler.help = ['انشاء-صورة'];
handler.tags = ['انشاء-صورة'];

export default handler;
