import fetch from "node-fetch";
import fs from 'fs';

// رسائل انتظار متغيرة
const waitMessages = [
  "⏳ جاري معالجة طلبك، اصبر لحظة ...",
  "🤖 أقوم بالتفكير في إجابتك الآن ...",
  "⌛ ثواني بس وحيكون الرد جاهز ...",
  "🚀 المعالجة قيد التنفيذ، انتظر قليلاً ...",
  "💡 استنى شوي، الذكاء الصناعي بيرتب الرد ..."
];

// رسائل خطأ متغيرة
const errorMessages = [
  "⚠️ حصلت مشكلة في الرد... جرب تاني!",
  "😅 المعالجة ماكملتش، حاول مرة أخرى.",
  "❌ فيه خطأ بسيط حصل، عيد المحاولة.",
  "🤖 السيرفر ما استجاب، جرّب كمان مرة.",
  "🚨 واجهنا مشكلة غير متوقعة، حاول لاحقًا."
];

function getRandomWait() {
  return waitMessages[Math.floor(Math.random() * waitMessages.length)];
}

function getRandomError() {
  return errorMessages[Math.floor(Math.random() * errorMessages.length)];
}

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply(
      "- 「🚀」 *أدخل نصًا بعد الامر لاستخدام الرد بالذكاء الاصطناعي* *مثال* :\n ⟣ *.مريم* افضل انمي حتی الان ⟣ \n*.مريم* اكتب رمز JS",
    );
  }

  // رسالة انتظار عشوائية
  await m.reply(getRandomWait());

  try {
    let result = await jebtiAI(m.sender, text);

    if (!result) {
      console.error("⚠️ API رجع رد فاضي!");
      return m.reply(getRandomError());
    }

    await m.reply(result);
  } catch (e) {
    console.error("❌ خطأ في المعالجة:", e);
    await m.reply(getRandomError());
  }
};

handler.help = ["مريم"];
handler.tags = ["ai"];
handler.command = /^(مريم)$/i;
export default handler;

// ========== نظام الذاكرة ==========
const conversations = new Map();
const MEMORY_FILE = './mariam_memory.json';

function loadMemory() {
    try {
        if (fs.existsSync(MEMORY_FILE)) {
            const data = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'));
            for (const [k, v] of Object.entries(data)) conversations.set(k, v);
            console.log(`✅ تم تحميل ذاكرة مريم: ${conversations.size} مستخدم`);
        }
    } catch (e) {}
}

function saveMemory() {
    try {
        fs.writeFileSync(MEMORY_FILE, JSON.stringify(Object.fromEntries(conversations), null, 2));
    } catch (e) {}
}

// ========== API جبتي ==========
async function jebtiAI(userId, prompt) {
    let history = conversations.get(userId) || [];
    
    history.push({ role: 'user', content: prompt });
    
    if (history.length > 10) {
        history = history.slice(-10);
    }
    
    const messages = [];
    for (let i = 0; i < history.length; i++) {
        const msg = history[i];
        messages.push({
            role: msg.role,
            content: [{ type: 'text', text: msg.content }]
        });
    }
    
    const headers = {
        'User-Agent': 'okhttp/4.9.2',
        'Accept': 'text/event-stream',
        'Content-Type': 'application/json',
        'cache-control': 'no-cache',
        'x-requested-with': 'XMLHttpRequest',
        'authorization': 'Bearer az-chatai-key',
        'x-app-version': '1.0.16',
        'x-user-id': `WA_${String(userId).substring(0, 20)}`,
        'x-platform-type': 'android',
        'x-language': 'ar',
    };
    
    const jsonData = {
        model: 'gpt-5.4-mini',
        stream: true,
        messages: messages,
        isSubscribed: false,
        web_search: false,
        reason: false,
        study_mode: false,
    };
    
    try {
        const response = await fetch('https://api.appzoneai.com/v1/chat/completions', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(jsonData)
        });
        
        const responseText = await response.text();
        
        let fullResponse = '';
        const lines = responseText.split('\n');
        
        for (const line of lines) {
            if (line.startsWith('data: ') && line !== 'data: [DONE]') {
                try {
                    const jsonStr = line.slice(6);
                    const parsed = JSON.parse(jsonStr);
                    const content = parsed?.choices?.[0]?.delta?.content;
                    if (content) {
                        fullResponse += content;
                    }
                } catch (e) {}
            }
        }
        
        if (!fullResponse) throw new Error('لا يوجد رد');
        
        history.push({ role: 'assistant', content: fullResponse });
        conversations.set(userId, history);
        saveMemory();
        
        return fullResponse;
    } catch (error) {
        console.error('API Error:', error.message);
        throw error;
    }
}

loadMemory();
