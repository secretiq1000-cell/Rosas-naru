// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios'
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

const NEXT_ACTION = "40016c43901dcc7fd55eca719fdb2c4944ab434fdb"
const BASE = "https://spotisoft.com"

let handler = async (m, { conn, text }) => {
  try {
    const url = text.trim()
    
    if (!url) {
      return conn.sendMessage(m.chat, {
        text: `🎵 *تحميل من سبوتيفاي* 🎵

━━━━━━━━━━━━━━━━━
📝 *الاستخدام:* 
.سبوتيفاي <رابط>

📋 *مثال:*
.سبوتيفاي https://open.spotify.com/track/...

🎧 *الجودة المدعومة:* 128

━━━━━━━━━━━━━━━━━
⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
      }, { quoted: m })
    }
    
    // التحقق من صحة الرابط
    if (!url.includes('spotify.com')) {
      return conn.sendMessage(m.chat, {
        text: `❌ *الرابط غير صحيح*\n📌 الرجاء إدخال رابط سبوتيفاي صحيح`
      }, { quoted: m })
    }
    
    await conn.sendMessage(m.chat, { 
      text: `🎵 *جاري جلب المعلومات...*\n⏳ يرجى الانتظار`
    }, { quoted: m })
    
    // جلب المعلومات
    const info = await getSpotifyInfo(url)
    
    if (!info.success) {
      throw new Error(info.message || 'فشل جلب المعلومات')
    }
    
    if (info.type === 'track') {
      // أغنية فردية
      const track = info.data
      
      await conn.sendMessage(m.chat, {
        text: `🎵 *${track.name}* 🎵

━━━━━━━━━━━━━━━━━
🎤 *الفنان:* ${track.artists?.join(', ') || 'غير معروف'}
💿 *الألبوم:* ${track.album || 'غير معروف'}
━━━━━━━━━━━━━━━━━

🔄 *جاري التحميل...*`
      }, { quoted: m })
      
      // تحميل الأغنية
      const audioBuffer = await downloadTrack(url, info.token, track.name, track.artists?.join(', '), track.image)
      
      // إرسال الصوت
      await conn.sendMessage(m.chat, {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        ptt: false,
        fileName: `${track.name} - ${track.artists?.join(', ')}.mp3`
      }, { quoted: m })
      
    } else if (info.type === 'album' || info.type === 'playlist') {
      // ألبوم أو قائمة تشغيل
      const playlist = info.data
      const tracks = playlist.tracks || []
      
      let trackList = `📀 *${playlist.name}* 📀\n━━━━━━━━━━━━━━━━━\n\n`
      tracks.forEach((t, i) => {
        trackList += `${i + 1}. ${t.name} - ${t.artists?.join(', ')}\n`
      })
      trackList += `\n━━━━━━━━━━━━━━━━━\n📊 *عدد المقاطع:* ${tracks.length}`
      
      await conn.sendMessage(m.chat, {
        text: trackList
      }, { quoted: m })
      
      // تحميل أول أغنية فقط (لأن البوت لا يستطيع إرسال متعدد بسهولة)
      if (tracks.length > 0) {
        const firstTrack = tracks[0]
        await conn.sendMessage(m.chat, {
          text: `🎵 *جاري تحميل أول أغنية:* ${firstTrack.name}`
        }, { quoted: m })
        
        const trackInfo = await getSpotifyInfo(firstTrack.url)
        const audioBuffer = await downloadTrack(firstTrack.url, trackInfo.token, firstTrack.name, firstTrack.artists?.join(', '), firstTrack.image)
        
        await conn.sendMessage(m.chat, {
          audio: audioBuffer,
          mimetype: 'audio/mpeg',
          ptt: false,
          fileName: `${firstTrack.name} - ${firstTrack.artists?.join(', ')}.mp3`
        }, { quoted: m })
      }
    }
    
  } catch (err) {
    console.error('❌ خطأ:', err.message)
    await conn.sendMessage(m.chat, {
      text: `❌ *حدث خطأ أثناء تحميل الأغنية*\n\n📛 ${err.message}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m })
  }
}

// دالة جلب المعلومات من سبوتيفاي
async function getSpotifyInfo(url) {
  const response = await axios.post(BASE + "/", {
    headers: {
      "next-action": NEXT_ACTION,
      "content-type": "text/plain;charset=UTF-8",
      "accept": "text/x-component",
      "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
      "origin": BASE,
      "referer": BASE + "/",
    },
    data: JSON.stringify([url])
  })
  
  const lines = response.data.split('\n')
  for (const line of lines) {
    if (line.trim().startsWith('1:')) {
      return JSON.parse(line.substring(2))
    }
  }
  throw new Error('استجابة غير متوقعة')
}

// دالة تحميل الأغنية
async function downloadTrack(url, token, title, artist, image) {
  const response = await axios.post(BASE + "/api/proxy/download", {
    url: url,
    token: token,
    q: "128",
    branding: "SpotiSoft",
    title: title || "",
    artist: artist || "",
    imageUrl: image || "",
  }, {
    responseType: 'arraybuffer',
    timeout: 120000
  })
  
  const contentType = response.headers['content-type'] || ''
  if (!contentType.includes('audio') && !contentType.includes('octet')) {
    throw new Error(`نوع خاطئ: ${contentType}`)
  }
  
  return Buffer.from(response.data)
}

handler.command = ['سبوتيفاي', 'spoitfy', 'download']
handler.help = ['سبوتيفاي']
handler.category = 'tools'
handler.description = '🎵 تحميل أغاني من سبوتيفاي'

export default handler