// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

const questions = [
  "😈 عمرك حبيت بنت؟",
  "💔 كم مرة حسيت بوحدة قاتلة؟",
  "😶‍🌫️ هل بكيت بدون سبب واضح؟",
  "😵‍💫 كم مرة حسيت الدنيا ضدك؟",
  "👻 هل تخاف من الوحدة؟",
  "🥀 هل كذبت على شخص تحبه؟",
  "💤 هل تمنيت الموت يومًا؟",
  "💀 ما أصعب لحظة مرت عليك؟",
  "🌚 هل ما زلت تفكر في شخص غادر حياتك؟",
  "😢 هل تشتاق لشيء مستحيل يعود؟",
  "😶‍🌫️ كم مرة اكتأبت؟",
  "🔥 هل ندمت على حب؟",
  "🖤 هل جرحت شخص يحبك؟",
  "🔪 هل فكرت في الانتقام من أحد؟",
  "😐 هل تثق بأحد حالياً؟",
  "😞 كم مرة قلت 'أنا بخير' وأنت لست كذلك؟",
  "🤐 هل تخفي ألمك عن الجميع؟",
  "👁️‍🗨️ هل تتمنى أن تختفي أحياناً؟",
  "💔 هل عشت حب من طرف واحد؟",
  "🥶 هل تمنيت لو أنك لم تقابل أحدًا ما؟"
]

let handler = async (m, { conn }) => {
  const question = questions[Math.floor(Math.random() * questions.length)]

  // تحديد الشخص المستهدف
  let target = m.sender
  if (m.mentionedJid && m.mentionedJid.length > 0) {
    target = m.mentionedJid[0]
  } else if (m.quoted) {
    target = m.quoted.sender
  }
  
  const targetName = target.split('@')[0]

  const caption = `╭━━⊰ *السؤال هو* ⊱━━╮
│
│ ${question}
│
╰━━⊰ @${targetName} جاوب بصراحة 😈 ⊱━━╯

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

  await conn.sendMessage(m.chat, {
    text: caption,
    mentions: [target]
  }, { quoted: m })
}

handler.command = ['جاوب']
handler.help = ['جاوب']
handler.category = 'تفاعلي'
handler.description = '❓ يطرح عليك سؤالاً شخصيًا عشوائيًا'

export default handler
