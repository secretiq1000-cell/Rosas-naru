var handler = async (m, {conn, groupMetadata }) => {

conn.reply(m.chat, `${await groupMetadata.id}`,   )

}
handler.help = ['𝑀𝛩𝛩𝐷𝐸']
handler.tags = ['𝑀𝛩𝛩𝐷𝐸']
handler.command = /^(ايدي-جروب)$/i

handler.group = true
handler.owner = true
export default handler