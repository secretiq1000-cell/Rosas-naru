import yts from "yt-search"

let ytmp3mobi = async (youtubeUrl, format = "mp4") => {
    // ✅ استخراج videoId من جميع روابط يوتيوب
    const regYoutubeId = /(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
    const match = youtubeUrl.match(regYoutubeId)
    const videoId = match ? match[1] : null

    if (!videoId) throw Error("❌ لم أتمكن من استخراج معرف الفيديو من الرابط، تأكد أنه رابط يوتيوب صالح.")

    const urlParam = { v: videoId, f: format, _: Math.random() }
    const headers = { "Referer": "https://id.ytmp3.mobi/" }

    const fetchJson = async (url, fetchDescription) => {
        const res = await fetch(url, { headers })
        if (!res.ok) throw Error(`❌ فشل في ${fetchDescription} | ${res.status} ${res.statusText}`)
        return await res.json()
    }

    const { convertURL } = await fetchJson("https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=" + Math.random(), "الحصول على رابط التحويل")
    const { progressURL, downloadURL } = await fetchJson(`${convertURL}&${new URLSearchParams(urlParam).toString()}`, "الحصول على رابط التقدم")

    let { error, progress, title } = {}
    while (progress != 3) {
        ({ error, progress, title } = await fetchJson(progressURL, "جلب حالة التحويل"))
        if (error) throw Error(`❌ خطأ أثناء التحويل: ${error}`)
    }

    return { title, downloadURL }
}

let handler = async (m, { conn, args, command }) => {
    try {
        if (!args[0]) {
            return m.reply(`🎥 طريقة الاستخدام:
.${command} رابط_يوتيوب أو عنوان_الفيديو

📌 مثال:
.${command} https://youtu.be/MN_JP4gyBNI
.${command} اغنية يمني`)
        }

        let query = args.join(" ")
        let videoUrl
        let videoTitle = ""

        // ✅ التحقق إذا كان الرابط مباشراً
        const youtubeRegex = /(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
        const match = query.match(youtubeRegex)

        if (match) {
            // إذا كان الرابط مباشر
            videoUrl = query
            videoTitle = "جاري جلب المعلومات..."
            m.reply("⏳ جاري تجهيز الفيديو (جودة 360p)، انتظر قليلاً...")
        } else {
            // 🔍 البحث باستخدام yts (يعمل 100%)
            m.reply("🔍 جاري البحث عن الفيديو...")
            const searchResults = await yts(query)
            
            if (!searchResults || !searchResults.videos.length) {
                return m.reply("❌ لم أجد أي نتائج للبحث المطلوب.")
            }
            
            const firstVideo = searchResults.videos[0]
            videoUrl = firstVideo.url
            videoTitle = firstVideo.title
            m.reply(`✅ تم العثور على: *${videoTitle}*\n⏳ جاري التحميل...`)
        }

        // تحميل الفيديو
        const { title, downloadURL } = await ytmp3mobi(videoUrl, "mp4")
        
        // ✅ إرسال الفيديو
        await conn.sendMessage(m.chat, {
            video: { url: downloadURL },
            mimetype: "video/mp4",
            caption: `🎥 *${title || videoTitle}*\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀`
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        m.reply(`❌ خطأ: ${e.message}`)
    }
}

// ✅ الأمر فقط "2فيديو"
handler.help = ['فيديو2']
handler.command = ['فيديو2']
handler.tags = ['downloader']

export default handler
