let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i

let handler = async (m, { conn, text, isPrems, isMods, isOwner }) => {
  try {
    // استخراج الرابط من الرد أو النص
    let link = (m.quoted ? m.quoted.text : text) || text
    let [_, code] = link.match(linkRegex) || []

    if (!code) return m.reply(`
╭━━━ ⚠️ ━━━╮
❌ الرابط غير صحيح أو غير موجود!
📌 ضع رابط الجروب بشكل صحيح
✦ مثال:
*.انضم https://chat.whatsapp.com/××××××××*
╰━━━ ⚠️ ━━━╯
    `)

    // إذا المستخدم لديه صلاحية مباشرة
    if (isPrems || isMods || isOwner || m.fromMe) {
      try {
        let res = await conn.groupAcceptInvite(code)
        m.reply(`
╭━━━ ✅ ━━━╮
🎉 تم انضمام البوت بنجاح!
👑 البوت: بــوت دانــى
⚡ استمتعوا بالبوت واحترموه
╰━━━ ✅ ━━━╯
        `)
      } catch (err) {
        console.error(err)
        m.reply(`
❌ فشل الانضمام للجروب!
🔹 السبب المحتمل:
- الرابط منتهي الصلاحية
- البوت تم طرده مسبقًا
- تجاوز البوت الحد الأقصى من المجموعات
⏳ تحقق من الرابط وحاول مرة أخرى
        `)
      }

    } else {
      // إرسال طلب للمطور
      const owners = global.owner.filter(([id]) => id)
      for (let jid of owners.map(([id]) => id + '@s.whatsapp.net').filter(v => v != conn.user.jid)) {
        await conn.sendMessage(jid, {
          text: `
╭━━━ 📌 ━━━╮
⚡ طلب إضافة بوت جديد
👤 مقدم الطلب: wa.me/${m.sender.split('@')[0]}
🌐 رابط المجموعة: ${link}
👑 البوت: بــوت دانــى
╰━━━ 📌 ━━━╯`
        })
      }

      m.reply(`
╭━━━ 🕓 ━━━╮
⚡ تم إرسال طلب مجموعتك إلى المطور
⏳ سيتم تقييمه وسيقرر المالك إضافة البوت أم لا
❗ أسباب رفض الطلب المحتملة:
1️⃣ البوت مشبع بعدد مجموعات كبير
2️⃣ تم طرد البوت مسبقًا
3️⃣ الرابط تم تغييره
4️⃣ القرار النهائي بيد المطور
⏳ قد يستغرق الرد ساعات أو أيام، تحلى بالصبر
╰━━━ 🕓 ━━━╯
      `)
    }

  } catch (e) {
    console.error(e)
    m.reply(`
❌ حدث خطأ غير متوقع أثناء محاولة الانضمام
🔹 تأكد من الرابط وصلاحيات البوت
⏳ حاول مرة أخرى لاحقًا
    `)
  }
}

handler.help = ['انضم [رابط الجروب]']
handler.tags = ['premium']
handler.command = /^join|انضم$/i

export default handler