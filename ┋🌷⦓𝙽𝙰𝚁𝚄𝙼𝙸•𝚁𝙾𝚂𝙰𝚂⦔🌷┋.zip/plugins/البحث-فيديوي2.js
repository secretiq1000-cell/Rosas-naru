
import yts from 'yt-search'
import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    
    if (!text) return conn.reply(m.chat, `🎬 *نظام تحميل الفيديو - جودة 1080p ثابتة*\n\nاكتب رابط الفيديو أو عنوانه\nمثال: .فيديوي2 محمد منير\nاو: .فيديوي2 https://youtu.be/...`, m)

    await m.react('👁️') 

    try {
        let videoUrl = text
        let videoTitle = ""

        const isUrl = text.match(/(youtube\.com|youtu\.be)/i)
        
        if (!isUrl) {
            await m.reply('🔍 جاري البحث عن الفيديو...')
            
            let search = await yts(text)
            let videos = search.videos
            
            if (!videos || videos.length === 0) {
                await m.react('🚫')
                return m.reply('❌ لم يتم العثور على فيديو\nحاول بكلمات بحث مختلفة.')
            }
            
            let firstVideo = videos[0]
            videoUrl = firstVideo.url
            videoTitle = firstVideo.title
        }

        const b = (s) => Buffer.from(s, 'base64').toString('utf-8')
        const base = b("aHR0cHM6Ly9hcGkuZXZvZ2Iub3Jn")
        const key = b("c2FzdWtl")

        // جودة ثابتة 1080p فقط
        let quality = '1080p'
        let vid = null
        
        try {
            let res = await fetch(`${base}/dl/ytmp4?url=${encodeURIComponent(videoUrl)}&key=${key}&quality=${quality}&format=mp4&vcodec=h264`)
            let json = await res.json()
            
            if (json.status && json.data && json.data.dl) {
                vid = json.data
                vid.quality = quality
            }
        } catch (e) {
            console.log('1080p غير متاحة:', e)
        }

        // إذا لم تكن 1080p متاحة، جرب 720p
        if (!vid || !vid.dl) {
            await m.reply('⚠️ جودة 1080p غير متاحة لهذا الفيديو، جاري التحميل بجودة 720p...')
            
            try {
                let res = await fetch(`${base}/dl/ytmp4?url=${encodeURIComponent(videoUrl)}&key=${key}&quality=720p&format=mp4&vcodec=h264`)
                let json = await res.json()
                
                if (json.status && json.data && json.data.dl) {
                    vid = json.data
                    vid.quality = '720p'
                }
            } catch (e) {
                console.log('720p غير متاحة:', e)
            }
        }

        if (!vid || !vid.dl) {
            await m.react('🚫')
            return m.reply('❌ فشل التحميل\nلا توجد جودة 1080p أو 720p متاحة لهذا الفيديو.')
        }

        let finalTitle = videoTitle || vid.title

        let txt = `📥 *تحميل الفيديو*\n\n`
        txt += `📹 *الاسم:* ${finalTitle}\n`
        txt += `🎥 *الجودة:* ${vid.quality}\n`
        txt += `📦 *النوع:* ${vid.type || 'video'}\n`
        txt += `💾 *الصيغة:* .${vid.format || 'mp4'}\n\n`
        
        if (vid.quality !== '1080p') {
            txt += `⚠️ *ملاحظة:* الفيديو الأصلي لا يدعم 1080p، تم التحميل بأفضل جودة متاحة (${vid.quality})`
        } else {
            txt += `✅ *تم التحميل بجودة 1080p كامل*`
        }

        await conn.sendMessage(m.chat, { 
            video: { url: vid.dl }, 
            caption: txt,
            mimetype: 'video/mp4',
            fileName: `${finalTitle.replace(/[^\w\s]/gi, '')}.mp4`
        }, { quoted: m })

        await m.react('✅') 

    } catch (e) {
        await m.react('❌')
        console.error(e)
        m.reply('❌ حدث خطأ\nتأكد من اتصال الإنترنت وحاول مرة أخرى.\n' + e.message)
    }
}

handler.help = ['فيديوي2', 'ytmp4', 'ytv', 'video']
handler.tags = ['downloader']
handler.command = ['فيديوي2', 'ytmp4', 'ytv', 'video']
handler.register = true

export default handler
