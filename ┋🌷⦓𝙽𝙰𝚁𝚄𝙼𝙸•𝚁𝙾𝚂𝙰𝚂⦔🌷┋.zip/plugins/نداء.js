import fs from 'fs'
import { join } from 'path'
import { fileURLToPath } from 'url'
import { dirname } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))

let handler = async (m, { conn, isAdmin, isOwner }) => {
  try {
    // ════ التحقق من صلاحية الأدمن ════
    if (!isAdmin && !isOwner) {
      await conn.sendMessage(m.chat, {
        text: '❌ *Access Denied*\n\n⛔ هذا الأمر مخصص للأدمن فقط.\n👑 فقط قادة الظلام يمكنهم استدعاء الموتى.'
      }, { quoted: m })
      return
    }

    // ════ نظام الرياكشن ════
    const zarfPath = join(process.cwd(), 'zarf.json')
    let zarfData = { reaction_status: "on", reaction: "🩸" }

    if (fs.existsSync(zarfPath)) {
      zarfData = JSON.parse(fs.readFileSync(zarfPath))
    }

    if (zarfData.reaction_status === "on" && zarfData.reaction) {
      await conn.sendMessage(m.chat, {
        react: { text: zarfData.reaction, key: m.key }
      }).catch(() => {})
    }

    // ════ جلب أعضاء الجروب ════
    const metadata = await conn.groupMetadata(m.chat)
    const participants = metadata.participants.map(p => p.id)

    // ════ رسالة دانـــي الـشبح ════
    const TanganText = `
╔══════════════════════════════╗
👑 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 🩸
☠️ نداء الموتى
╚══════════════════════════════╝

🩸 عدد الأرواح المستدعاة:
➤ *${participants.length}*

☠️ « انهضوا أيها الموتى...
فقد نطق دانـــي الـشـبح ،
ولا يُرَدّ أمره »

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

    await conn.sendMessage(
      m.chat,
      {
        text: TanganText,
        mentions: participants
      },
      { quoted: m }
    )

  } catch (err) {
    console.error('❌ خطأ في أمر اموات:', err)
    await conn.sendMessage(
      m.chat,
      { text: '☠️ فشل نداء الموتى…' },
      { quoted: m }
    )
  }
}

handler.command = ['نداء']
handler.help = ['نداء']
handler.category = 'hidden'
handler.description = '☠️ نداء داني السري لاستدعاء الجميع (للأدمن فقط)'
handler.group = true

export default handler
