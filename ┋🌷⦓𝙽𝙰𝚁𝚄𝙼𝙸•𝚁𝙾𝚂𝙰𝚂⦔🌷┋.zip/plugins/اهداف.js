// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

const dir = [
  'https://telegra.ph/file/5fb7c13a4d93917f97ff3.mp4',
  'https://telegra.ph/file/2a4e007bec39cc66385b0.mp4',
  'https://telegra.ph/file/a22d5d23a85c4d7b2cdac.mp4',
  'https://telegra.ph/file/148dcadb72c631e0a9d1c.mp4',
  'https://telegra.ph/file/6699964c4f9486bafac22.mp4',
  'https://telegra.ph/file/aec768d540e249ceb0c5b.mp4',
  'https://telegra.ph/file/b2f92a40a7b869896d360.mp4',
  'https://telegra.ph/file/cd611bb1e76ceac182de8.mp4',
  'https://telegra.ph/file/0c4046c6477431bbed40d.mp4',
  'https://telegra.ph/file/d84e53e96fb44ec4cbd23.mp4',
  'https://telegra.ph/file/1286e1bf83c9901308cd8.mp4'
];

let handler = async (m, { conn }) => {
  const file = dir[Math.floor(Math.random() * dir.length)];
  
  // تحديد الشخص المستهدف (منشن أو مقتبس)
  let target = m.sender
  if (m.mentionedJid && m.mentionedJid.length > 0) {
    target = m.mentionedJid[0]
  } else if (m.quoted) {
    target = m.quoted.sender
  }
  
  const targetName = target.split('@')[0]

  await conn.sendMessage(m.chat, {
    video: { url: file },
    caption: `⚽ *اهداف رائعة* ⚽

🎬 *لـ* @${targetName}

⚠️ *تنبيه:* الفيديو يحتوي على موسيقى

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
    mentions: [target]
  }, { quoted: m });
}

handler.command = ['اهداف']
handler.help = ['اهداف']
handler.category = 'edit'
handler.description = '⚽ ارسال فيديو اهداف عشوائي'
handler.group = true

export default handler
