import fetch from "node-fetch";
import fs from 'fs';

// رسائل انتظار متنوعة
const waitMessages = [
  "🧠 *ديبـسيڪ*: ثواني واجاوبك...",
  "⚡ *ديبـسيڪ*: بشتغل على سؤالك دلوقتي",
  "💭 *ديبـسيڪ*: بفكر في إجابتك... استنى شوية",
  "🔥 *ديبـسيڪ*: جاري تحليل الطلب...",
  "🎯 *ديبـسيڪ*: هارد عليك خلال لحظات"
];

function getRandomWait() {
  return waitMessages[Math.floor(Math.random() * waitMessages.length)];
}

let handler = async (m, { text, command }) => {
  if (!text)
    return m.reply(
      `🎯 *ديبـسيڪ*: معك بوت يعمل ب الذكاء الاصطناعي كيف اخدمك\n\n📌 *مثال:*\n${command} ما هو الذكاء الاصطناعي؟`
    );

  const waitMsg = await m.reply(getRandomWait());

  try {
    let result = await jebtiAI(m.sender, text);
    
    // تقسيم الرد الطويل إلى أجزاء
    if (result.length > 2000) {
      const parts = result.match(/(.|[\r\n]){1,2000}/g);
      for (let i = 0; i < parts.length; i++) {
        await m.reply(
          `💬 *ديبـسيڪ* [${i+1}/${parts.length}]:\n\n${parts[i]}\n\n━━━━━━━━━━━━━━━━━━\n> ✨ _صنع بحب بواسطة بـوتك_`
        );
      }
    } else {
      await m.reply(
        `╔══════════════════╗\n💬 *رد ديبـسيڪ:*\n╚══════════════════╝\n\n${result}\n\n━━━━━━━━━━━━━━━━━━\n> 🚀 _تم الرد بواسطة ديبـسيڪ الذكي_`
      );
    }
    
    // حذف رسالة الانتظار بعد الرد
    await m.reply("✅ *تم الرد بنجاح*", waitMsg.key);
    
  } catch (err) {
    console.error(err);
  }
};

handler.help = ["ديب"];
handler.tags = ["ai"];
handler.command = /^(ديب|ديبسيك|deepseek|deep)$/i;

export default handler;

// ========== نظام الذاكرة المحسن ==========
const conversations = new Map();
const MEMORY_FILE = './deepseek_memory.json';

function loadMemory() {
    try {
        if (fs.existsSync(MEMORY_FILE)) {
            const data = JSON.parse(fs.readFileSync(MEMORY_FILE, 'utf-8'));
            for (const [k, v] of Object.entries(data)) conversations.set(k, v);
            console.log(`✅ تم تحميل ذاكرة ديبـسيڪ: ${conversations.size} مستخدم`);
        }
    } catch (e) {
        console.log('📁 سيتم إنشاء ملف ذاكرة جديد');
    }
}

function saveMemory() {
    try {
        fs.writeFileSync(MEMORY_FILE, JSON.stringify(Object.fromEntries(conversations), null, 2));
    } catch (e) {
        console.error('خطأ في حفظ الذاكرة:', e);
    }
}

// ========== API جبتي المحسن ==========
async function jebtiAI(userId, prompt) {
    let history = conversations.get(userId) || [];
    
    // تحسين الـ prompt ليكون أكثر احترافية
    const enhancedPrompt = `أنت DeepSeek، مساعد ذكي محترف. تحدث بلغة عربية فصحى مفهومة، كن دقيقًا ومفيدًا في إجاباتك. قدم معلومات قيمة ومرتبة. السؤال: ${prompt}`;
    
    history.push({ role: 'user', content: enhancedPrompt });
    
    // الاحتفاظ بآخر 15 رسالة (زيادة الذاكرة)
    if (history.length > 15) {
        history = history.slice(-15);
    }
    
    const messages = [];
    for (let i = 0; i < history.length; i++) {
        const msg = history[i];
        messages.push({
            role: msg.role,
            content: [{ type: 'text', text: msg.content }]
        });
    }
    
    const headers = {
        'User-Agent': 'okhttp/4.9.2',
        'Accept': 'text/event-stream',
        'Content-Type': 'application/json',
        'cache-control': 'no-cache',
        'x-requested-with': 'XMLHttpRequest',
        'authorization': 'Bearer az-chatai-key',
        'x-app-version': '1.0.16',
        'x-user-id': `WA_${String(userId).substring(0, 20)}`,
        'x-platform-type': 'android',
        'x-language': 'ar',
    };
    
    const jsonData = {
        model: 'gpt-5.4-mini',
        stream: true,
        messages: messages,
        isSubscribed: false,
        web_search: false,
        reason: false,
        study_mode: false,
    };
    
    try {
        const response = await fetch('https://api.appzoneai.com/v1/chat/completions', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(jsonData)
        });
        
        const responseText = await response.text();
        
        let fullResponse = '';
        const lines = responseText.split('\n');
        
        for (const line of lines) {
            if (line.startsWith('data: ') && line !== 'data: [DONE]') {
                try {
                    const jsonStr = line.slice(6);
                    const parsed = JSON.parse(jsonStr);
                    const content = parsed?.choices?.[0]?.delta?.content;
                    if (content) {
                        fullResponse += content;
                    }
                } catch (e) {}
            }
        }
        
        if (!fullResponse) throw new Error('لا يوجد رد');
        
        // تنظيف الرد من أي إضافات غير مرغوب فيها
        fullResponse = fullResponse.trim();
        
        history.push({ role: 'assistant', content: fullResponse });
        conversations.set(userId, history);
        saveMemory();
        
        return fullResponse;
    } catch (error) {
        console.error('API Error:', error.message);
        throw error;
    }
}

loadMemory();
