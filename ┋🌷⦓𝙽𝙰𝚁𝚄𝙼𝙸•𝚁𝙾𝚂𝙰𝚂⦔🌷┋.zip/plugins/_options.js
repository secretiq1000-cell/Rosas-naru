const handler = async (m, { conn, usedPrefix, command, args, isOwner, isAdmin }) => {
  const primaryBot = global.db.data.chats[m.chat].primaryBot
  if (primaryBot && conn.user.jid !== primaryBot) throw !1
  
  const chat = global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}
  const action = command.toLowerCase()

  // إذا كتب الأمر فقط بدون إضافة
  if (args.length === 0) {
    let commandsList = `「✦」 *أوامر الإعدادات المتاحة*\n\n`

    commandsList += `👑 *أوامر المشرفين:*\n`
    commandsList += `❍╎🌸┊ antilink - منع مشاركة الروابط في المجموعة\n`
    commandsList += `❍╎🌸┊ welcome - إرسال رسائل ترحيب للأعضاء الجدد\n`
    commandsList += `❍╎🌸┊ detect - كشف التغييرات في المجموعة\n`
    commandsList += `❍╎🌸┊ modoadmin - تقييد الأوامر للمشرفين فقط\n`
    commandsList += `❍╎🌸┊ onlyadmin - تقييد الكتابة للمشرفين فقط\n`
    commandsList += `❍╎🌸┊ economy - تفعيل النظام الاقتصادي\n`
    commandsList += `❍╎🌸┊ rpg - تفعيل ألعاب الـ RPG\n`
    commandsList += `❍╎🌸┊ gacha - تفعيل ألعاب الـ Gacha\n`
    commandsList += `❍╎🌸┊ sbye - منع إشعارات ذكر المجموعة في الستوري\n\n`

    commandsList += `🔐 *أوامر المطورين:*\n`
    commandsList += `❍╎🌸┊ nsfw - تفعيل المحتوى الحساس (+18)\n\n`

    commandsList += `❍╎🌸┊ *طريقة الاستخدام:*\n`
    commandsList += `${usedPrefix}${command} [اسم الإعداد]\n\n`
    commandsList += `❍╎🌸┊ *أمثلة:*\n`
    commandsList += `${usedPrefix}${command} antilink\n`
    commandsList += `${usedPrefix}${command} onlyadmin\n`
    commandsList += `${usedPrefix}${command} welcome\n`
    commandsList += `${usedPrefix}${command} sbye\n\n`
    commandsList += `𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

    return conn.reply(m.chat, commandsList, m)
  }

  // الحصول على نوع الأمر من args[0]
  let type = args[0].toLowerCase()

  // التعرف على جميع أسماء الأوامر
  const commandMap = {
    'welcome': { key: 'welcome', name: 'الترحيب', desc: 'إرسال رسائل ترحيب عند دخول أعضاء جدد', role: 'admin' },
    'bienvenida': { key: 'welcome', name: 'الترحيب', desc: 'إرسال رسائل ترحيب عند دخول أعضاء جدد', role: 'admin' },
    'modoadmin': { key: 'modoadmin', name: 'وضع الأدمن', desc: 'تقييد استخدام الأوامر للمشرفين فقط', role: 'admin' },
    'onlyadmin': { key: 'onlyadmin', name: 'الكتابة للمشرفين فقط', desc: 'تقييد الكتابة في المجموعة للمشرفين فقط', role: 'admin' },
    'detect': { key: 'detect', name: 'نظام الكشف', desc: 'كشف التغييرات في إعدادات المجموعة', role: 'admin' },
    'alertas': { key: 'detect', name: 'نظام الكشف', desc: 'كشف التغييرات في إعدادات المجموعة', role: 'admin' },
    'antilink': { key: 'antiLink', name: 'منع الروابط', desc: 'حظر مشاركة أي روابط في المجموعة', role: 'admin' },
    'antienlace': { key: 'antiLink', name: 'منع الروابط', desc: 'حظر مشاركة أي روابط في المجموعة', role: 'admin' },
    'economy': { key: 'economy', name: 'نظام الاقتصاد', desc: 'تفعيل الألعاب والنظام الاقتصادي', role: 'admin' },
    'economia': { key: 'economy', name: 'نظام الاقتصاد', desc: 'تفعيل الألعاب والنظام الاقتصادي', role: 'admin' },
    'rpg': { key: 'gacha', name: 'نظام الألعاب', desc: 'تفعيل ألعاب الـ RPG والجائزة', role: 'admin' },
    'gacha': { key: 'gacha', name: 'نظام الألعاب', desc: 'تفعيل ألعاب الـ Gacha والجائزة', role: 'admin' },
    'sbye': { key: 'sBye', name: 'حماية الستوري', desc: 'منع إشعارات "تم ذكر هذه المجموعة" في الستوري', role: 'admin' },
    'ستوري': { key: 'sBye', name: 'حماية الستوري', desc: 'منع إشعارات ذكر المجموعة في الستوري', role: 'admin' },
    'story': { key: 'sBye', name: 'حماية الستوري', desc: 'منع إشعارات ذكر المجموعة في الستوري', role: 'admin' },
    'mention': { key: 'sBye', name: 'حماية الستوري', desc: 'منع إشعارات ذكر المجموعة في الستوري', role: 'admin' },
    'إشارة': { key: 'sBye', name: 'حماية الستوري', desc: 'منع إشعارات ذكر المجموعة في الستوري', role: 'admin' },
    'nsfw': { key: 'nsfw', name: 'المحتوى الممنوع', desc: 'تفعيل الأوامر ذات المحتوى الحساس', role: 'owner' },
    'modohorny': { key: 'nsfw', name: 'المحتوى الممنوع', desc: 'تفعيل الأوامر ذات المحتوى الحساس', role: 'owner' }
  }

  // البحث عن الأمر
  const commandInfo = commandMap[type]
  
  if (!commandInfo) {
    return conn.reply(m.chat, `❀ الأمر *${type}* غير معروف\n\nاستخدم *${usedPrefix}${command}* لرؤية الأوامر المتاحة`, m)
  }

  const { key, name, desc, role } = commandInfo
  const isEnabled = chat[key] !== undefined ? chat[key] : false

  // تحقق من الصلاحيات
  if (m.isGroup && role === 'admin' && !(isAdmin || isOwner)) {
    global.dfail('admin', m, conn)
    return
  }
  
  if (m.isGroup && role === 'owner' && !isOwner) {
    global.dfail('owner', m, conn)
    return
  }

  // تحديد الإجراء
  let isEnableNew = false

  if (action === 'تفعيل' || action === 'on') {
    if (isEnabled) {
      return conn.reply(m.chat, `❀ *${name}*\n\n${desc}\n\n${role === 'owner' ? '❍╎🔒┊ صلاحية: المطور فقط' : '❍╎🌹┊ صلاحية: المشرفين'}\n❍╎🌸┊مـفـعـل مـسـبـقـاً ✅`, m)
    }
    isEnableNew = true
  } else if (action === 'تعطيل' || action === 'off') {
    if (!isEnabled) {
      return conn.reply(m.chat, `❀ *${name}*\n\n${desc}\n\n${role === 'owner' ? '❍╎🔒┊ صلاحية: المطور فقط' : '❍╎🌹┊ صلاحية: المشرفين'}\n❍╎🌸┊مـعـطـل مـسـبـقـا`, m)
    }
    isEnableNew = false
  }

  // تحديث الإعداد
  chat[key] = isEnableNew

  // إذا كان الأمر خاص بـ onlyadmin، قم بتفعيل/تعطيل القيود في المجموعة
  if (key === 'onlyadmin') {
    if (isEnableNew) {
      // تفعيل وضع المشرفين فقط
      await conn.groupSettingUpdate(m.chat, 'announcement').catch(console.error)
    } else {
      // تعطيل وضع المشرفين فقط
      await conn.groupSettingUpdate(m.chat, 'not_announcement').catch(console.error)
    }
  }

  // رسالة خاصة لـ sBye
  let extraMessage = ''
  if (key === 'sBye') {
    extraMessage = isEnableNew 
      ? '\n\n📢 *ملاحظة:* سيتم كشف وإزالة أي إشعارات تحتوي على "تم ذكر هذه المجموعة" تلقائياً'
      : '\n\n📢 *ملاحظة:* سيتم تعطيل حماية الستوري وستسمح بإشعارات ذكر المجموعة'
  }

  conn.reply(m.chat, `❀ *${name}*\n\n${desc}\n\n${role === 'owner' ? '🔐 صلاحية: المطور فقط' : '👑 صلاحية: المشرفين'}\nالحالة: ${isEnableNew ? 'تم التفعيل ✅' : 'تم التعطيل ❌'}${extraMessage}\n\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`, m)
}

handler.help = ['تفعيل', 'تعطيل', 'on', 'off']
handler.tags = ['nable']
handler.command = ['تفعيل', 'تعطيل', 'on', 'off']
handler.group = true

export default handler
