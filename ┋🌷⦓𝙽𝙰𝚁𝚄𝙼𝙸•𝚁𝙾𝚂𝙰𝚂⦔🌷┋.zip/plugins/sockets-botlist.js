import ws from "ws"

const handler = async (m, { conn, command, usedPrefix, participants }) => {
try {
const users = [global.conn.user.jid, ...new Set(global.conns.filter((conn) => conn.user && conn.ws.socket && conn.ws.socket.readyState !== ws.CLOSED).map((conn) => conn.user.jid))]

// ╭•─•─•─•╮
// │ 🕒 دالة حساب مدة التشغيل │
// ╰•─•─•─•╯
function convertirMsADiasHorasMinutosSegundos(ms) {
const segundos = Math.floor(ms / 1000)
const minutos = Math.floor(segundos / 60)
const horas = Math.floor(minutos / 60)
const días = Math.floor(horas / 24)
const segRest = segundos % 60
const minRest = minutos % 60
const horasRest = horas % 24
let resultado = ""
if (días) resultado += `${días} يوم, `
if (horasRest) resultado += `${horasRest} ساعة, `
if (minRest) resultado += `${minRest} دقيقة, `
if (segRest) resultado += `${segRest} ثانية`
return resultado.trim()
}

// ╭•─•─•─•╮
// │ 🤖 تحديد البوتات الموجودة في القروب │
// ╰•─•─•─•╯
let groupBots = users.filter((bot) => participants.some((p) => p.id === bot))
if (participants.some((p) => p.id === global.conn.user.jid) && !groupBots.includes(global.conn.user.jid)) { groupBots.push(global.conn.user.jid) }

// ╭•─•─•─•╮
// │ 📋 إنشاء قائمة البوتات │
// ╰•─•─•─•╯
const botsGroup = groupBots.length > 0 ? groupBots.map((bot) => {
const isMainBot = bot === global.conn.user.jid
const v = global.conns.find((conn) => conn.user.jid === bot)
const uptime = isMainBot ? convertirMsADiasHorasMinutosSegundos(Date.now() - global.conn.uptime) : v?.uptime ? convertirMsADiasHorasMinutosSegundos(Date.now() - v.uptime) : "نشط الآن"
const mention = bot.replace(/[^0-9]/g, '')
return `@${mention}\n> نوع البوت: ${isMainBot ? 'الرئيسي' : 'الفرعي'}\n> مدة التشغيل: ${uptime}`}).join("\n\n") : `✧ لا يوجد أي بوتات نشطة في هذه المجموعة`

// ╭•─•─•─•╮
// │ 💬 رسالة العرض │
// ╰•─•─•─•╯
const message = `*「 🌷 」 قائمة البوتات النشطة*

❀ البوت الرئيسي: *1*
✿ البوتات الفرعية: *${users.length - 1}*

❏ داخل هذه المجموعة: *${groupBots.length}* بوت
${botsGroup}`

const mentionList = groupBots.map(bot => bot.endsWith("@s.whatsapp.net") ? bot : `${bot}@s.whatsapp.net`)
rcanal.contextInfo.mentionedJid = mentionList
await conn.sendMessage(m.chat, { text: message, ...rcanal }, { quoted: m })

} catch (error) {
// ╭•─•─•─•╮
// │ ⚠️ في حال حدوث خطأ │
// ╰•─•─•─•╯
m.reply(`⚠︎ حدث خطأ أثناء التنفيذ.\n> استخدم *${usedPrefix}بلاغ* للإبلاغ عنه.\n\n${error.message}`)
}}

handler.tags = ["البوتات"]
handler.help = ["قائمة_البوتات"]
handler.command = ["قائمة_البوتات", "عرض_البوتات", "البوتات", "bots", "بوتات"]

export default handler
