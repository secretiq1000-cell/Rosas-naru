// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from "axios"

let handler = async (m, { conn }) => {
  // جلب النص من الرسالة بشكل صحيح
  let text = m.text || ''
  
  // إزالة الأمر من النص (مثال: .الطقس القاهرة → القاهرة)
  let city = text.replace(/^[.,،!?]?(الطقس|طقس|weather)\s*/i, '').trim()
  
  if (!city) {
    return await conn.sendMessage(m.chat, {
      text: '🌍 من فضلك حدد اسم المدينة.\n\nمثال: .الطقس القاهرة'
    }, { quoted: m })
  }

  const apiKey = '4902c0f2550f58298ad4146a92b65e10'
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${apiKey}&units=metric&lang=ar`

  try {
    const response = await axios.get(url)
    const data = response.data

    const weatherText = `🌦️ *الطقس في ${data.name}*\n\n` +
      `🌡️ الحرارة: *${data.main.temp}°C*\n` +
      `🤒 الإحساس الحقيقي: *${data.main.feels_like}°C*\n` +
      `💧 الرطوبة: *${data.main.humidity}%*\n` +
      `🌬️ سرعة الرياح: *${data.wind.speed} م/ث*\n` +
      `☁️ الحالة: *${data.weather[0].description}*\n\n` +
      `⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

    await conn.sendMessage(m.chat, {
      text: weatherText
    }, { quoted: m })

  } catch (error) {
    console.error("❌ خطأ في الطقس:", error.message)
    let errorMsg = "⚠️ حصل خطأ أثناء جلب الطقس.\n"
    if (error.response?.status === 404) {
      errorMsg += `❌ مدينة "${city}" غير موجودة. تأكد من اسم المدينة.`
    } else {
      errorMsg += "تأكد من اسم المدينة وحاول مرة أخرى."
    }
    await conn.sendMessage(m.chat, {
      text: errorMsg
    }, { quoted: m })
  }
}

handler.command = ['الطقس', 'طقس', 'weather']
handler.help = ['الطقس']
handler.category = 'tools'
handler.description = '🌦️ يعرض حالة الطقس في مدينة محددة'

export default handler
