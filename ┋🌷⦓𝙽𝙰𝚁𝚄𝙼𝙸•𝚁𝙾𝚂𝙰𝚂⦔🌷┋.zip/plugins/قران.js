// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import axios from 'axios'

// قائمة القراء
const reciters = [
  { id: 1, name: 'عبد الباسط عبد الصمد', code: '128' },
  { id: 2, name: 'محمد صديق المنشاوي', code: '129' },
  { id: 3, name: 'محمود خليل الحصري', code: '130' },
  { id: 4, name: 'مصطفى إسماعيل', code: '131' },
  { id: 5, name: 'علي الحذيفي', code: '132' },
  { id: 6, name: 'محمد أيوب', code: '133' },
  { id: 7, name: 'عبد الرحمن السديس', code: '134' },
  { id: 8, name: 'سعود الشريم', code: '135' },
  { id: 9, name: 'مشاري العفاسي', code: '136' },
  { id: 10, name: 'ناصر القطامي', code: '137' }
]

// أسماء السور
const surahNames = [
  "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
  "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
  "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
  "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
  "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
  "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
  "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
  "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
  "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
  "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
  "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
  "المسد", "الإخلاص", "الفلق", "الناس"
]

let handler = async (m, { conn, text }) => {
  try {
    let args = text.trim().split(/\s+/)
    let subCommand = args[0]?.toLowerCase()
    
    // أمر عرض القراء
    if (subCommand === 'قراء' || subCommand === 'reciters') {
      let list = `🎙️ *قائمة القراء* 🎙️\n\n`
      reciters.forEach((r, i) => {
        list += `${r.id}️⃣ *${r.name}*\n`
      })
      list += `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
      return conn.sendMessage(m.chat, { text: list }, { quoted: m })
    }
    
    // أمر عرض السور
    if (subCommand === 'سور' || subCommand === 'surahs') {
      let list = `📖 *قائمة السور* 📖\n\n`
      surahNames.slice(0, 20).forEach((s, i) => {
        list += `${i + 1}️⃣ *${s}*\n`
      })
      list += `\n...و ${surahNames.length - 20} سورة أخرى\n`
      list += `\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
      return conn.sendMessage(m.chat, { text: list }, { quoted: m })
    }
    
    // التحقق من وجود النص
    if (!text) {
      return conn.sendMessage(m.chat, {
        text: `📖 *القرآن الكريم* 📖

━━━━━━━━━━━━━━━━━
🎙️ *لتشغيل سورة:*
.قرآن <رقم السورة> <رقم القارئ>

📋 *مثال:*
.قرآن 5 1

🎙️ *لعرض القراء:*
.قرآن قراء

📖 *لعرض السور:*
.قرآن سور

🎧 *للحصول على سورة عشوائية:*
.قرآن عشوائي

━━━━━━━━━━━━━━━━━
⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
      }, { quoted: m })
    }
    
    // سورة عشوائية
    if (subCommand === 'عشوائي' || subCommand === 'random') {
      const randomSurah = Math.floor(Math.random() * 114) + 1
      const randomReciter = Math.floor(Math.random() * reciters.length) + 1
      
      await conn.sendMessage(m.chat, { 
        text: `🎧 *جاري تشغيل سورة عشوائية...*\n📖 السورة: ${randomSurah}\n🎙️ القارئ: ${reciters.find(r => r.id === randomReciter)?.name}`
      }, { quoted: m })
      
      const apiUrl = `https://helm-api.vercel.app/api/quran/audio/${randomSurah}/${randomReciter}?play=false`
      const response = await axios.get(apiUrl)
      
      if (response.data?.audio_url) {
        await conn.sendMessage(m.chat, {
          audio: { url: response.data.audio_url },
          mimetype: 'audio/mpeg',
          ptt: false
        }, { quoted: m })
      }
      return
    }
    
    // تشغيل سورة محددة
    let surahNum = parseInt(args[0])
    let reciterId = parseInt(args[1])
    
    if (isNaN(surahNum) || surahNum < 1 || surahNum > 114) {
      return conn.sendMessage(m.chat, {
        text: `❌ *رقم السورة غير صحيح*\n📖 أدخل رقماً بين 1 و 114`
      }, { quoted: m })
    }
    
    if (isNaN(reciterId) || reciterId < 1 || reciterId > reciters.length) {
      return conn.sendMessage(m.chat, {
        text: `❌ *رقم القارئ غير صحيح*\n🎙️ استخدم .قرآن قراء لعرض الأرقام`
      }, { quoted: m })
    }
    
    const reciter = reciters.find(r => r.id === reciterId)
    const surahName = surahNames[surahNum - 1]
    
    await conn.sendMessage(m.chat, { 
      text: `🎧 *جاري تشغيل التلاوة...*\n📖 السورة: ${surahName}\n🎙️ القارئ: ${reciter.name}`
    }, { quoted: m })
    
    const apiUrl = `https://helm-api.vercel.app/api/quran/audio/${surahNum}/${reciterId}?play=false`
    const response = await axios.get(apiUrl)
    
    if (response.data?.audio_url) {
      await conn.sendMessage(m.chat, {
        audio: { url: response.data.audio_url },
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: m })
    } else {
      throw new Error('لم يتم العثور على التلاوة')
    }
    
  } catch (err) {
    console.error('❌ خطأ:', err.message)
    await conn.sendMessage(m.chat, {
      text: `❌ *حدث خطأ أثناء تشغيل التلاوة*\n\n📛 ${err.message}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m })
  }
}

handler.command = ['قرآن', 'قران']
handler.help = ['قرآن']
handler.category = 'ديني'
handler.description = '📖 تشغيل تلاوات القرآن الكريم'

export default handler