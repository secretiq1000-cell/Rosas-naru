import { existsSync, promises as fs } from 'fs'
import { tmpdir } from 'os'
import path, { join, resolve } from 'path'

let handler = async (m, { conn, command, usedPrefix }) => {
  
  // 📂 عرض الجلسات
  if (command === 'sessions') {
    try {
      const subBotPath = resolve('./Sessions/SubBot/')
      if (!existsSync(subBotPath)) {
        return conn.reply(m.chat, `╭══════════════════╮
     📂 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐
════════════════════
💤 لا تـوجـد جـلـسـات
✅ الـنـظـام نـظـيـف
╰══════════════════╯`, m)
      }

      const folders = (await fs.readdir(subBotPath)).filter(f => /^\d+$/.test(f))
      if (folders.length === 0) {
        return conn.reply(m.chat, `╭══════════════════╮
     📂 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐
════════════════════
💤 لا تـوجـد جـلـسـات
✅ الـنـظـام نـظـيـف
╰══════════════════╯`, m)
      }

      const sessionsList = folders.map((f, i) => `🔹 ${i + 1}. ${f}`).join('\n')
      return conn.reply(m.chat, `╭══════════════════╮
     📂 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐
════════════════════
📊 الـجـلـسـات: ${folders.length}
════════════════════
${sessionsList}
╰══════════════════╯`, m)
    } catch (err) {
      console.error(err)
      return conn.reply(m.chat, `╭══════════════════╮
     ⚠️ 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐
════════════════════
📛 خـطـأ فـي الـعـرض
📌 ${err.message}
╰══════════════════╯`, m)
    }
  }

  // 🧹 أمر التنظيف (متاح للجميع)
  if (command === 'تنظيف') {
    try {
      await conn.sendMessage(m.chat, { react: { text: '♻', key: m.key } })
      
      let totalDeleted = 0
      let totalFolders = 0
      let tmpFilesDeleted = 0
      let mainSessionFilesDeleted = 0
      let subBotFilesDeleted = 0

      // 🔹 1. تنظيف SubBot
      const subBotPath = resolve('./Sessions/SubBot/')
      
      if (existsSync(subBotPath)) {
        const userFolders = await fs.readdir(subBotPath).catch(() => [])
        
        for (const userFolder of userFolders) {
          const userFolderPath = join(subBotPath, userFolder)
          if (!existsSync(userFolderPath)) continue
          
          const stats = await fs.stat(userFolderPath).catch(() => null)
          if (!stats?.isDirectory()) continue
          
          if (/^\d+$/.test(userFolder)) {
            totalFolders++
            let files = await fs.readdir(userFolderPath).catch(() => [])
            
            for (const file of files) {
              const filePath = join(userFolderPath, file)
              if (!existsSync(filePath)) continue
              
              const fileStats = await fs.stat(filePath).catch(() => null)
              if (!fileStats?.isFile()) continue
              
              if (file !== 'creds.json') {
                await fs.unlink(filePath).catch(() => {})
                totalDeleted++
                subBotFilesDeleted++
              }
            }
          }
        }
      }

      // 🔹 2. تنظيف Principal
      const mainSessionPath = resolve('./Sessions/Principal/')
      
      if (existsSync(mainSessionPath)) {
        let items = await fs.readdir(mainSessionPath, { withFileTypes: true }).catch(() => [])
        
        for (const item of items) {
          const itemPath = path.join(mainSessionPath, item.name)
          if (!existsSync(itemPath)) continue
          
          if (item.isDirectory()) {
            await fs.rm(itemPath, { recursive: true, force: true }).catch(() => {})
            totalDeleted++
            mainSessionFilesDeleted++
          } else if (item.isFile()) {
            if (item.name !== 'creds.json') {
              await fs.unlink(itemPath).catch(() => {})
              totalDeleted++
              mainSessionFilesDeleted++
            }
          }
        }
      }

      // 🔹 3. تنظيف الملفات المؤقتة
      const projectTmpPath = resolve('./tmp')
      if (existsSync(projectTmpPath)) {
        let files = await fs.readdir(projectTmpPath).catch(() => [])
        
        for (const file of files) {
          const fullPath = join(projectTmpPath, file)
          if (!existsSync(fullPath)) continue
          
          const statsInfo = await fs.stat(fullPath).catch(() => null)
          if (!statsInfo?.isFile()) continue
          
          await fs.unlink(fullPath).catch(() => {})
          totalDeleted++
          tmpFilesDeleted++
        }
      }

      await conn.sendMessage(m.chat, { react: { text: totalDeleted > 0 ? '✅' : '💤', key: m.key } })

      let reportMessage = `
╭══════════════════╮
     🧹 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐
════════════════════
🤖 *الفرعي:* ${totalFolders}📁 | ${subBotFilesDeleted}🗑️
💾 *الرئيسية:* ${mainSessionFilesDeleted}🗑️ | 🛡️creds
🗂️ *المؤقتة:* ${tmpFilesDeleted}🪛
════════════════════
📊 *الإجمالي:* ${totalDeleted}🎯
${totalDeleted > 0 ? '✅ تـم الـتـنـظـيـف بـنـجـاح' : '💤 لا تـوجـد مـلـفـات لـلـحـذف'}
╰══════════════════╯
`

      await conn.sendMessage(m.chat, {
        image: { url: 'https://i.postimg.cc/vTb8ckVk/IMG-20251229-WA0066.jpg' },
        caption: reportMessage.trim(),
        footer: '⚙️ 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 | نـظـام ذكـي'
      }, { quoted: m })

    } catch (err) {
      await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
      console.error('❌ خطأ في التنظيف:', err)
      await conn.reply(m.chat, `╭══════════════════╮
     ⚠️ 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐
════════════════════
📛 خـطـأ فـي الـتـنـظـيـف
📌 ${err.message}
════════════════════
🚫 تـم إيـقـاف الـعـمـلـيـة
╰══════════════════╯`, m)
    }
  }
}

handler.help = ['تنظيف', 'sessions']
handler.tags = ['general']  // تغيير من 'owner' إلى 'general'
handler.command = ['تنظيف', 'sessions']
// handler.owner = true  // تم إزالة هذا السطر أو تعليقه

export default handler