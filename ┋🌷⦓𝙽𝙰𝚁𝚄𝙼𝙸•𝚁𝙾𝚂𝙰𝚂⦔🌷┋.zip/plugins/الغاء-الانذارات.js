const handler = async (m, { conn, text, command, usedPrefix }) => {
  // 1. تحديد المستهدف (منشن أو رد أو نص)
  let who;
  if (m.isGroup) {
    who = m.mentionedJid[0] || (m.quoted ? m.quoted.sender : text);
  } else {
    who = m.chat;
  }

  // 2. منع تحذير البوت نفسه
  if (who === conn.user.jid) return;

  // 3. رسالة الخطأ مع منشن صحيح (بدون global.suittag)
  const warntext = `❪🌸❫⇇ *اعمل منشن أو رد على رسالة المستخدم* ⇇❪🌸❫\n\n⧈═━━━━✦🌸✦━━━━═⧈\n*—◉ مثال:*\n*${usedPrefix + command} @${m.sender.split('@')[0]}*`;
  
  if (!who) return m.reply(warntext, null, { mentions: [m.sender] });

  // 4. التأكد من وجود بيانات المستخدم
  if (!global.db.data.users[who]) {
    global.db.data.users[who] = { warn: 0 };
  }
  const user = global.db.data.users[who];

  // 5. التأكد من وجود خاصية warn بقيمة رقمية
  if (typeof user.warn !== 'number') user.warn = 0;

  // 6. إذا كان عدد التحذيرات 0، لا يمكن إزالة تحذير
  if (user.warn === 0) {
    return m.reply(`❪🌸❫⇇ *المستخدم عنده 0 تحذير، لا يمكن إزالة المزيد* ⇇❪🌸❫`);
  }

  // 7. إنقاص التحذير بمقدار 1
  user.warn -= 1;

  // 8. رسالة الرد حسب العدد الجديد
  const replyText = user.warn === 1
    ? `❪🌸❫⇇ *تمت إزالة تحذير عن* ⇇❪@${who.split('@')[0]}❫\n*┊عدد التحذيرات الآن: ❪${user.warn}/3❫*\n⧈═━━━━✦🌸✦━━━━═⧈`
    : `❪🌸❫⇇ *تمت إزالة التحذير بنجاح* ⇇❪@${who.split('@')[0]}❫\n*┊عدد التحذيرات الآن: ❪${user.warn}/3❫*\n⧈═━━━━✦🌸✦━━━━═⧈`;

  await m.reply(replyText, null, { mentions: [who] });
  await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
};

// أوامر التشغيل
handler.command = /^(unwarn|delwarn|حذف-التحذير|الغاء-التحذير|delwarning|الغاء-الانذار|الغاءالانذار)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
