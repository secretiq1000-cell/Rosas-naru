// ملف: تعديل.js
import axios from "axios";
import uploadImage from "../lib/uploadImage.js";

async function translateToEnglish(text) {
  try {
    const url = "https://translate.googleapis.com/translate_a/single";
    const params = { client: "gtx", sl: "auto", tl: "en", dt: "t", q: text };
    const response = await axios.get(url, { params });
    return response.data?.[0]?.[0]?.[0] || text;
  } catch {
    return text;
  }
}

async function img2imgFree(imageUrl, prompt) {
  const translated = await translateToEnglish(prompt);
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(translated)}?image=${encodeURIComponent(imageUrl)}&width=1024&height=1024&nologo=true&model=flux`;
}

async function fetchUrlToBuffer(url) {
  const response = await axios.get(url, { responseType: "arraybuffer", timeout: 60000 });
  return Buffer.from(response.data);
}

let handler = async (m, { conn, text, args, usedPrefix }) => {
  let prompt, imageUrl;
  const q = m.quoted || m;
  const mimeQuoted = (q.msg || q).mimetype || "";
  
  if (/image/.test(mimeQuoted)) {
    if (!text) throw `⚠️ اكتب التعديل المطلوب.\n📌 مثال:\n${usedPrefix}تعديل اجعلها كرتونية`;
    const buffer = await q.download();
    if (!buffer) throw "❌ لم أستطع جلب الصورة";
    imageUrl = await uploadImage(buffer);
    prompt = text.trim();
  } else if (text) {
    const parts = text.split("|").map(s => s.trim());
    if (parts.length >= 2) {
      imageUrl = parts[0];
      prompt = parts.slice(1).join(" ");
    } else {
      throw `⚠️ أرسل الصورة مرفقة مع الوصف، أو استخدم:\n${usedPrefix}تعديل رابط_الصورة | الوصف`;
    }
  } else {
    throw `⚠️ رد على صورة مع الوصف.\nمثال:\n${usedPrefix}تعديل اجعلها أنمي`;
  }
  
  if (!/^https?:\/\//i.test(imageUrl)) throw "❌ رابط الصورة غير صالح";
  
  const waitMsg = await conn.sendMessage(m.chat, { text: "🖌️ جاري التعديل..." }, { quoted: m });
  
  const resultUrl = await img2imgFree(imageUrl, prompt);
  const buffer = await fetchUrlToBuffer(resultUrl);
  
  await conn.sendMessage(m.chat, { delete: waitMsg.key }).catch(() => {});
  await conn.sendMessage(m.chat, { 
    image: buffer, 
    caption: `✅ تم التعديل\n📌 ${prompt}` 
  }, { quoted: m });
};

handler.command = /^(تعديل)$/i;
export default handler;
