
import yts from 'yt-search'
import fetch from 'node-fetch'

let ytmp3mobi = async (youtubeUrl, format = "mp4", quality = "high") => {
    // ✅ استخراج videoId من جميع روابط يوتيوب
    const regYoutubeId = /(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/
    const match = youtubeUrl.match(regYoutubeId)
    const videoId = match ? match[1] : null

    if (!videoId) throw Error("❌ لم أتمكن من استخراج معرف الفيديو من الرابط، تأكد أنه رابط يوتيوب صالح.")

    // ✅ جودة 720p ثابتة
    const urlParam = { v: videoId, f: format, q: "high", _: Math.random() }
    const headers = { "Referer": "https://id.ytmp3.mobi/" }

    const fetchJson = async (url, fetchDescription) => {
        const res = await fetch(url, { headers })
        if (!res.ok) throw Error(`❌ فشل في ${fetchDescription} | ${res.status} ${res.statusText}`)
        return await res.json()
    }

    const { convertURL } = await fetchJson("https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=" + Math.random(), "الحصول على رابط التحويل")
    const { progressURL, downloadURL } = await fetchJson(`${convertURL}&${new URLSearchParams(urlParam).toString()}`, "الحصول على رابط التقدم")

    let { error, progress, title } = {}
    while (progress != 3) {
        ({ error, progress, title } = await fetchJson(progressURL, "جلب حالة التحويل"))
        if (error) throw Error(`❌ خطأ أثناء التحويل: ${error}`)
    }

    return { title, downloadURL }
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    let contoh = `${usedPrefix + command} سورة الكهف - ماهر المعيقلي`
    return m.reply(`
*⚠️ الاستخدام الصحيح:*
اكتب رابط يوتيوب أو اسم المقطع الذي تريد تحميله بصيغة MP4.

*🎬 الجودة:* 720p (عالية)

*مثال:* 
${contoh}
    `.trim())
  }

  await m.react("⏳")

  let url
  let query = text.trim()

  // التحقق إذا كان الرابط أم بحث
  const videoMatch = query.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/|live\/|v\/))([a-zA-Z0-9_-]{11})/)
  
  if (videoMatch) {
    url = 'https://youtu.be/' + videoMatch[1]
  } else {
    let search = await yts(query)
    if (!search.videos.length) throw '❌ لم أجد أي نتائج لهذا البحث'
    url = search.videos[0].url
  }

  try {
    // الحصول على معلومات الفيديو
    let searchInfo = await yts(url)
    let videoInfo = searchInfo.videos[0] || searchInfo.all[0]
    let title = videoInfo?.title || 'video'
    
    // جودة 720p ثابتة
    let quality = "720p (عالية)"
    
    // تجهيز جميع المعلومات
    let vistas = (videoInfo.views || 0).toLocaleString()
    let canal = videoInfo.author?.name || 'غير معروف'
    let infoMessage = `📥 *${videoInfo.title}*

🎥 *الجودة:* ${quality}
📺 *القناة:* ${canal}
⏱️ *المدة:* ${videoInfo.timestamp || 'غير معروف'}
👁️ *المشاهدات:* ${vistas}
📅 *النشر:* ${videoInfo.ago || 'غير معروف'}`

    // ✅ استخدام API ytmp3mobi للتحميل بجودة 720p
    const { title: videoTitle, downloadURL } = await ytmp3mobi(url, "mp4", "high")
    
    // إرسال الفيديو مع جميع المعلومات في الكابشن
    await conn.sendMessage(m.chat, {
      video: { url: downloadURL },
      mimetype: 'video/mp4',
      fileName: `${videoTitle || title}.mp4`,
      caption: infoMessage
    }, { quoted: m })

  } catch (error) {
    console.error(error)
    await m.reply(`❌ حدث خطأ: ${error.message || 'فشل التحميل'}`)
  }

  await m.react("✅")
}

handler.help = ['فيديوي <رابط/بحث>']
handler.tags = ['downloader']
handler.command = ['فيديوي']
handler.register = true

export default handler
