// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import { jidDecode } from '@whiskeysockets/baileys'

const decorate = (text) => `╭──⪧\n🍷 *${text}*\n╰──⪦`

let handler = async (m, { conn, text }) => {
  try {
    let targetJid = null
    let inputNumber = text?.trim() || ''

    // 1️⃣ التحقق من وجود منشن
    if (m.mentionedJid && m.mentionedJid.length > 0) {
      targetJid = m.mentionedJid[0]
    }
    
    // 2️⃣ التحقق من الرد على رسالة
    if (!targetJid && m.quoted) {
      targetJid = m.quoted.sender
    }
    
    // 3️⃣ التحقق من إدخال رقم
    if (!targetJid && inputNumber) {
      let cleanNumber = inputNumber.replace(/[^0-9]/g, '')
      
      if (cleanNumber.length >= 10) {
        if (cleanNumber.startsWith('0')) {
          cleanNumber = '20' + cleanNumber.slice(1)
        }
        if (!cleanNumber.startsWith('20') && !cleanNumber.startsWith('966') && !cleanNumber.startsWith('971')) {
          cleanNumber = '20' + cleanNumber
        }
        targetJid = `${cleanNumber}@s.whatsapp.net`
      }
    }

    if (!targetJid) {
      return await conn.sendMessage(m.chat, {
        text: decorate('👤 من فضلك *رد على رسالة الشخص* أو *منشن الشخص* أو *اكتب الرقم*\n\nمثال: .بروفايل2 201234567890'),
      }, { quoted: m })
    }

    const targetName = targetJid.split('@')[0]
    
    const ppUrl = await conn.profilePictureUrl(targetJid, 'image').catch(() => null)

    if (!ppUrl) {
      return await conn.sendMessage(m.chat, {
        text: decorate('❌ لا يوجد صورة بروفايل لهذا الشخص أو غير مسموح بالوصول إليها.'),
      }, { quoted: m })
    }

    await conn.sendMessage(m.chat, {
      image: { url: ppUrl },
      caption: `📸 *صورة بروفايل* لـ @${targetName}\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`,
      mentions: [targetJid],
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, {
      text: decorate('⚠️ حصل خطأ أثناء محاولة جلب صورة البروفايل.'),
    }, { quoted: m })
  }
}

handler.command = ['بروفايل2']
handler.help = ['بروفايل2']
handler.category = 'tools'
handler.description = '🖼️ عرض صورة الملف الشخصي لأي شخص (بالرد، المنشن، أو الرقم)'

export default handler
