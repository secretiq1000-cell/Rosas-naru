const developerNumber = "201022950118@s.whatsapp.net"; // رقم المطور

let handler = async (m, { conn, args }) => {
  if (!m.isGroup) throw '⚠️ هذا الأمر يعمل داخل المجموعات فقط.';
  if (!m.quoted && !args[0]) throw '👤 منشن الشخص أو اكتب رقمه.\n\nمثال:\nادخله 201234567890 مرحباً';

  let target = '';
  let msg = '';

  // لو منشَّن شخص
  if (m.quoted) {
    target = m.quoted.sender;
    msg = args.join(' ');
  } else {
    // استخراج الرقم فقط
    const number = args[0].replace(/[^0-9]/g, '');
    target = number + '@s.whatsapp.net';
    msg = args.slice(1).join(' ');
  }

  if (!msg) throw '✏️ اكتب الرسالة التي تريد إرسالها.';

  // إرسال الرسالة للرقم في الخاص — لا يحتاج مشرف
  await conn.sendMessage(target, { text: msg }, { quoted: m });

  // تأكيد الإرسال
  await m.reply(
    `✅ تم إرسال الرسالة إلى: @${target.split('@')[0]}\n👨‍💻 رقم المطوّر: @${developerNumber.split('@')[0]}`,
    null,
    { mentions: [target, developerNumber] }
  );
};

handler.help = ['ادخله'];
handler.tags = ['group'];
handler.command = ['ادخله'];

export default handler;
