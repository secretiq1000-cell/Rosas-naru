let handler = async (m, { conn, args, usedPrefix, command }) => {

    // تحديد المستخدم المستهدف
    let who = m.mentionedJid && m.mentionedJid[0] 
        ? m.mentionedJid[0] 
        : m.quoted ? m.quoted.sender 
        : args[0] ? args[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net' 
        : false

    if (!who) return m.reply(`🍩 *ضع تاغ للمستخدم أو أدخل رقمه أولاً لإلغاء الحظر!*  
    
🍡 *مثال:*  
${usedPrefix + command} @${m.sender.split('@')[0]}`, false, { mentions: [m.sender] })

    // التأكد أن المستخدم موجود في قاعدة البيانات
    if (!global.db.data.users[who]) global.db.data.users[who] = {}
    let user = global.db.data.users[who]

    // تنفيذ إلغاء الحظر
    user.banned = false
    user.bannedTime = 0

    // إشعار المجموعة
    m.reply(`🍀 *تم إلغاء حظر @${who.split('@')[0]} بنجاح!*`, false, { mentions: [who] })

   
    // رسالة توضيح الاستخدام
    let usage = `
💡 *لتوضيح استخدام الأمر:*  
يمكنك إلغاء حظر أي مستخدم باستخدام الأمر \`${usedPrefix + command}\`  

📌 مثال:  
- لإلغاء الحظر عن مستخدم: \`${usedPrefix + command} @user\`

𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 💀
`.trim()

    await m.reply(usage)
}

handler.help = ['unban', 'الغاء-بان']
handler.tags = ['owner']
handler.command = /^(unban|الغاء-بان|فك-حظر|فكحظر)$/i
handler.owner = true
handler.register = true

export default handler
