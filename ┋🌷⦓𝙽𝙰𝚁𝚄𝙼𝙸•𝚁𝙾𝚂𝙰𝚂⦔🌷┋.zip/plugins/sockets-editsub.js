import Jimp from 'jimp'

const handler = async (m, { conn, command, usedPrefix, text }) => {

/*
╭•─•─•─•─•╮
│ 🔐 التحقق من الصلاحيات (Owner + Developer)
╰•─•─•─•─•╯
*/

const developer = '201022950118@s.whatsapp.net'

const isAllowed = [
...global.owner.map(([n]) => `${n}@s.whatsapp.net`),
...(global.mods || []).map(n => `${n}@s.whatsapp.net`),
developer
].includes(m.sender)

if (!isAllowed)
return m.reply(`❀ هذا الأمر مخصص للمالك والمطور فقط.`)

try {
const value = text ? text.trim() : ''

switch (command) {

/*
╭•─•─•─•─•╮
│ 🖼️ تغيير صورة البروفايل
╰•─•─•─•─•╯
*/
case 'تغيير_الصورة':
case 'ضبط_الصورة': {
const q = m.quoted || m
const mime = (q.msg || q).mimetype || ''
if (!/image\/(png|jpe?g)/.test(mime))
return conn.reply(m.chat, `❀ أرسل أو رد على صورة صالحة.`, m)

const media = await q.download()
if (!media) return conn.reply(m.chat, `ꕥ فشل تحميل الصورة.`, m)

const image = await Jimp.read(media)
const buffer = await image.getBufferAsync(Jimp.MIME_JPEG)

await conn.updateProfilePicture(conn.user.jid, buffer)
await conn.reply(m.chat, `❀ تم تغيير صورة البروفايل بنجاح.`, m)
break
}

/*
╭•─•─•─•─•╮
│ 📝 تغيير الحالة / البايو
╰•─•─•─•─•╯
*/
case 'تغيير_الحالة':
case 'تغيير_النبذة': {
if (!value)
return conn.reply(m.chat, `❀ اكتب الحالة الجديدة.`, m)

await conn.updateProfileStatus(value)
await conn.reply(m.chat, `❀ تم تحديث الحالة إلى:\n*${value}*`, m)
break
}

/*
╭•─•─•─•─•╮
│ 👤 تغيير اسم المستخدم
╰•─•─•─•─•╯
*/
case 'تغيير_الاسم':
case 'تحديث_الاسم': {
if (!value)
return conn.reply(m.chat, `❀ اكتب الاسم الجديد.`, m)

if (value.length < 3 || value.length > 25)
return conn.reply(m.chat, `ꕥ الاسم يجب أن يكون بين 3 و 25 حرفًا.`, m)

await conn.updateProfileName(value)
await conn.reply(m.chat, `❀ تم تغيير الاسم إلى *${value}* بنجاح.`, m)
break
}

default:
break
}

} catch (e) {
m.reply(`⚠︎ حدث خطأ.\n> استخدم *${usedPrefix}ابلغ*\n\n${e.message}`)
}}

handler.help = [
'تغيير_الصورة',
'ضبط_الصورة',
'تغيير_الحالة',
'تغيير_النبذة',
'تغيير_الاسم',
'تحديث_الاسم'
]

handler.tags = ['socket']

handler.command = [
'تغيير_الصورة',
'ضبط_الصورة',
'تغيير_الحالة',
'تغيير_النبذة',
'تغيير_الاسم',
'تحديث_الاسم'
]

export default handler

/*
╭•─•─•─•─•╮
│ 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
╰•─•─•─•─•╯
*/
