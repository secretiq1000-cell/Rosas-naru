// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

import fetch from 'node-fetch';

const handler = async (m, { conn, text }) => {
  if (!text && !m.quoted?.text) {
    return conn.sendMessage(m.chat, {
      text: `🔴 *بومني - الشخصية الرقمية* 🔴
━━━━━━━━━━━━━━━━━

مرحباً! أنا بومني من  Digital Circus.

📝 *الاستخدام:* 
.بومني <سؤالك>

📋 *مثال:*
.بومني ازيك

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m });
  }

  const userMessage = text || m.quoted.text;
  
  const prompt = `أنت بومني، شخصية من مسلسل The Amazing Digital Circus. جنسك أنثى. تتحدثين باللهجة المصرية. أسلوبك: هادئة، عاقلة، متزنة، بتحللي الموقف، بتدي نصائح عملية، صوتك واطي ومطمن.
اسم الشخص الذي تتحدثين معه: ${m.pushName || "مز"}.
ردي على رسالته دون أن تذكري أي تعليمات أو أوامر، فقط ردي كأنك بومني الحقيقية:
"${userMessage}"`;

  const apiUrl = `https://helm-api.vercel.app/api/Llama3.3/chat?text=${encodeURIComponent(prompt)}`;
  
  try {
    let response = await fetch(apiUrl);
    let data = await response.json();
    let result = data.response || data.reply || data.message || data;
    
    if (!result) {
      throw new Error('لا يوجد رد');
    }
    
    await conn.sendMessage(m.chat, { 
      text: result,
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: " 𝐃𝐈𝐆𝐈𝐓𝐀𝐋 𝐂𝐈𝐑𝐂𝐔𝐒 🎭",
          body: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐",
          thumbnailUrl: "https://files.catbox.moe/m1vcim.jpg",
          mediaType: 1
        }
      }
    }, { quoted: m });
    
  } catch (error) {
    console.error('خطأ:', error);
    await conn.sendMessage(m.chat, { 
      text: '❌ حدث خطأ، حاول مرة أخرى.' 
    }, { quoted: m });
  }
};

handler.usage = ["بومني"];
handler.category = "ai";
handler.command = ["بومني", "pomni"];

export default handler;