import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
  // منع البوت من الرد على نفسه
  if (m.key && m.key.fromMe) return
  
  if (!m.text) return

  const text = m.text.trim()

  const sendAudio = async (url, ptt = false) => {
    try {
      await conn.sendPresenceUpdate('recording', m.chat)
      
      // التحقق من صحة الرابط قبل الإرسال
      if (!url || typeof url !== 'string') {
        console.log('[AUTO-AUDIO] رابط غير صالح')
        return
      }

      // محاولة إرسال الصوت مع timeout
      const audioData = {
        audio: { url },
        mimetype: ptt ? 'audio/ogg; codecs=opus' : 'audio/mpeg',
        ptt
      }
      
      await conn.sendMessage(m.chat, audioData, { quoted: m })
      
    } catch (e) {
      // معالجة الأخطاء المختلفة دون تعطيل البوت
      if (e.data === 403 || e.output?.statusCode === 403 || e?.message?.includes('forbidden')) {
        console.log('[AUTO-AUDIO] تم حظر الإرسال (403) - رابط غير مدعوم أو محظور')
      } else if (e.data === 428 || e.output?.statusCode === 428) {
        console.log('[AUTO-AUDIO] جلسة غير متصلة (428) - سيتم المحاولة مرة أخرى لاحقاً')
      } else {
        console.log('[AUTO-AUDIO خطأ غير متوقع]:', e.message || e)
      }
    }
  }

  // ╭───────────────────╮
  // │   الردود الموحدة   │
  // ╰───────────────────╯
  const replies = {
    "بضان": ['https://files.catbox.moe/iboovz.m4a', false],
    "بضاني": ['https://files.catbox.moe/iboovz.m4a', false],
    "بعبص": ['https://files.catbox.moe/5fuc77.opus', true],
    "بعبصي": ['https://files.catbox.moe/5fuc77.opus', true],
    "بمقابل": ['https://files.catbox.moe/ng4rxo.opus', true],
    "فلوس": ['https://files.catbox.moe/ng4rxo.opus', true],
    "بموتفيك": ['https://files.catbox.moe/ptr5o9.opus', true],
    "الاخر": ['https://files.catbox.moe/ptr5o9.opus', true],
    "فيكك": ['https://files.catbox.moe/ptr5o9.opus', true],
    "اخري": ['https://files.catbox.moe/ptr5o9.opus', true],
    "بتردليه": ['https://files.catbox.moe/9v99rd.opus', true],
    "بترد": ['https://files.catbox.moe/9v99rd.opus', true],
    "جدعه": ['https://files.catbox.moe/uohz0s.opus', true],
    "جدع": ['https://files.catbox.moe/uohz0s.opus', true],
    "جارتي": ['https://files.catbox.moe/mtqe61.opus', true],
    "جارتك": ['https://files.catbox.moe/mtqe61.opus', true],
    "الروم": ['https://files.catbox.moe/ui516o.opus', true],
    "الناس": ['https://files.catbox.moe/ui516o.opus', true],
    "زبي": ['https://files.catbox.moe/h3nqdn.opus', true],
    "اتجوز": ['https://files.catbox.moe/h3nqdn.opus', true],
    "بكره": ['https://files.catbox.moe/h3nqdn.opus', true],
    "زيك": ['https://files.catbox.moe/0p20no.opus', true],
    "ساكت": ['https://files.catbox.moe/0p20no.opus', true],
    "سكت": ['https://files.catbox.moe/mxoh97.opus', true],
    "اسكت": ['https://files.catbox.moe/mxoh97.opus', true],
    "تموت": ['https://files.catbox.moe/h3nqdn.opus', true],
    "هتموت": ['https://files.catbox.moe/h3nqdn.opus', true],
    "شفت": ['https://files.catbox.moe/rbx6wq.opus', true],
    "شخره": ['https://files.catbox.moe/ytbpn8.opus', true],
    "خخ": ['https://files.catbox.moe/ytbpn8.opus', true],
    "طيزك": ['https://files.catbox.moe/4yc9qv.opus', true],
    "عايزك": ['https://files.catbox.moe/04h9sm.opus', true],
    "تتناك": ['https://files.catbox.moe/2k795u.mp3', false],
    "فل": ['https://files.catbox.moe/ptr5o9.opus', true],
    "عاش": ['https://files.catbox.moe/ptr5o9.opus', true],
    "قعدين": ['https://files.catbox.moe/ue2hmy.opus', true],
    "عيط": ['https://files.catbox.moe/ue2hmy.opus', true],
    "فهمان": ['https://files.catbox.moe/w2196k.opus', true],
    "هعرفك": ['https://files.catbox.moe/w2196k.opus', true],
    "بديلو": ['https://files.catbox.moe/t8vzea.opus', true],
    "فوقو": ['https://files.catbox.moe/t8vzea.opus', true],
    "خرا": ['https://files.catbox.moe/ucnuj6.opus', true],
    "خرى": ['https://files.catbox.moe/ucnuj6.opus', true],
    "مليش": ['https://files.catbox.moe/ku2o1m.opus', true],
    "ايوه": ['https://files.catbox.moe/fa9xix.opus', true],
    "ههههه": ['https://files.catbox.moe/gx14xj.mp3', false],
    "😂😂": ['https://files.catbox.moe/gx14xj.mp3', false],
    "ضحك": ['https://files.catbox.moe/gx14xj.mp3', false],
  }

  // دالة للبحث عن كلمات كاملة داخل النص
  const findWholeWord = (text, replies) => {
    // تقسيم النص إلى كلمات مع الحفاظ على الرموز التعبيرية
    const words = text.match(/[\p{L}\p{N}\p{Emoji}]+|\S+/gu) || []
    
    for (const key in replies) {
      // إذا كانت الكلمة المفتاحية موجودة في قائمة الكلمات المنفصلة
      if (words.includes(key)) {
        return { key, ...replies[key] }
      }
    }
    return null
  }

  // البحث عن تطابق كامل (الكلمة كاملة وليست جزئياً)
  const match = findWholeWord(text, replies)
  
  if (match) {
    const [url, ptt] = [match[0], match[1]]
    return sendAudio(url, ptt)
  }
}

handler.customPrefix = /.*/
handler.command = new RegExp

export default handler
