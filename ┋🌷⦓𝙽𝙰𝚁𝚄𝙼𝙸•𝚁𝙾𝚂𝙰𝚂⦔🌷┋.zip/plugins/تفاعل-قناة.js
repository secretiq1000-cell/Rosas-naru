let handler = async (m, { conn, text, args, isOwner }) => {
  if (!isOwner) 
    return m.reply("*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*\n❌ *عذرًا، هذا الأمر مخصص للمالك فقط!*\n*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*");

  if (!text || !args[0] || !args[1]) 
    return m.reply("*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*\n⚠️ *طريقة الاستخدام الصحيحة:*\n.تفاعل https://whatsapp.com/channel/0029Vb6hPGJ3bbVCjW2W6D2p 🇲🇦🇲🇦❤🧡💛💚💚\n*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*");

  if (!args[0].includes("https://whatsapp.com/channel/")) 
    return m.reply("*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*\n🚫 *الرابط الذي أدخلته غير صالح، يرجى إدخال رابط قناة صحيح!*\n*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*");

  let result = args[0].split('/')[4];
  let serverId = args[0].split('/')[5];
  let res = await conn.newsletterMetadata("invite", result);

  await conn.newsletterReactMessage(res.id, serverId, args[1]);


  await conn.sendMessage(m.chat, {
    image: { url: "https://i.postimg.cc/6qyZ8sKv/IMG-20251230-WA0075.jpg" },
    caption: `*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*\n✅ *تم إرسال التفاعل (${args[1]}) إلى قناة:* *${res.name}* بنجاح! 🎉\n*⎔ ⋅ ───━ •﹝💀﹞• ━─── ⋅ ⎔*`,
  }, { quoted: m });
};

handler.help = ["دانى"];
handler.tags = ["دانى"];
handler.command = /^تفاعل-قناة$/i;

export default handler;
