import axios from 'axios'
import * as cheerio from 'cheerio'

let handler = async (m, { conn, text }) => {

if (!text) {
return m.reply('الاستخدام : .اجلب + الرابط\n📌 مثال:\n.اجلب https://example.com/music.mp3\n\n.اجلب https://files.catbox.moe/s9wbeh.mp3')
}

await conn.sendMessage(m.chat, {
    react: { text: '⏳', key: m.key }
})

// ========== الحالة 1: رابط مباشر لملف صوتي ==========
if (text.match(/\.(mp3|wav|ogg|m4a|flac|aac|opus)(\?|$)/i)) {
    try {
        await conn.sendMessage(m.chat, {
            audio: { url: text },
            mimetype: 'audio/mpeg',
            caption: '🎵 تم التحميل من الرابط المباشر'
        })
        return
    } catch(e) {
        return m.reply(`❌ فشل تحميل الصوت: ${e.message}`)
    }
}

// ========== الحالة 2: رابط موقع عادي ==========
let الصوتيات = []

// روابط API بديلة لتجاوز الحماية
let apiList = [
    `https://api.allorigins.win/raw?url=${encodeURIComponent(text)}`,
    `https://api.codetabs.com/v1/proxy/?quest=${text}`,
    `https://thingproxy.freeboard.io/fetch/${text}`
]

let data = null

for (let api of apiList) {
    try {
        let res = await axios.get(api, { 
            timeout: 15000,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        })
        if (res.data && typeof res.data === 'string' && (res.data.includes('html') || res.data.length > 500)) {
            data = res.data
            break
        }
    } catch(e) {}
}

if (!data) {
    try {
        data = (await axios.get(text, {
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
            }
        })).data
    } catch(e) {}
}

if (!data) {
    return m.reply(`❌ تعذر الوصول إلى الموقع: ${text}`)
}

try {
    const $ = cheerio.load(data)

    const fixUrl = (url) => {
        if (!url) return null
        if (url.startsWith('//')) return 'https:' + url
        if (url.startsWith('/')) return new URL(url, text).href
        if (url.startsWith('http')) return url
        return null
    }

    // ========== جلب الصوتيات ==========

    // من audio tags
    $('audio').each((i, el) => {
        let src = $(el).attr('src')
        if (src) {
            let fixed = fixUrl(src)
            if (fixed && fixed.match(/\.(mp3|wav|ogg|m4a|flac|aac|opus)(\?|$)/i)) 
                الصوتيات.push(fixed)
        }
        $(el).find('source').each((i, srcEl) => {
            let s = $(srcEl).attr('src')
            if (s) {
                let fixed = fixUrl(s)
                if (fixed && fixed.match(/\.(mp3|wav|ogg|m4a|flac|aac|opus)(\?|$)/i)) 
                    الصوتيات.push(fixed)
            }
        })
    })

    // من source tags
    $('source').each((i, el) => {
        let src = $(el).attr('src')
        let type = $(el).attr('type') || ''
        if (src && type.includes('audio')) {
            let fixed = fixUrl(src)
            if (fixed) الصوتيات.push(fixed)
        }
    })

    // من الروابط a
    $('a').each((i, el) => {
        let href = $(el).attr('href')
        if (href) {
            let fixed = fixUrl(href)
            if (fixed && fixed.match(/\.(mp3|wav|ogg|m4a|flac|aac|opus)(\?|$)/i)) {
                الصوتيات.push(fixed)
            }
        }
    })

    // من meta tags
    $('meta[property="og:audio"], meta[name="twitter:audio"]').each((i, el) => {
        let content = $(el).attr('content')
        if (content) {
            let fixed = fixUrl(content)
            if (fixed) الصوتيات.push(fixed)
        }
    })

    // إزالة التكرار
    الصوتيات = [...new Set(الصوتيات)]

    let نتيجة = `
╭•─•─•𓆩 ✦ استخراج صوتيات ✦ 𓆪•─•─•╮

🌐 ${text}

🎵 عدد الصوتيات: ${الصوتيات.length}

╰•─•─•𓆩 ✦ 𓆪•─•─•╯
    `

    await m.reply(نتيجة)

    // ===== إرسال الصوتيات =====
    if (الصوتيات.length > 0) {
        let i = 0
        for (let audio of الصوتيات.slice(0, 15)) {
            try {
                await conn.sendMessage(m.chat, {
                    audio: { url: audio },
                    mimetype: 'audio/mpeg',
                    caption: `🎵 صوت ${i+1}`
                })
                i++
                await new Promise(r => setTimeout(r, 1000))
            } catch(e) {
                await m.reply(`❌ فشل تحميل الصوت ${i+1}\n🔗 ${audio}`)
            }
        }
    }

    if (الصوتيات.length === 0) {
        await m.reply(`⚠️ لم يتم العثور على روابط صوتية في هذا الموقع`)
    }

} catch(e) {
    await m.reply(`❌ خطأ: ${e.message}`)
}
}

handler.command = ['اجلب', 'جلب']
export default handler