import axios from 'axios';
import fs from 'fs';

let handler = async (m, { conn, args }) => {
  const text = args.join(' ');
  if (!text) return conn.reply(m.chat, '*اكتب حاجة تبحث عنها يا حوب 🧞*', m);
  
  await conn.sendMessage(m.chat, { react: { text: '🔍', key: m.key } }); // إضافة تفاعل
  
  try {
    const response = await axios.get(`https://news.google.com/rss/search?q=${encodeURIComponent(text)}&hl=ar&gl=EG&ceid=EG:ar`, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    const html = response.data;
    const titles = html.match(/<title>(.*?)<\/title>/g) || [];
    const links = html.match(/<link>(.*?)<\/link>/g) || [];
    
    if (titles.length <= 1) {
      const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(text)}`;
      await conn.reply(m.chat, `🔍 *نتائج البحث عن:* ${text}\n\n📌 افتح الرابط:\n${searchUrl}\n\nعذراً ما قدرتش أجيب نتائج دلوقتي 🧞`, m);
      return;
    }
    
    let teks = `🔍 *نتائج البحث عن:* _${text}_\n\n`;
    let resultCount = 0;
    
    for (let i = 1; i < Math.min(titles.length, 6); i++) {
      let title = titles[i].replace(/<title>/g, '').replace(/<\/title>/g, '');
      let link = links[i] ? links[i].replace(/<link>/g, '').replace(/<\/link>/g, '') : '#';
      
      // تنظيف النص من HTML entities
      title = title.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
      
      teks += `📌 *${title}*\n🔗 ${link}\n\n━━━━━━━━━━━━━━━\n\n`;
      resultCount++;
    }
    
    teks += `\n📊 *عدد النتائج:* ${resultCount}`;
    await conn.reply(m.chat, teks, m);
    
  } catch (error) {
    console.error('خطأ:', error.message);
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(text)}`;
    await conn.reply(m.chat, `🔍 *البحث عن:* ${text}\n\n⚠️ حدث خطأ: ${error.message}\n\nرابط البحث البديل:\n${searchUrl}`, m);
  }
}

handler.command = /^جوجل|google$/i;
handler.description = 'البحث في أخبار جوجل';
handler.tag = 'search';

export default handler;

