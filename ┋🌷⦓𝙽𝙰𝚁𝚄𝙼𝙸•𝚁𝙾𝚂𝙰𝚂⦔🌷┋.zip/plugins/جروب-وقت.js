// ╭•─•─•─•─•─•─•─•─•─•┈●
// │   قفل / فتح الجروب بوقت
// │   مطوّر الأمر: 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╰•─•─•─•─•─•─•─•─•─•

const handler = async (m, { conn, isAdmin, isOwner, args, usedPrefix, command }) => {

  if (!(isAdmin || isOwner)) {
    global.dfail('admin', m, conn)
    return
  }

  const mode = (args[0] || '').toLowerCase()

  const isClose = {
    'فتح': 'not_announcement',
    'on': 'not_announcement',
    '1': 'not_announcement',

    'قفل': 'announcement',
    'off': 'announcement',
    '0': 'announcement'
  }[mode]

  if (!isClose) {
    return m.reply(`
╭•─•─•─•─•─•─•─•─•─•┈●
│  ⚙️ أوامر إدارة الجروب
│
│  🔓 فتح الجروب:
│  ${usedPrefix + command} فتح 1
│
│  🔒 قفل الجروب:
│  ${usedPrefix + command} قفل 1
│
│  ⏱️ الرقم = عدد الساعات
│  ✨ الأمر يعمل تلقائيًا
╰•─•─•─•─•─•─•─•─•─•
`)
  }

  const hours = Number(args[1])
  const timeout = hours ? hours * 60 * 60 * 1000 : null

  await conn.groupSettingUpdate(m.chat, isClose)

  m.reply(`⚠️ تم ${isClose === 'announcement' ? 'قفل' : 'فتح'} الجروب ${hours ? `لمدة ⏱️ ${clockString(timeout)}` : ''}`)

  if (timeout) {
    setTimeout(async () => {
      const revert = isClose === 'announcement' ? 'not_announcement' : 'announcement'
      await conn.groupSettingUpdate(m.chat, revert)

      conn.reply(
        m.chat,
        revert === 'announcement'
          ? '🔒 تم قفل الجروب تلقائيًا، الكتابة للمشرفين فقط.'
          : '🔓 تم فتح الجروب تلقائيًا، يمكن للجميع الكتابة الآن.'
      )
    }, timeout)
  }
}

handler.help = ['وقت <فتح/قفل> <ساعات>']
handler.tags = ['group']
handler.command = /^وقت$/i

handler.botAdmin = true
handler.group = true

export default handler

function clockString(ms) {
  const h = Math.floor(ms / 3600000)
  const m = Math.floor(ms / 60000) % 60
  const s = Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}
