// approve-any-number.js

let handler = async (m, { conn, args, isAdmin }) => {
  try {
    if (!m.isGroup)
      return conn.reply(m.chat, '❌ هذا الأمر خاص بالمجموعات فقط.', m)

    if (!isAdmin)
      return conn.reply(m.chat, '❌ هذا الأمر متاح للمشرفين فقط.', m)

    // جلب طلبات الانضمام
    const pending = await conn.groupRequestParticipantsList(m.chat)

    if (!pending || pending.length === 0)
      return conn.reply(m.chat, 'ℹ️ لا توجد طلبات انضمام معلقة.', m)

    // العدد المطلوب
    let count = Number(args[0])

    // إذا لم يُحدد رقم → قبول الكل
    if (!count || count <= 0) count = pending.length

    // تحديد العدد النهائي
    const toApprove = pending.slice(0, count)
    const jids = toApprove.map(u => u.jid)

    // تنفيذ القبول دفعة واحدة (أفضل وأأمن)
    await conn.groupRequestParticipantsUpdate(m.chat, jids, 'approve')

    await conn.reply(
      m.chat,
      `✅ تم قبول *${jids.length}* طلب/طلبات انضمام بنجاح.`,
      m
    )

  } catch (e) {
    console.error(e)
    conn.reply(m.chat, '❌ حدث خطأ أثناء قبول الطلبات.', m)
  }
}

handler.command = /^(قبول|accept)$/i
handler.group = true
handler.botAdmin = true
handler.admin = true

export default handler
