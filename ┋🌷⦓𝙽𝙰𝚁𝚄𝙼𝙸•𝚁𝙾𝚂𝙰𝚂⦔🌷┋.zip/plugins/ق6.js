let handler = async (m, { conn }) => {
  let user = global.db.data.users[m.sender];
  let name = conn.getName(m.sender) || 'مستخدم';
  let taguser = '@' + m.sender.split("@")[0];

  let currentTime = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

  let groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
  let groupName = groupMetadata ? groupMetadata.subject : 'غير معروف';
  let groupMembers = groupMetadata ? groupMetadata.participants.length : 'غير معروف';

  let message = `
╮••─๋︩︪──๋︩︪─═⊐‹﷽›⊏═─๋︩︪──๋︩︪─┈☇
╿↵ مرحــبـا ⌊${taguser}⌉
── • ◈ • ──
*⌝🤖┊قــســم الـAI┊🤖⌞* 
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹𝑫𝑨𝑵𝑵𝒀›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ
┤─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪─☇ـ
┤┌─๋︩︪──ׅ─ׅ┈ ─๋︩︪─›
> │┊ ۬.͜ـ🤖˖ ⟨كيلـوا☇ 

> │┊ ۬.͜ـ🤖˖ ⟨ليفـاي☇

> │┊ ۬.͜ـ🤖˖ ⟨الستـور☇

> │┊ ۬.͜ـ🤖˖ ⟨سمـسم☇

> │┊ ۬.͜ـ🤖˖ ⟨ليـفاي☇

> │┊ ۬.͜ـ🤖˖ ⟨مـودي☇

> │┊ ۬.͜ـ🤖˖ ⟨دليـل☇

> │┊ ۬.͜ـ🤖˖ ⟨ديـب☇ 

> │┊ ۬.͜ـ🤖˖ ⟨مبرمـج☇

> │┊ ۬.͜ـ🤖˖ ⟨ايلـون☇

> │┊ ۬.͜ـ🤖˖ ⟨زورو☇

> │┊ ۬.͜ـ🤖˖ ⟨لوفـي☇

> │┊ ۬.͜ـ🤖˖ ⟨ايـرين☇

> │┊ ۬.͜ـ🤖˖ ⟨جبتـي☇

> │┊ ۬.͜ـ🤖˖ ⟨مـريـم☇
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹𝑫𝑨𝑵𝑵𝒀›⊏═┈ ─๋︩︪─ ∙ ∙ ⊰ـ  `;

  const emojiReaction = '🤖';

  try {
    await conn.sendMessage(m.chat, { react: { text: emojiReaction, key: m.key } });

    await conn.sendMessage(m.chat, { 
      image: { url: 'https://i.postimg.cc/rprYtbVp/IMG-20251230-WA0102.jpg' },
      caption: message,
      mentions: [m.sender]
    });
  } catch (error) {
    console.error("Error sending message:", error);
    await conn.sendMessage(m.chat, { text: 'حدث خطأ أثناء إرسال الصورة.' });
  }
};

handler.command = /^(ق6)$/i;
handler.exp = 50;
handler.fail = null;

export default handler;
