// ملف: فنن.js
import axios from "axios";

async function translateToEnglish(text) {
  try {
    const url = "https://translate.googleapis.com/translate_a/single";
    const params = { client: "gtx", sl: "auto", tl: "en", dt: "t", q: text };
    const response = await axios.get(url, { params });
    return response.data?.[0]?.[0]?.[0] || text;
  } catch {
    return text;
  }
}

async function text2imgFast(prompt) {
  const translated = await translateToEnglish(prompt);
  return `https://image.pollinations.ai/prompt/${encodeURIComponent(translated)}?width=1024&height=1024&nologo=true&seed=${Date.now()}`;
}

async function fetchUrlToBuffer(url) {
  const response = await axios.get(url, { responseType: "arraybuffer", timeout: 60000 });
  return Buffer.from(response.data);
}

let handler = async (m, { conn, text, usedPrefix }) => {
  if (!text) throw `⚠️ مثال:\n${usedPrefix}فنن قطة فضائية`;
  
  const waitMsg = await conn.sendMessage(m.chat, { text: "🎨 جاري الرسم..." }, { quoted: m });
  
  const imageUrl = await text2imgFast(text);
  const buffer = await fetchUrlToBuffer(imageUrl);
  
  await conn.sendMessage(m.chat, { delete: waitMsg.key }).catch(() => {});
  await conn.sendMessage(m.chat, { 
    image: buffer, 
    caption: `✨ *تم الإنشاء* ✨\n📝 ${text}` 
  }, { quoted: m });
};

handler.command = /^(فنن)$/i;
export default handler;
