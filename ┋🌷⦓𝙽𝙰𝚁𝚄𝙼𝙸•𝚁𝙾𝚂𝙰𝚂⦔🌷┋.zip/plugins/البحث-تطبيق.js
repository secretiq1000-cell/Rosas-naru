import fetch from 'node-fetch';
import baileys from '@whiskeysockets/baileys';

const { proto, generateWAMessageFromContent } = baileys;

// دالة إرسال القائمة التفاعلية
async function sendList(conn, jid, data, quoted) {
    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ text: data.body }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: data.footer }),
                    header: proto.Message.InteractiveMessage.Header.create({ 
                        title: data.title,
                        hasMediaAttachment: data.image ? true : false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: data.buttonText || '📲 اختر تطبيق',
                                sections: data.sections
                            })
                        }]
                    })
                })
            }
        }
    }, { quoted });

    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id });
}

// دالة إرسال رسالة مع أزرار تفاعلية
async function sendButtonMessage(conn, jid, data, quoted) {
    const sections = [{
        title: data.sectionTitle || 'خيارات التحميل',
        rows: data.buttons.map(btn => ({
            title: btn.title,
            description: btn.description,
            id: btn.id
        }))
    }];

    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ text: data.body }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: data.footer }),
                    header: proto.Message.InteractiveMessage.Header.create({ 
                        title: data.title,
                        hasMediaAttachment: data.image ? true : false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: data.buttonText || '📥 خيارات',
                                sections: sections
                            })
                        }]
                    })
                })
            }
        }
    }, { quoted });

    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id });
}

// دالة بحث محسنة مع ترتيب حسب الصلة
async function enhancedSearch(query) {
    try {
        // البحث الأساسي
        const res = await fetch(`https://obito-mr-apis.vercel.app/api/search/apk_modded?q=${encodeURIComponent(query)}`);
        const json = await res.json();

        if (!json || !json.results || !Array.isArray(json.results)) {
            return [];
        }

        let results = json.results;

        // تحسين ترتيب النتائج حسب الصلة
        results = results.sort((a, b) => {
            let scoreA = 0;
            let scoreB = 0;

            const searchTerms = query.toLowerCase().split(' ');

            // حساب درجة الصلة للتطبيق A
            if (a.title) {
                const title = a.title.toLowerCase();
                searchTerms.forEach(term => {
                    if (title.includes(term)) scoreA += 3;
                    if (title === term) scoreA += 5;
                    if (title.startsWith(term)) scoreA += 2;
                });
            }

            if (a.category) {
                const category = a.category.toLowerCase();
                searchTerms.forEach(term => {
                    if (category.includes(term)) scoreA += 2;
                });
            }

            if (a.developer?.name) {
                const developer = a.developer.name.toLowerCase();
                searchTerms.forEach(term => {
                    if (developer.includes(term)) scoreA += 1;
                });
            }

            // حساب درجة الصلة للتطبيق B
            if (b.title) {
                const title = b.title.toLowerCase();
                searchTerms.forEach(term => {
                    if (title.includes(term)) scoreB += 3;
                    if (title === term) scoreB += 5;
                    if (title.startsWith(term)) scoreB += 2;
                });
            }

            if (b.category) {
                const category = b.category.toLowerCase();
                searchTerms.forEach(term => {
                    if (category.includes(term)) scoreB += 2;
                });
            }

            if (b.developer?.name) {
                const developer = b.developer.name.toLowerCase();
                searchTerms.forEach(term => {
                    if (developer.includes(term)) scoreB += 1;
                });
            }

            return scoreB - scoreA; // ترتيب تنازلي حسب الدرجة
        });

        // إزالة التكرارات
        const uniqueResults = [];
        const seenIds = new Set();

        results.forEach(app => {
            if (app.id && !seenIds.has(app.id)) {
                seenIds.add(app.id);
                uniqueResults.push(app);
            }
        });

        return uniqueResults.slice(0, 100); // إرجاع حتى 100 نتيجة

    } catch (error) {
        console.error('Search error:', error);
        return [];
    }
}

let handler = async (m, { conn, args, command, usedPrefix }) => {
    let query = args.join(" ").trim();
    
    // إذا كتب .تطبيق فقط بدون اسم
    if (command === 'تطبيق' && !query) {
        const guideText = `
📱 *دليل استخدام بوت التطبيقات*

🔍 *طريقة الاستخدام:*
\`.تطبيق اسم_التطبيق\`

📥 *خطوات التحميل:*
1. ابحث عن التطبيق
2. اختر من القائمة
3. اقرأ الوصف واضغط "📥 تأكيد التحميل"
4. سيتم التحميل تلقائياً

⚡ *مميزات البوت:*
• بحث دقيق ومرتب حسب الصلة
• عرض حتى 100 نتيجة للبحث
• تطبيقات موددة مجانية
• تحميل مباشر وسريع

💡 *نصائح للبحث:*
• استخدم كلمات دقيقة للحصول على أفضل النتائج
• يمكنك البحث بأسماء المطورين أيضاً
• النتائج مرتبة حسب الأكثر صلة أولاً
        `;

        await conn.sendMessage(m.chat, {
            text: guideText,
            footer: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 - ابدأ بالبحث الآن!",
        }, { quoted: m });
        return;
    }

    // إذا كتب .تطبيق مع اسم (البحث المحسن)
    if (command === 'تطبيق' && query) {
        try {
            await m.reply('🔍 جاري البحث الدقيق في التطبيقات...');
            
            const results = await enhancedSearch(query);

            if (!results || results.length === 0) {
                return m.reply('❌ لم يتم العثور على تطبيقات تطابق بحثك.\n\n💡 حاول استخدام:\n• كلمات بحث أكثر دقة\n• اسم التطبيق الكامل\n• اسم المطور');
            }

            // تقسيم النتائج إلى أقسام (كل قسم 10 نتائج)
            const sections = [];
            const chunkSize = 10;
            
            for (let i = 0; i < results.length; i += chunkSize) {
                const chunk = results.slice(i, i + chunkSize);
                const sectionTitle = i === 0 ? 
                    `🔍 أفضل النتائج لـ "${query}"` : 
                    `📊 النتائج ${i + 1}-${Math.min(i + chunkSize, results.length)}`;
                
                sections.push({
                    title: sectionTitle,
                    rows: chunk.map((app, index) => {
                        // إنشاء وصف مفصل لكل تطبيق
                        let description = '';
                        
                        // إضافة الفئة إذا موجودة
                        if (app.category) {
                            description += `📂 ${app.category}`;
                        }
                        
                        // إضافة المطور إذا موجود
                        if (app.developer?.name) {
                            description += ` | 👨‍💻 ${app.developer.name.substring(0, 15)}${app.developer.name.length > 15 ? '...' : ''}`;
                        }

                        // إضافة مؤشر الصلة
                        const globalIndex = i + index + 1;
                        const relevanceIndicator = globalIndex <= 5 ? ' 🎯' : (globalIndex <= 15 ? ' ⭐' : '');

                        return {
                            title: `📱 ${globalIndex}. ${app.title || 'بدون عنوان'}${relevanceIndicator}`,
                            description: description || 'معلومات غير متوفرة',
                            id: `${usedPrefix}عرض ${app.id}`
                        };
                    })
                });
            }

            const listData = {
                title: "📊 نتائج البحث الدقيق",
                body: `تم العثور على ${results.length} تطبيق مرتب حسب الصلة\n\n` +
                      `🔍 *الكلمة المبحوثة:* "${query}"\n` +
                      `🎯 *الأكثر صلة:* ${Math.min(5, results.length)} تطبيق أول\n` +
                      `📅 *آخر تحديث:* ${new Date().toLocaleDateString('ar-SA')}\n\n` +
                      `👇 اختر التطبيق الذي تريد تحميله:`,
                footer: `BY 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴 - عرض ${results.length} نتيجة مرتبة حسب الصلة`,
                buttonText: '🎯 اختر تطبيق',
                sections: sections
            };

            await sendList(conn, m.chat, listData, m);
            
        } catch (e) {
            console.error(e);
            await m.reply('❌ حدثت مشكلة أثناء البحث، تأكد من اسم التطبيق أو حاول لاحقًا.');
        }
        return;
    }

    // أمر عرض تفاصيل التطبيق مع زر التأكيد
    if (command === 'عرض') {
        if (!query) throw '❗ يرجى إدخال معرف التطبيق.';
        
        try {
            await m.reply('📥 جاري جلب معلومات التطبيق...');
            
            const res = await fetch(`https://obito-mr-apis.vercel.app/api/download/apk_modded_download?id=${encodeURIComponent(query)}`);
            const json = await res.json();

            if (!json || !json.title) throw '❌ لم يتم العثور على معلومات التطبيق.';

            const randomImage = Array.isArray(json.images) && json.images.length > 0
                ? json.images[Math.floor(Math.random() * json.images.length)]
                : null;

            // بناء الوصف مع جميع المعلومات المتاحة
            let descriptionText = '';
            if (json.description && Array.isArray(json.description)) {
                descriptionText = json.description.join("\n\n");
            } else if (json.description) {
                descriptionText = json.description;
            } else {
                descriptionText = 'لا يوجد وصف متوفر لهذا التطبيق.';
            }

            const bodyText = `📱 *${json.title}*\n\n` +
                `📂 *الفئة:* ${json.category || 'غير محددة'}\n` +
                `👨‍💻 *المطور:* ${json.developer?.name || 'غير معروف'}\n` +
                `📄 *الترخيص:* ${json.license || 'مجاني'}\n` +
                `🆔 *المعرف:* ${json.id || query}\n\n` +
                `📝 *الوصف:*\n${descriptionText.substring(0, 1500)}${descriptionText.length > 1500 ? '...' : ''}\n\n` +
                `👇 *اضغط على زر "📥 تأكيد التحميل" لبدء التحميل:*`;

            const buttonData = {
                title: `📱 ${json.title}`,
                body: bodyText,
                footer: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 - اضغط تأكيد التحميل لتحميل التطبيق",
                buttonText: "📥 خيارات التحميل",
                sectionTitle: "تحميل التطبيق",
                buttons: [
                    {
                        title: "📥 تأكيد التحميل",
                        description: `تحميل ${json.title}`,
                        id: `${usedPrefix}التنزيل ${json.id || query}`
                    },
                    {
                        title: "🔍 بحث متقدم",
                        description: "البحث عن تطبيقات أخرى",
                        id: `${usedPrefix}تطبيق`
                    }
                ]
            };

            await sendButtonMessage(conn, m.chat, buttonData, m);
            
        } catch (e) {
            console.error(e);
            await m.reply('❌ حدثت مشكلة أثناء جلب معلومات التطبيق.');
        }
        return;
    }

    // أمر التنزيل النهائي
    if (command === 'التنزيل') {
        if (!query) throw '❗ يرجى إدخال معرف التطبيق.';
        
        try {
            await m.reply('⏬ جاري تحميل التطبيق... قد يستغرق ذلك بضع دقائق');
            
            const res = await fetch(`https://obito-mr-apis.vercel.app/api/download/apk_modded_download?id=${encodeURIComponent(query)}`);
            const json = await res.json();

            const apkLink = json.download_links?.apk_android?.[0];
            if (!apkLink) throw '❌ لم يتم العثور على رابط تحميل.';

            // إرسال التطبيق
            await conn.sendMessage(m.chat, {
                document: { url: apkLink },
                mimetype: 'application/vnd.android.package-archive',
                fileName: `${(json.title || 'تطبيق').replace(/[^\w\s.]/gi, '')}.apk`,
                caption: `✅ *تم تحميل التطبيق بنجاح*\n\n` +
                         `📱 *الاسم:* ${json.title || query}\n` +
                         `📂 *الفئة:* ${json.category || 'غير معروف'}\n` +
                         `👨‍💻 *المطور:* ${json.developer?.name || 'غير معروف'}\n` +
                         `🆔 *المعرف:* ${json.id || query}\n\n` +
                         `BY 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴 🚀`
            }, { quoted: m });

        } catch (e) {
            console.error(e);
            await m.reply('❌ حدثت مشكلة أثناء إرسال ملف التطبيق.');
        }
        return;
    }
};

handler.help = ["تطبيق"]
handler.tags = ["البحث"]
// جعل الأمر يقبل الأسماء الإنجليزية والعربية معًا
handler.command = /^(تطبيق|عرض|التنزيل)$/i
handler.limit = true
handler.register = true

export default handler

