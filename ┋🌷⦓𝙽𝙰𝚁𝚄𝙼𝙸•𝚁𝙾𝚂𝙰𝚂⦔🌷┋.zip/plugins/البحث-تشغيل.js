import fetch from "node-fetch"

const yt = {
  baseUrl: 'https://ssvid.net',
  baseHeaders: {
    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'origin': 'https://ssvid.net',
    'referer': 'https://ssvid.net/youtube-to-mp3'
  },

  validateFormat(format) {
    if (format !== 'mp3') throw Error('❌ الصيغة غير صحيحة! الصيغة المدعومة: mp3')
  },

  async hit(path, payload) {
    const body = new URLSearchParams(payload)
    const r = await fetch(this.baseUrl + path, { method: 'POST', headers: this.baseHeaders, body })
    if (!r.ok) throw Error(`${r.status} ${r.statusText}`)
    return await r.json()
  },

  async download(queryOrUrl, format = 'mp3') {
    this.validateFormat(format)
    let search = await this.hit('/api/ajax/search', { query: queryOrUrl, cf_token: '', vt: 'youtube' })
    
    // إذا كان البحث بالكلمة وليس رابط
    if (search.p === 'search') {
      if (!search?.items?.length) throw Error(`❌ لم يتم العثور على نتائج للبحث: ${queryOrUrl}`)
      const { v } = search.items[0] // أخذ أول نتيجة
      search = await this.hit('/api/ajax/search', { query: 'https://www.youtube.com/watch?v=' + v, cf_token: '', vt: 'youtube' })
    }

    const vid = search.vid
    const k = search.links?.mp3?.mp3128?.k
    if (!k) throw Error('❌ لم يتم العثور على رابط تحميل الصوت.')
    
    const convert = await this.hit('/api/ajax/convert', { k, vid })
    return convert
  }
}

let handler = async (m, { text, conn }) => {
  try {
    if (!text) return m.reply(
      `🧞 استخدم الأمر هكذا:\n.تشغيل رابط_يوتيوب أو اسم_الأغنية\n\n🔹 مثال:\n.تشغيل Alan Walker Faded\n.تشغيل https://youtu.be/xyz`
    )

    m.reply('⏳ جاري جلب الصوت ...')

    const res = await yt.download(text, 'mp3')
    await conn.sendMessage(
      m.chat,
      { audio: { url: res.dlink }, mimetype: 'audio/mpeg', ptt: false },
      { quoted: m }
    )
  } catch (err) {
    m.reply(`❌ خطأ: ${err.message}`)
  }
}

handler.command = ['تشغيل', 'play']
handler.help = ['تشغيل <رابط|اسم>']
handler.tags = ['تحميل']

export default handler