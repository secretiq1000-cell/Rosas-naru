import yts from 'yt-search'
import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    
    if (!text) return conn.reply(m.chat, `نظام التحميل\n\nاكتب رابط الفيديو أو عنوانه\nمثال: .فيديو3 محمد منير\nاو: .فيديو3 https://youtu.be/...`, m)

    await m.react('👁️') 

    try {
        let videoUrl = text
        let videoTitle = ""

        // التحقق إذا كان النص رابطاً أم عنواناً للبحث
        const isUrl = text.match(/(youtube\.com|youtu\.be)/i)
        
        if (!isUrl) {
            // إذا كان عنواناً: قم بالبحث عن الفيديو
            await m.reply('جاري البحث عن الفيديو...')
            
            let search = await yts(text)
            let videos = search.videos
            
            if (!videos || videos.length === 0) {
                await m.react('🚫')
                return m.reply('لم يتم العثور على فيديو\nحاول بكلمات بحث مختلفة.')
            }
            
            // اختر أول نتيجة
            let firstVideo = videos[0]
            videoUrl = firstVideo.url
            videoTitle = firstVideo.title
        }

        const b = (s) => Buffer.from(s, 'base64').toString('utf-8')
        const base = b("aHR0cHM6Ly9hcGkuZXZvZ2Iub3Jn")
        const key = b("c2FzdWtl")

        let res = await fetch(`${base}/dl/ytmp4?url=${encodeURIComponent(videoUrl)}&key=${key}`)
        let json = await res.json()

        if (!json.status || !json.data || !json.data.dl) {
            await m.react('🚫')
            return m.reply('الرابط غير صالح\nحاول برابط آخر.')
        }

        const vid = json.data
        
        // استخدام عنوان البحث إذا لم يكن موجوداً في الـ API
        let finalTitle = videoTitle || vid.title

        let txt = `تحميل الفيديو\n\n`
        txt += `الاسم: ${finalTitle}\n`
        txt += `الجودة: ${vid.quality}\n`
        txt += `النوع: ${vid.type}\n`
        txt += `الصيغة: .${vid.format}`

        await conn.sendMessage(m.chat, { 
            video: { url: vid.dl }, 
            caption: txt,
            mimetype: 'video/mp4',
            fileName: `${finalTitle.replace(/[^\w\s]/gi, '')}.mp4`
        }, { quoted: m })

        await m.react('🛸') 

    } catch (e) {
        await m.react('❗')
        console.error(e)
        m.reply('حدث خطأ\nتأكد من اتصال الإنترنت وحاول مرة أخرى.')
    }
}

handler.help = ['فيديو3']
handler.tags = ['downloader']
handler.command = ['فيديو3']

export default handler
