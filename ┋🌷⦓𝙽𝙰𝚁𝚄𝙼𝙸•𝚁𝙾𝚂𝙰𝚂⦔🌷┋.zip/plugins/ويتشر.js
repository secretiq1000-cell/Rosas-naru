/*
بحث و تحميل حلقات الانمي من تطبيق انمي ويتشر معا جودات
by 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 🦅
*/

import fetch from 'node-fetch';
import baileys from '@whiskeysockets/baileys';

const { proto, generateWAMessageFromContent } = baileys;

const API_BASE = "https://obito-mr-apis.vercel.app/api/anime/witcher";

async function sendList(conn, jid, data, quoted) {
    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ text: data.body }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: data.footer }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            name: 'single_select',
                            buttonParamsJson: JSON.stringify({
                                title: data.buttonTitle || '📲 اختر من القائمة',
                                sections: data.sections
                            })
                        }]
                    })
                })
            }
        }
    }, { quoted });

    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id });
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        // ✅ تجاوز أي قيود Premium
        if (global.db && global.db.data && global.db.data.users) {
            global.db.data.users[m.sender] = global.db.data.users[m.sender] || {};
            global.db.data.users[m.sender].premium = true;
        }

        if (command === 'wit-eps') {
            if (!text) return m.reply(`✧ يرجى إرسال معرف الأنمي.\nمثال:\n${usedPrefix}wit-eps naruto`);
            
            const res = await fetch(`${API_BASE}/episodes?id=${encodeURIComponent(text)}`);
            const data = await res.json();
            const episodes = data.results;

            if (!episodes || episodes.length === 0) throw "لا توجد حلقات متاحة.";

            const sections = [{
                title: "🎞️ الحلقات المتاحة",
                rows: episodes.map(ep => ({
                    title: ep.name,
                    description: `اضغط لاختيار جودة التحميل`,
                    id: `${usedPrefix}wit-serv ${text}|${ep.id}`
                }))
            }];

            await sendList(conn, m.chat, {
                body: `*⎔ ⋅ ───━ •﹝🎞️ الحلقات ﹞• ━─── ⋅ ⎔*\n\n📺 الأنمي: *${text}*\n🎯 اختر الحلقة لعرض الجودات المتوفرة:`,
                footer: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 🦅 - 𝐀𝐍𝐈𝐌𝐄 𝐖𝐈𝐓𝐂𝐇𝐄𝐑",
                buttonTitle: '❲ 📄 اختر حلقة ❳',
                sections
            }, m);
            
            return;
        }

        if (command === 'wit-serv') {
            if (!text) return m.reply(`✧ يرجى إرسال معرف الأنمي والحلقة.\nمثال:\n${usedPrefix}wit-serv naruto|1`);
            
            const [animeId, episodeId] = text.split('|');
            const res = await fetch(`${API_BASE}/download?animeId=${animeId}&epId=${episodeId}`);
            const data = await res.json();
            const servers = data.results;

            if (!servers || servers.length === 0) throw "عذراً، لا تتوفر جودات لهذه الحلقة حالياً.";

            const sections = [{
                title: "📥 الجودات المتوفرة للتحميل",
                rows: servers.map(srv => ({
                    title: `جودة ${srv.quality}`,
                    description: `تحميل مباشر عبر سيرفر ويتشر`,
                    id: `${usedPrefix}wit-dl ${srv.directLink}|${animeId}_${episodeId}_${srv.quality}`
                }))
            }];

            await sendList(conn, m.chat, {
                body: `*⎔ ⋅ ───━ •﹝📥 اختر الجودة ﹞• ━─── ⋅ ⎔*\n\n🎬 الحلقة: *${episodeId}*\n⚠️ سيتم إرسال الفيديو كملف مباشر بمجرد الاختيار.`,
                footer: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 🦅 - 𝐒𝐄𝐋𝐄𝐂𝐓 𝐐𝐔𝐀𝐋𝐈𝐓𝐘",
                buttonTitle: '❲ 📥 قائمة الجودات ❳',
                sections
            }, m);
            
            return;
        }

        if (command === 'wit-dl') {
            if (!text) return m.reply(`✧ يرجى إرسال رابط التحميل.\nمثال:\n${usedPrefix}wit-dl https://...|naruto_1_720p`);
            
            const [directLink, fileName] = text.split('|');

            await m.reply(`🚀 جاري جلب الحلقة من السيرفر...\n📦 الملف: ${fileName}.mp4\n⏳ يرجى الانتظار قليلاً...`);

            return await conn.sendMessage(m.chat, {
                document: { url: directLink },
                mimetype: 'video/mp4',
                fileName: `${fileName}.mp4`,
                caption: `*⎔ ⋅ ───━ •﹝✅ تم التحميل ﹞• ━─── ⋅ ⎔*\n\n🎬 الملف: ${fileName}\n🚀 تم الرفع بواسطة 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 🦅\n\n*⎔ ⋅ ───━ •﹝ 𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 🦅 ﹞• ━─── ⋅ ⎔*`
            }, { quoted: m });
        }

        // البحث الرئيسي
        if (!text) return m.reply(`*⎔ ⋅ ───━ •﹝📺﹞• ━─── ⋅ ⎔*\n🌟 *محرك ويتشر للتحميل المباشر:*\n${usedPrefix}ويتشر <اسم الأنمي>\n*⎔ ⋅ ───━ •﹝📺﹞• ━─── ⋅ ⎔*`);

        await m.reply("🔍 جاري البحث عن الأنمي...");

        const res = await fetch(`${API_BASE}/search?q=${encodeURIComponent(text)}`);
        const data = await res.json();
        const hits = data.results;

        if (!hits || hits.length === 0) throw "لا توجد نتائج للبحث.";

        const sections = [{
            title: "✨ نتائج البحث",
            rows: hits.map((anime) => ({
                title: anime.name,
                description: `النوع: ${anime.type}`,
                id: `${usedPrefix}wit-eps ${anime.id}`
            }))
        }];

        await sendList(conn, m.chat, {
            body: `*⎔ ⋅ ───━ •﹝🔎 نتائج البحث ﹞• ━─── ⋅ ⎔*\n\n🎯 اختر الأنمي للانتقال لقائمة الحلقات:`,
            footer: "𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐 🦅 - 𝐀𝐍𝐈𝐌𝐄 𝐖𝐈𝐓𝐂𝐇𝐄𝐑",
            buttonTitle: '❲ 📺 القائمة ❳',
            sections
        }, m);

    } catch (err) {
        console.error(err);
        await m.reply(`*⎔ ⋅ ───━ •﹝⚠️ خطأ﹞• ━─── ⋅ ⎔*\n❌ ${err.message || err}\n*⎔ ⋅ ───━ •﹝⚠️﹞• ━─── ⋅ ⎔*`);
    }
};

handler.help = ['ويتشر <اسم الأنمي>', 'wit-eps <معرف الأنمي>', 'wit-serv <أنمي|حلقة>'];
handler.tags = ['anime'];
handler.command = ['ويتشر', 'wit-eps', 'wit-serv', 'wit-dl'];

export default handler;
