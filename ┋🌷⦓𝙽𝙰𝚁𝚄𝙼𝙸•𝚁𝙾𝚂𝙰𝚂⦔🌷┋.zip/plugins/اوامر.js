
function clockString(ms) {
    if (isNaN(ms)) return '00:00';
    let h = Math.floor(ms / 3600000);
    let m = Math.floor((ms % 3600000) / 60000);
    let s = Math.floor((ms % 60000) / 1000);
    return [h, m, s]
        .map(v => v.toString().padStart(2, '0'))
        .join(':');
}

function getUserRank(level = 0) {
    const ranks = [
        { min: 81, rank: 'كـايـجـو 👑' },
        { min: 71, rank: 'ذئـب 🐺' },
        { min: 61, rank: 'سـاحـࢪ 🔮' },
        { min: 51, rank: 'ظـل 🎼' },
        { min: 41, rank: 'مـحـاࢪب ⚔️' },
        { min: 31, rank: 'ࢪائد 🛰️' },
        { min: 21, rank: 'حـر 🪶' },
        { min: 16, rank: 'عـادي 🧑‍✈️' },
        { min: 11, rank: 'سـحـسـاوي 🐕' },
        { min: 6, rank: 'بـلـوجـوبـاوي 😋' },
        { min: 3, rank: 'عـبـد 🦦' },
        { min: 0, rank: 'كـلـب 🐶' }
    ];
    return ranks.find(r => level >= r.min)?.rank || 'مواطن 🧍‍♂️';
}

import pkg from '@whiskeysockets/baileys';
const { prepareWAMessageMedia } = pkg;

const handler = async (m, { conn, command, text }) => {
    try {

        // نظام تقييم البوت
        if (command === 'تقييم') {
            const rating = Number((text || '').trim());

            if (!text) {
                return m.reply(
                    '🌷 أرسل تقييمك للبوت من 1 إلى 5 بهذا الشكل:\n.تقييم 5'
                );
            }

            if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
                return m.reply(
                    '❌ التقييم يجب أن يكون رقمًا من 1 إلى 5.\nمثال: .تقييم 5'
                );
            }

            global.db.data.botRatings ||= {};
            global.db.data.botRatings[m.sender] = rating;

            return m.reply(
                `🌷 شكرًا لتقييمك!\n⭐ تقييمك: ${rating}/5\n┋🌷⦓𝙽𝙰𝚁𝚄𝙼𝙸•𝚁𝙾𝚂𝙰𝚂⦔🌷┋`
            );
        }

        const uptime = clockString(process.uptime() * 1000);

        const user = global.db?.data?.users?.[m.sender] || {};
        let name;

        try {
            name = await conn.getName(m.sender);
        } catch {
            name = 'مستخدم';
        }

        const level = user.level || 0;
        const role = getUserRank(level);

        const totalUsers = Object.keys(global.db?.data?.users || {}).length;
        const now = new Date();
        const day = now.toLocaleDateString('ar-TN', { weekday: 'long' });
        const date = now.toLocaleDateString('ar-TN', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });

        await conn.sendMessage(m.chat, {
            react: { text: '🧸', key: m.key }
        });

        const imageUrl = 'https://picturetolink.com/i/Aa8TG4m0pm.jbg';

        const media = await prepareWAMessageMedia(
            { image: { url: imageUrl } },
            { upload: conn.waUploadToServer }
        );

        const botName = '┋🌷⦓𝙽𝙰𝚁𝚄𝙼𝙸•𝚁𝙾𝚂𝙰𝚂⦔🌷┋';

        const sections = [
            ['🎮', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـالـعـاب⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق1'],
            ['🛡️', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـمـشـرفـيـن⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق2'],
            ['🛠️', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـــادوات⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق3'],
            ['⬇️', '╼֪ׄ༉᱖ ╼֪ׄالـتـحـمـيـل⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق4'],
            ['🏦', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـبـنـك⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق5'],
            ['🤖', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـ ai⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق6'],
            ['🎭', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـتـسـلـيـة⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق7'],
            ['🕋', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـديـن⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق8'],
            ['🖌️', '╼֪ׄ༉᱖ ╼֪ׄ⦓╼֪ׄ༉᱖ ╼֪ׄ⦓الـزغـاࢪف⦔╼֪ׄ༉᱖ ╼֪ׄ⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق9'],
            ['⚔️', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـنـقـابـات⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق10'],
            ['🖼️', '╼֪ׄ༉᱖ ╼֪ׄالـصـوࢪ⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق11'],
            ['😎', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـوجـوهـات⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق12'],
            ['🫦', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـشـهـوة⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق13'],
            ['🍷', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـمـطـوࢪيـن⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق14'],
            ['👾', '╼֪ׄ༉᱖ ╼֪ׄ⦓فـيـديـو جـيـم⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق15'],
            ['📖', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـامـان⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق16'],
            ['🛍', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـبـريـمـيـوم⦔╼֪ׄ༉᱖ ╼֪ׄ', '.ق17'],
            ['📜', '╼֪ׄ༉᱖ ╼֪ׄ⦓الـقـوانـيـن⦔╼֪ׄ༉᱖ ╼֪ׄ', '.القواعد']
        ].map(([emoji, title, id]) => ({
            title: `${emoji} ${title}`,
            rows: [{
                title,
                description: botName,
                id
            }]
        }));

        const message = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            hasMediaAttachment: true,
                            ...media
                        },
                        body: {
                            text: `
*╼֪ׄ╾╼ׁ֪╾ִ╼🌷༉᱖ ╼֪ׄ╾╼ׁ֪╾ִ╼֪╾*
*ω𝖾ℓ𝖼𝗈ო𝖾 ƚ𝗈 𝐍𝗮𝗋𝗎ო𝗂 𝐑𝗈𝗌𝗮𝗌 𝐁𝗈ƚ 🫟*
*╼֪ׄ╾╼ׁ֪╾ִ╼🌷༉᱖ ╼֪ׄ╾╼ׁ֪╾ִ╼֪╾*

*╮═≼『 ⏤͟͞ू⃪ ┃🍷┃⏤͟͞ू⃪  』≽═╭*
*❍╎🕊┊  الـمـسـتـخـدم* 
*╮═≼『 ⏤͟͞ू⃪ ┃🍷┃⏤͟͞ू⃪  』≽═╭*

*❍╎🧸┊ 𝙽𝙰𝙼𝙴 : ${name}*
*❍╎🧸┊ 𝙻𝙴𝚅𝙴𝙻 : ${level}*
*❍╎🧸┊ 𝚁𝙰𝙽𝙺 : ${role}*
*╼֪ׄ╾╼ׁ֪╾ִ╼🌷༉᱖ ╼֪ׄ╾╼ׁ֪╾ִ╼֪╾*

*───━━━⊱  🍷  ⊰━━━───*
*❍╎⚙️┊ مـعـلومـات الـبـوت*
*───━━━⊱  🍷  ⊰━━━───*

*❍╎🌸┊ 𝙽𝙰𝙼𝙴 : ┋🌷⦓𝙽𝙰𝚁𝚄𝙼𝙸•𝚁𝙾𝚂𝙰𝚂⦔🌷┋*
*❍╎🌸┊ 𝚄𝚂𝙴𝚁𝚂 : ${totalUsers}*
*❍╎🌸┊ 𝙾𝚆𝙽𝙴𝚁 : ╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ*
*❍╎🌸┊ 𝙽𝚄𝙼𝙱𝙴𝚁 : wa.me/201553801908*
*╼֪ׄ╾╼ׁ֪╾ִ╼🌷༉᱖ ╼֪ׄ╾╼ׁ֪╾ִ╼֪╾*

*⌬──══─┈•⤣🌺⤤•┈─══──⌬*
~*❍╎🧸┊ مـعـلومـات عـامـة*~
*⌬──══─┈•⤣🌺⤤•┈─══──⌬*
*❍╎🎀┊ 𝙳𝙰𝚈 : ${day}*
*❍╎🎀┊ 𝚃𝙷𝙴 𝙳𝙰𝚃𝙴 : ${date}*
*❍╎🎀┊ 𝚂𝚃𝙰𝚁𝚃 : ${uptime}*
*╼֪ׄ╾╼ׁ֪╾ִ╼🌷༉᱖ ╼֪ׄ╾╼ׁ֪╾ִ╼֪╾*

*╼֪ׄ╾╼ׁ֪╾ִ╼🌷༉᱖ ╼֪ׄ╾╼ׁ֪╾ִ╼֪╾*
*┋🌷⦓𝙽𝙰𝚁𝚄𝙼𝙸•𝚁𝙾𝚂𝙰𝚂⦔🌷┋*
*╼֪ׄ╾╼ׁ֪╾ִ╼🌷༉᱖ ╼֪ׄ╾╼ׁ֪╾ִ╼֪╾*
                            `,
                            subtitle: botName
                        },
                        contextInfo: {
                            mentionedJid: [m.sender]
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: 'single_select',
                                    buttonParamsJson: JSON.stringify({
                                        title: '╼֪ׄ༉᱖ ╼֪ׄ⦓الاقـسـام⦔╼֪ׄ༉᱖ ╼֪ׄ',
                                        sections
                                    })
                                },
                                {
                                    name: 'cta_url',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: '╼֪ׄ༉᱖ ╼֪ׄ⦓الـقـنـاة⦔╼֪ׄ༉᱖ ╼֪ׄ',
                                        url: 'https://whatsapp.com/channel/0029Vb8DdbGDTkJyauiZnf1b'
                                    })
                                },
                                {
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: '╼֪ׄ༉᱖ ╼֪ׄ⦓الـمـطـوࢪ⦔╼֪ׄ༉᱖ ╼֪ׄ',
                                        id: '.المطور'
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        };

        await conn.relayMessage(m.chat, message, {});

        // أزرار التقييم والتنصيب
        const extraButtons = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: '╼֪ׄ༉᱖ ╼֪ׄ⦓خـدمـات NARUMI ROSAS⦔╼֪ׄ༉᱖ ╼֪ׄ'
                        },
                        footer: {
                            text: botName
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: '⭐ ╼֪ׄ༉᱖ ╼֪ׄ⦓تـقـيـيـم الـبـوت⦔╼֪ׄ༉᱖ ╼֪ׄ',
                                        id: '.تقييم'
                                    })
                                },
                                {
                                    name: 'quick_reply',
                                    buttonParamsJson: JSON.stringify({
                                        display_text: '🚀 ╼֪ׄ༉᱖ ╼֪ׄ⦓تـنـصـيـب بـوت فـرعـي⦔╼֪ׄ༉᱖ ╼֪ׄ',
                                        id: '.تنصيب'
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        };

        await conn.relayMessage(m.chat, extraButtons, {});

    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, {
            text: '❌ حصل خطأ أثناء تنفيذ الأمر'
        }, { quoted: m });
    }
};

handler.help = ['menu'];
handler.tags = ['main'];
handler.command = ['menu', 'قائمة', 'الاوامر', 'اوامر', 'تقييم'];

export default handler;
