// ╔════════════════════════════╗
// 👑 𝑀𝛩𝛩𝐷𝐸 𝑨𝑳𝑯𝑨𝑲𝑬𝑴
// ╚════════════════════════════╝

const zodiak = [
  ["♑ الجدي", new Date(1970, 0, 1)],
  ["♒ الدلو", new Date(1970, 0, 20)],
  ["♓ الحوت", new Date(1970, 1, 19)],
  ["♈ الحمل", new Date(1970, 2, 21)],
  ["♉ الثور", new Date(1970, 3, 21)],
  ["♊ الجوزاء", new Date(1970, 4, 21)],
  ["♋ السرطان", new Date(1970, 5, 22)],
  ["♌ الأسد", new Date(1970, 6, 23)],
  ["♍ العذراء", new Date(1970, 7, 23)],
  ["♎ الميزان", new Date(1970, 8, 23)],
  ["♏ العقرب", new Date(1970, 9, 23)],
  ["♐ القوس", new Date(1970, 10, 22)],
  ["♑ الجدي", new Date(1970, 11, 22)]
].reverse()

function getZodiac(month, day) {
  let d = new Date(1970, month - 1, day)
  return zodiak.find(([_, _d]) => d >= _d)[0]
}

let handler = async (m, { conn, text }) => {
  let input = text.trim()

  if (!input) {
    return conn.sendMessage(m.chat, {
      text: `❌ *لازم تكتب تاريخ ميلادك*\n\nمثال: .برجي 2002 02 25\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`
    }, { quoted: m })
  }

  const parts = input.split(/\s+/)
  if (parts.length < 3) {
    return conn.sendMessage(m.chat, {
      text: '⚠️ *التاريخ غير صحيح!*\n\nاكتب بالشكل: .برجي 2002 02 25\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐'
    }, { quoted: m })
  }

  const [year, month, day] = parts.map(p => parseInt(p))
  const date = new Date(year, month - 1, day)

  if (isNaN(date.getTime())) {
    return conn.sendMessage(m.chat, {
      text: '⚠️ *التاريخ غير صحيح!*\n\nاكتب بالشكل: .برجي 2002 02 25\n\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐'
    }, { quoted: m })
  }

  const d = new Date()
  const [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
  const birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]

  const zodiac = getZodiac(birth[1], birth[2])

  const ageD = new Date(d - date)
  const age = ageD.getFullYear() - new Date(1970, 0, 1).getFullYear()

  const birthday = [
    tahun + (
      (bulan > birth[1]) ||
      (bulan === birth[1] && tanggal > birth[2]) ||
      (bulan === birth[1] && tanggal === birth[2])
    ),
    ...birth.slice(1)
  ]

  const cekusia = bulan === birth[1] && tanggal === birth[2]
    ? `🎂🥳 *كل سنة وانت طيب!* 🎉 عيد ميلادك الـ ${age} النهارده`
    : `${age} سنة 🎈`

  // تحديد الشخص المستهدف
  let target = m.sender
  if (m.mentionedJid && m.mentionedJid.length > 0) {
    target = m.mentionedJid[0]
  } else if (m.quoted) {
    target = m.quoted.sender
  }
  
  const targetName = target.split('@')[0]

  const teks = `
🪐 *معلومات برجك* 🪐

📅 *تاريخ الميلاد:* ${birth.join('-')}
🎁 *عيد الميلاد القادم:* ${birthday.join('-')}
👤 *العمر:* ${cekusia}
🔮 *برجك:* ${zodiac}

✨ لـ @${targetName}

⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯
𝑫𝑨𝑵𝑵𝒀 𝑨𝑳𝑺𝑯𝑩𝑨𝑯 𝐕𝟐`

  await conn.sendMessage(m.chat, { 
    text: teks,
    mentions: [target]
  }, { quoted: m })
}

handler.command = ['برجي', 'الابراج', 'ابراج']
handler.help = ['برجي']
handler.category = 'tools'
handler.description = '🪐 اعرف برجك وعُمرك من تاريخ ميلادك'

export default handler
