const handler = async (m, { conn, text, command, usedPrefix }) => {

  // دالة استخراج المنشن بكل الطرق
  function getMentioned(m, text) {
    if (m?.mentionedJid && m.mentionedJid[0]) return m.mentionedJid[0];
    if (m?.quoted?.sender) return m.quoted.sender;

    if (text) {
      const number = text.match(/@(\d+)/);
      if (number) return number[1] + "@s.whatsapp.net";
    }

    return null;
  }

  let who = getMentioned(m, text);

  // لو لا يوجد منشن
  if (!who) {
    const warntext = `
╔═━━••【🧬】••━━═╗
✦ قم بالرد على رسالة أو منشن المستخدم ✦
╚═━━••【🧬】••━━═╝

—◉ مثال:
${usedPrefix + command} @${global.suittag}
    `.trim();
    return m.reply(warntext);
  }

  // منع تحذير البوت أو نفسك
  if (who === conn.user.jid) return m.reply("لا يمكن تحذير البوت يا قلبي 🐤.");
  if (who === m.sender) return m.reply("لا يمكنك تحذير نفسك يا حب 🫶🏻.");
// منع تحذير المطور (آمن)
let owners = (global.owner || []).map(v => {
  return v.toString().includes('@')
    ? v
    : v + '@s.whatsapp.net';
});

if (owners.includes(who)) {
  return m.reply("❌ لا يمكن إعطاء إنذار للمطور.");
}

  // جلب بيانات المستخدم
  let user = global.db.data.users[who] || { warn: 0 };
  global.db.data.users[who] = user;

  const reason = text ? text.replace(/@\d+/g, "").trim() : "بدون سبب";
  user.warn++;

  await m.reply(
    `
╔═━━••【🧬】••━━═╗
✦ *@${who.split`@`[0]}* لقد تلقيت تحذيرًا ✦
✦ السبب: ${reason} ✦
✦ عدد التحذيرات: ❪${user.warn}/3❫ ✦
╚═━━••【🧬】••━━═╝
    `.trim(),
    null,
    { mentions: [who] }
  );

  if (user.warn >= 3) {
    user.warn = 0;
    await m.reply(
      `
╔═━━••【🧬】••━━═╗
✦ حذرتك ثلاث مرات!! ✦
✦ *@${who.split`@`[0]}* لقد تجاوزت *3* تحذيرات ✦
✦ سيتم طردك الآن 👽 ✦
╚═━━••【🧬】••━━═╝
      `.trim(),
      null,
      { mentions: [who] }
    );

    await conn.groupParticipantsUpdate(m.chat, [who], 'remove');
  }

  return false;
};

// تشغيله في كل البوتات الأساسية و الفرعية
handler.all = async () => true;

handler.command = /^(تحذير|warn|انذار)$/i;
handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;
