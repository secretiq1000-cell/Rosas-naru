import { watchFile, unwatchFile } from "fs"
import chalk from "chalk"
import { fileURLToPath } from "url"
import fs from "fs"

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

//BETA: Si quiere evitar escribir el número que será bot en la consola, agregué desde aquí entonces:
//Sólo aplica para opción 2 (ser bot con código de texto de 8 digitos)
global.botNumber = "" //Ejemplo: 201022950118

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.owner = ["201553801908", "201044689315", "01124341361"]
global.suittag = ["201553801908"] 
global.prems = []

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.libreria = "Baileys Multi Device"
global.vs = "^1.8.2|Latest"
global.nameqr = "ROSAS-MD"
global.sessions = "Sessions/Principal"
global.jadi = "Sessions/SubBot"
global.yukiJadibts = true

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.botname = "┋🌷⦓𝙽𝙰𝚁𝚄𝙼𝙸•𝚁𝙾𝚂𝙰𝚂⦔🌷┋"
global.textbot = "BY『 ╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ 』"
global.dev = "BY 『 ╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ 』"
global.author = "© 𝙰𝙷𝙼𝙴𝙳🎼"
global.etiqueta = "BY『 ╼֪ׄ༉᱖ ╼֪ׄ⦓𝐀𝐇𝐌𝐄𝐃⦔╼֪ׄ༉᱖ ╼֪ׄ 』"
global.currency = "𝙰𝙷𝙼𝙴𝙳"
global.banner = "https://picturetolink.com/i/jR6StjhPlU.jpg"
global.icono = "https://picturetolink.com/i/jR6StjhPlU.jpg"
global.catalogo = fs.readFileSync('./lib/catalogo.jpg')

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.group = "https://chat.whatsapp.com/IgoLSPUERDm2N41dR5a3KR?s=cl&p=a&iam=2"
global.community = "https://chat.whatsapp.com/IgoLSPUERDm2N41dR5a3KR?s=cl&p=a&iam=2"
global.channel = "https://whatsapp.com/channel/0029Vb8DdbGDTkJyauiZnf1b"
global.github = "https://github.com/The-King-Destroy/YukiBot-MD"
global.gmail = "agnoevsy@gmail.com"
global.ch = {
ch1: "120363424239487841@newsletter"
}

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

global.APIs = {
xyro: { url: "https://api.xyro.site", key: null },
yupra: { url: "https://api.yupra.my.id", key: null },
vreden: { url: "https://api.vreden.web.id", key: null },
delirius: { url: "https://api.delirius.store", key: null },
zenzxz: { url: "https://api.zenzxz.my.id", key: null },
siputzx: { url: "https://api.siputzx.my.id", key: null }
}

//*─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─⭒─ׄ─ׅ─ׄ─*

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
unwatchFile(file)
console.log(chalk.redBright("Update 'settings.js'"))
import(`${file}?update=${Date.now()}`)
})
